# Glossary

| Term | Meaning |
| --- | --- |
| Purchase ID | Buyer-persisted globally unique logical purchase key; it is not an authorization secret. |
| Binding | Immutable purchase terms: buyer, provider, purchase ID, quote ID/version, amount, request digest, expiry, contract and network scope. |
| Environment fingerprint | Stable identifier derived from the sandbox genesis configuration; distinguishes fresh chains that reuse account names. |
| Quote | Provider-authorized immutable offer for one binding. Database intent exists before chain registration. |
| Accepted payment | Finalized contract state accepting the deposit for the exact binding. It says nothing about service quality or completion. |
| Provider revenue | Native balance credited to the provider's own contract account; storage lock and gas rewards are accounted separately. |
| Delivery | Offchain processing lifecycle: pending, running, succeeded or failed, separate from payment. |
| Canonical request | Validated, deterministically serialized request whose SHA-256 digest is bound to the quote. |
| Canonical result | Single durable report committed by the worker holding the current lease token. Computation can repeat. |
| Reconciliation | Independent finalized-chain lookup and full binding comparison before marking paid or enqueuing work. |
| Unresolved | A response, RPC lookup or state is insufficient to determine payment; it does not authorize a fresh purchase or charge. |
| Lease / fencing token | Time-bounded job ownership and unique claim token required for renewal and terminal updates. |
| NEP-413 challenge | Standard signed authentication payload with a one-use nonce bound to buyer, service, environment and expiry. |
| Local MVP | Node API/CLI, SQLite and a real disposable NEAR sandbox; remote/testnet/mainnet behavior remains a separate verification boundary. |
