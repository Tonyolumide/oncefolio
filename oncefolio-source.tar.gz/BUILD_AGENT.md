# Oncefolio build directive

## Mandate and reading
Complete the authorized local API/CLI MVP: buy one structured-data report, interrupt, restart and recover the same paid purchase/result. Read AGENTS.md, the brief/source inventory, SECURITY.md, BACKEND_SETUP.md, flow map/contracts and the three flow files. The current user instruction overrides stale setup-only text in historical documents. No external release or spending is authorized.

## Foundation and order
Inspect the existing payment spike and run its baseline. Preserve pinned toolchains/lockfiles. Add the environment example/generated config, checksum migrations, deterministic fixtures, idempotent bootstrap and real-caller authorization smoke. Build shared canonicalization, environment binding, SQLite, identity and errors before purchase → delivery → recovery. Do not start a dependent flow while its contract is red.

## Per-flow loop
Write a failing behavior/security test, implement the smallest complete path with all retry/failure states, run focused checks, then drive a real localhost API/CLI path through NEAR and SQLite. Review specification compliance before code quality. Independent payment/security review must cover auth, exact bindings, chain resets, worker fencing and crash windows. Preserve the distinction between repeated computation and a single canonical result.

## Security, platform and quality
Use standard NEP-413 verification with finalized FullAccess membership, one-use nonce and session expiry. Never invent/commit credentials. Bound JSON input and use parameterized SQL. Do not log secrets or private requests/results. CLI feedback must be readable, deterministic and usable without color/animation; no haptic or screen-reader claims from a headless test. Check syntax/lint/type assumptions, dependency advisories and secrets proportionally; document toolchain limitations.

## Activation, recovery and release
Local generated sandbox accounts are the proof environment. Stop for deployment, paid transactions, publication, DNS, legal consent, destructive real-data operations or submission without exact authority. Environment mismatch or migration checksum drift is an error, not a reset invitation. Reconcile uncertain chain writes; fence every worker update; never reset lifetime attempts. Production backup/restore, monitoring and rollout are separate release work.

## Evidence and done
Inspect every project-owned verification argv and definition before execution. Bootstrap twice; replay migrations; prove real unauthenticated/wrong-role/cross-object denial; run fresh payment, delivery and restart tests. Capture migration ledger/schema fingerprints, command stdout/stderr/exit codes and runtime results. Generate BUILD_STATE.json from actual repository/runtime truth. Do not hand-author success evidence. A complete local build has all three flows proven, no blocking review findings, reproducible commands and a final report separating automated, static, runtime and unverified claims.
