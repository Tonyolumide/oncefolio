# Backend setup and contracts

## Stack and bootstrap
Node 24 ESM, built-in HTTP and node:sqlite, SQLite WAL, pinned near-api-js and NEAR SDK JS. The existing real contract remains the payment boundary. No external paid API is needed for deterministic report generation. Native toolchain support is currently macOS ARM64; follow spike/README.md for its pinned downloads.

Executable commands: ./oncefolio setup installs pinned local dependencies/tools and builds; ./oncefolio start reuses a persistent local chain/provider/worker; ./oncefolio demo runs the isolated restart walkthrough; ./oncefolio test invokes scripts/product-verify.mjs. scripts/bootstrap.mjs initializes schema idempotently (offline schema fixture by default, or a supplied runtime config); scripts/migration-replay.mjs compares two clean schemas. Runtime evidence is generated in outputs/product/.

## Modules and state owners
| Module | Owns |
| --- | --- |
| app/report.mjs | Request validation, canonical JSON/digest, deterministic report |
| app/near.mjs | Local-only RPC, finalized access keys/purchases/quotes, genesis fingerprint |
| app/store.mjs | SQLite transactions, immutable intent/quote/purchase, sessions, jobs and canonical result |
| app/auth.mjs | NEP-413 challenge/session protocol and buyer identity |
| app/server.mjs | HTTP contracts, limits, ownership checks, error mapping |
| app/worker.mjs | Paid-job claim, lease/fencing, bounded compute and commit |
| app/client.mjs | Buyer identity, durable intent/signing, buy/recover/status/retry |

## Domain and persistence
The ledger has payment unknown/accepted; client attempts separately have not_submitted/unknown/rejected/accepted observations. Delivery has awaiting/pending/running/succeeded/failed states. Do not collapse them into one success flag. A missing RPC observation is not a terminal rejection.

Versioned migrations start at migrations/001_initial.sql and are applied transactionally with recorded checksums. WAL plus short explicit transactions supports independent local processes; configure a bounded busy timeout. Unique purchase IDs and immutable binding/request digest prevent conflicting retry writes. Store environment fingerprint+contract metadata, one-use challenges, hashed sessions, quotes, purchase payment evidence, jobs/attempts/lease tokens and canonical results. Private rows are buyer-owned. Keep completed result and delivery terminal state in the same transaction. Lifetime attempts cap at three; exhausted expired leases fail durably.

Initialization compares persisted environment identity to live genesis configuration; refuse mismatches without resetting. Reopening the same database on the same chain must preserve schema, purchases, leases and results. No automatic deletion policy is implemented for local fixtures; operational retention remains a release decision.

## HTTP contract
| Method and route | Input/identity | Outcome |
| --- | --- | --- |
| GET /health | Public | Local readiness without private data |
| GET /v1/service | Public | Service origin, contract, environment and price metadata |
| POST /v1/auth/challenges | buyer | One-use bound NEP-413 challenge |
| POST /v1/auth/sessions | challenge_id, public_key, base64 signature | Hashed-server-side expiring bearer session |
| DELETE /v1/auth/session | Buyer bearer | Revoke that session |
| POST /v1/quotes | Buyer bearer; purchase_id, request | Persist immutable intent, register/recover exact quote |
| GET /v1/purchases/:id | Owning buyer bearer | Payment/delivery status and available canonical report |
| POST /v1/purchases/:id/reconcile | Owning buyer bearer | Independent finalized payment lookup and eligible job enqueue |
| POST /v1/purchases/:id/retry | Owning buyer bearer | Requeue failed paid work only within lifetime attempt cap |

CLI operations are buy, recover, status and retry with runtime configuration and durable intent path. A fresh authentication session may be needed after restart; the purchase ID never changes. Non-2xx responses must distinguish validation, unauthorized, forbidden/hidden object, conflict, unavailable/unresolved and exhausted retry states. No external webhook, analytics or notification service is in scope.

## Integration contracts
Before chain registration, persist the exact quote so an ambiguous response can be recovered via finalized get_quote. Product provider equals contract account: acceptance credits that account directly, with storage locks and gas rewards reported separately. The configured provider signing key is local-only and is not accepted from HTTP callers.

Buyer intent includes exact canonical request/binding, signer, environment fingerprint and signed transaction bytes/hash, durably written before broadcast. Backend reconciliation never trusts client-supplied acceptance. Requests/results remain offchain. Job claims and result commits require current fencing tokens; a stale worker may compute but cannot overwrite the canonical result.

## Configuration, operations and recovery
Runtime configuration supplies local API origin, RPC URL, contract/provider ID, database path and signing-key location; implementations must name exact environment/config keys in .env.example or generated config without committing values. Bind server/RPC to localhost. Log correlation IDs and status codes without payloads/secrets. Input bounds and lifetime worker limits constrain local cost; production quotas and storage pruning need review.

Use forward migrations and checksum validation; do not edit applied migrations. Do not reset a mismatched environment/database. Quote registration and payment ambiguity reconcile against chain; expired leases reconcile against durable job ownership. Tests must rebuild from zero, run bootstrap twice, reopen persistent data, and drive real caller authorization. Deployment, production rollback, real-data restore, external monitoring and testnet activation remain unverified and unauthorized.


The local demo proves live chain/provider restart, stored-result recovery and unchanged provider balance. The full verifier proves schema replay, bootstrap twice and real caller authorization.
