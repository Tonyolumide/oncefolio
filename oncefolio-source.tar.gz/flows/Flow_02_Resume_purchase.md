# Flow_02: Resume a purchase or result

## Goal
The buyer agent retrieves its existing purchase/report after restart, interruption or explicit status check. Success is the same ID/binding and canonical result, or an honest unresolved/pending/failed status. Entries come from Flow 01 and provider completion; bounded retry can return to Flow 03.

## References and coverage
REF-001/002 and historical REF-004/006/007. Covers CLI recover/status/retry, GET /v1/purchases/:id, POST /v1/purchases/:id/reconcile and POST /v1/purchases/:id/retry. Extends historical payment recovery to authorized private results.

## Entries, sequence, and exits
Load the durable original intent, verify environment identity and authenticate the buyer. Read finalized chain state and compare the full stored binding; backend independently verifies before marking paid. Retrieve durable delivery status/result. If failed and fewer than three lifetime attempts were used, request retry under the same purchase. A succeeded result is returned from storage without execution or payment. Logout revokes the current session; later authentication resumes the same object.

## States and feedback
Missing state/RPC failure means unresolved. Pending/running means paid work is incomplete. Failed means payment remains accepted but delivery failed; retry availability is explicit. Exhausted means no more automatic reruns. Foreign objects and invalid sessions reveal no private result. Conflict means the intent does not match the stored purchase. Payment accepted after quote expiry remains retrievable.

## Interaction surface and transitions
Text CLI plus HTTP JSON. Each command returns status and purchase ID; no hidden resubmission/new ID. No animation, focus choreography or haptics applies. Interrupting polling does not cancel payment or discard a result.

## Actions and functions
app/client.mjs loads intent, reauthenticates and recovers. app/near.mjs performs finalized lookup; app/server.mjs authorizes ownership; app/store.mjs returns immutable result/state and transactional retry eligibility. Exact signed-byte rebroadcast is distinct from a newly signed contract retry. Neither absence nor uncertainty triggers automatic new charging. Concurrent recover/retry calls converge on one purchase and bounded job state.

## Data and integrations
Persistent data: yes. Reuses SQLite purchase/job/result and buyer's intent. Key membership is finalized and rechecked for private access. Results remain offchain; no external notifications. Session expiry does not erase purchases. Database or chain mismatch is a visible refusal, not reset.

## Security and abuse cases
Test guessed IDs, changed buyer/request/binding, expired/replayed session proof, revoked keys, unavailable RPC, chain reset and simultaneous retries. Retry cannot reset attempts, replace a canonical result or mark unpaid work paid.

## Accessibility
Stable machine-readable states and readable CLI text without color dependence. No screen-reader/device claim from headless tests.

## Platform behavior
A fresh process must succeed without in-memory caches. Provider/API restart must preserve requests/results. A runtime key/config path may be local, but no secret is echoed in command output or evidence.

## Contracts
01 → 02 durable intent; 03 → 02 canonical result; 02 → 03 bounded same-purchase retry; shared environment/identity/error contracts.

## Verification
| Requirement | Implementation owner | Automated/runtime proof | Status |
| --- | --- | --- | --- |
| Recover after lost payment response | Client/gateway/store | Killed buyer plus new process result retrieval | Pending |
| Recover committed result after provider restart | Store/server | API restart on same database and same result hash | Pending |
| Keep unknown payment unresolved | Gateway/client | RPC failure and unbroadcast-intent cases | Pending |
| Protect private result | Auth/server/store | Real caller cross-object/revoked-key denial | Pending |
| Retry bounded without payment | Store/worker | Concurrent retries and lifetime exhaustion | Pending |

## Open decisions
No local blocker. Automatic refunds, public deployment and production retention require later scope/authority.

## Build seed
Start with a real paid purchase whose buyer receives no response. Kill/restart the buyer, reconcile final state and retrieve the same persisted result; assert no new service payment.


## Executed local verification — November 5, 2026
See outputs/product/result.json, runtime.json, authorization.json, migration-state.json and demo.json. The clean verifier covers real settlement, ownership, worker SIGKILL/fencing, failed-delivery retry, stale nonce recovery and provider/chain/stored-result restart. Historical pending entries above describe foundation-authoring status; generated proof supersedes them. Testnet/production remain unverified.
