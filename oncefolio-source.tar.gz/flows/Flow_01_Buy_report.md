# Flow_01: Buy a report

## Goal
The buyer agent funds one immutable structured-data report request. A fresh purchase intent enters; a finalized accepted purchase eligible for delivery exits to Flow 03. Interruption or later status retrieval enters Flow 02.

## References and coverage
REF-001/002 define intent and constraints; REF-004/005/006 cover historical payment proof. Covers CLI buy, buyer authentication and POST /v1/quotes. Preserve the spike's duplicate rejection/refund behavior while adding durable private requests and quote recovery.

## Entries, sequence, and exits
Validate/normalize a bounded request; choose and persist a purchase ID. Authenticate via bound NEP-413 challenge. Persist the immutable quote intent before provider chain registration; on ambiguity compare finalized get_quote instead of changing IDs. Buyer persists exact binding, request, environment and signed bytes/hash before broadcasting payment. Reconcile finalized purchase independently; queue paid work once. Exit paid/pending to 03 or unresolved/interrupted to 02. Cancellation before broadcast leaves an unsubmitted intent; after broadcast it cannot retract acceptance.

## States and feedback
Validation and ownership errors are actionable terminal responses. Quote registration can be pending/unavailable, recovered or conflicting. Payment may be unsubmitted, unresolved, definitively rejected, or accepted; do not equate a duplicate-call failure with failure of the original purchase. Expiry blocks a new acceptance, not recovery of an old one. CLI prints purchase ID and distinct payment/delivery statuses without private payloads or secrets.

## Interaction surface and transitions
Headless HTTP and text CLI, no modal/page/motion/haptics. Commands return structured data/status and preserve a durable intent on interruption. No production UI is being introduced; visual prototype gate is not applicable to this flow.

## Actions and functions
app/client.mjs owns buy/sign/persist/broadcast. app/auth.mjs authenticates the buyer. app/report.mjs validates/canonicalizes/digests. app/store.mjs owns immutable quote/request writes. app/near.mjs registers/recovers the quote and reads final payment; app/server.mjs exposes routes. Quote same-ID/same-request retry returns the same terms; changed request conflicts. Provider account alone registers quotes. Backend never accepts a caller's paid flag as proof. SQL and contract mutations are atomic within their respective boundaries, not across chain+database.

## Data and integrations
Persistent data: yes. Private request/quote/purchase metadata in SQLite; signed intent on buyer disk; only binding metadata/digest on NEAR. Provider equals contract account, so native deposit credits it directly. Sessions expire; local request/result retention is explicit operator-managed storage. Chain fingerprint mismatch rejects; RPC offline leaves unresolved state.

## Security and abuse cases
Reject wrong buyers, restricted/revoked keys, replayed/expired challenges, malformed/oversized requests, changed terms and foreign objects. Provider key never arrives in API input. A new sandbox cannot inherit a paid row from an old chain. Duplicate calls can cost gas; inspect exact completed refunds.

## Accessibility
Text-only CLI output must remain readable without color or animation and expose stable codes. No GUI/device accessibility claim is made by API tests.

## Platform behavior
Node 24 localhost; current native toolchain macOS ARM64 only. Disk persistence is atomic before broadcast. Process termination never grants authority to make a new purchase automatically.

## Contracts
identity-session, environment and immutable-intent globals; 01 → 03 paid-job handoff; 01 → 02 durable recovery handoff in 00_Flow_Contracts.md.

## Verification
| Requirement | Implementation owner | Automated/runtime proof | Status |
| --- | --- | --- | --- |
| Same-ID quote concurrency/conflict | app/store.mjs, app/near.mjs | Concurrent API quote tests + chain lookup | Pending |
| Real identity and ownership | app/auth.mjs, app/server.mjs | Actual signed-key challenge/replay/foreign-object tests | Pending |
| One accepted deposit | Contract + gateway | Existing spike regression and product receipt evidence | Historical spike PASS; product pending |
| Crash-safe buyer intent/payment | app/client.mjs | Kill after broadcast, fresh process resume | Pending |
| Chain instance isolation | Gateway/store/client | Fresh-genesis mismatch tests | Pending |

## Open decisions
No local correctness blocker. Commercial price, deployment and service-failure remedy beyond bounded rerun remain release decisions, not implicit production approval.

## Build seed
First test: concurrent same-ID quote calls persist one exact quote; changed payload rejects. Next: finalized payment unlocks one job, while an unknown response does not.


## Executed local verification — November 5, 2026
See outputs/product/result.json, runtime.json, authorization.json, migration-state.json and demo.json. The clean verifier covers real settlement, ownership, worker SIGKILL/fencing, failed-delivery retry, stale nonce recovery and provider/chain/stored-result restart. Historical pending entries above describe foundation-authoring status; generated proof supersedes them. Testnet/production remain unverified.
