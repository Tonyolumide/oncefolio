# Flow_03: Complete a paid report

## Goal
The provider worker completes one paid structured-data report or records an honest failure. Trigger is an eligible durable job from Flow 01/02. Success commits one canonical report and succeeded state atomically, then returns control to buyer retrieval in Flow 02.

## References and coverage
REF-001/002 define useful delivery; REF-005 establishes the payment boundary only. Covers worker claim, computation, lease recovery and result commit. No arbitrary-work verification or universal exactly-once execution is claimed.

## Entries, sequence, and exits
Independently verified accepted payment creates an eligible job. Atomically claim with incremented lifetime attempt count, lease expiry and unique fencing token. Compute the deterministic report from the stored canonical request. While holding the current token, atomically persist report/hash and succeeded state. On failure, fence the failed-state update. After crash/expiry, reclaim only within the three-attempt lifetime cap; an expired last attempt fails durably. Buyer-requested rerun uses the same paid purchase.

## States and feedback
Pending awaits a claim; running exposes in-progress status; succeeded exposes a stored result; failed exposes bounded retry or exhaustion. Payment stays accepted through delivery failure. A stale worker receives commit rejection and cannot overwrite a newer result. There is no automatic service-failure refund.

## Interaction surface and transitions
Background worker with API-visible status and text demo trace. No UI container, motion, haptic or device behavior. Worker shutdown/interruption is recoverable through durable lease state rather than an in-memory queue.

## Actions and functions
app/store.mjs owns transactional paid-job eligibility, claim, lease token/expiry, renewal, success/failure commits and retry cap. app/worker.mjs orchestrates claim/compute/commit; app/report.mjs validates normalized input and produces deterministic issues/summary/duplicates. Every mutation checks current fencing token; result and delivery terminal state share a transaction. Two workers may contend; only one current claim may commit. Crash after compute but before commit may recompute. No downstream external side effect needs an exactly-once guarantee.

## Data and integrations
Persistent data: yes. SQLite owns request, accepted-payment evidence, job attempts/token/expiry, canonical report/hash and terminal state. No private data goes onchain. Report input is bounded to 128 KiB, 1000 flat rows and 32 fields. No external model/API cost. Local data is retained for recovery until explicit operator cleanup.

## Security and abuse cases
Unpaid jobs are ineligible. Reject forged/stale tokens on renewal, success and failure. Exhausted attempts never reset. Protect private result retrieval in Flow 02. Reject malformed prototype keys, nested data, excessive fields/rows/strings and unsupported numeric values before quoting. Public provider full-access custody remains a disclosed trust boundary.

## Accessibility
Status codes and CLI trace are text-readable without color; background processing has no direct focus or haptic surface.

## Platform behavior
Node 24 workers can be independent local processes against the same WAL database. Use bounded database busy waits and short transactions. Process death must not leave an immortal running job, including after the last allowed attempt.

## Contracts
01 → 03 finalized payment eligibility; 03 → 02 atomic result publication; 02 → 03 bounded rerun. Shared identity/environment/canonicalization rules remain consistent.

## Verification
| Requirement | Implementation owner | Automated/runtime proof | Status |
| --- | --- | --- | --- |
| Useful deterministic report | app/report.mjs | Required/type/duplicate fixtures, stable digest | Pending |
| Only paid work executes | Gateway/store | Unpaid-job denial plus finalized chain proof | Pending |
| One canonical result under contention | Store/worker | Two real workers and stale-token commit rejection | Pending |
| Crash before result commit | Worker/store | Kill/restart worker, recover lease and commit | Pending |
| Final-attempt crash terminates | Store/worker | Expired third-attempt lease becomes failed | Pending |
| Durable result recovery | Store/server | Reopen database/API and return identical result hash | Pending |

## Open decisions
No local correctness blocker. Production lease duration, service latency budget, retention and refund policy require measured operational scope before release.

## Build seed
First test races two store connections for one paid job; only the current fenced claim can commit. Then kill a worker between compute and commit and prove bounded recovery.


## Executed local verification — November 5, 2026
See outputs/product/result.json, runtime.json, authorization.json, migration-state.json and demo.json. The clean verifier covers real settlement, ownership, worker SIGKILL/fencing, failed-delivery retry, stale nonce recovery and provider/chain/stored-result restart. Historical pending entries above describe foundation-authoring status; generated proof supersedes them. Testnet/production remain unverified.
