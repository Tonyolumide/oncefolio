# Brief analysis

- North star: let an agent recover an already paid useful service after interruption without another accepted service payment.
- Paradigm: api, with buyer CLI and local demo orchestration.
- Target platforms: local Node 24; currently pinned native NEAR toolchain on macOS ARM64.
- Persistent data: yes
- Sensitive categories: signing credentials, buyer requests/results, bearer sessions and signed purchase intents.
- Proof environment: real NEAR sandbox, localhost HTTP, isolated SQLite databases and fresh processes.

## Actors and measurable goals
Buyer: buy one report and later retrieve the same purchase/result. Provider worker: complete a paid request or expose a recoverable failure. Operator: start the local environment and inspect bounded failure states without treating payment as delivery proof.

## Scope and non-goals
One deterministic structured-data validation report; native NEAR payment; immutable bindings; signed buyer identity; concurrent retry and process recovery. No cross-chain system, marketplace, custom cryptography, universal exactly-once execution, arbitrary-work verification, external deployment or production custody claim.

## Signature moments
The buyer receives no payment response, restarts and recovers the existing paid purchase. A worker restarts or loses its lease, yet an old worker cannot replace the canonical result or trigger another charge.

## Supplied materials
PROJECT_BRIEF.md, BUILD_PLAN.md, existing spike code/tests and outputs/FEASIBILITY_REPORT.md; see 00_Source_Inventory.md. Later user instruction “lets build” authorizes the local product beyond the earlier setup/spike boundary.

## Constraints
Solo builder. Target submission November 14, 2026 at 23:59 UTC, subject to rechecking official rules. No paid external services. Keep independent Lotveil disclosure for eventual submission. The local product now has generated runtime proof for signed identity, private delivery, real settlement and process/chain/result recovery; historical spike proof remains separate.

## Decision register
| Status | Decision | Owner | Affected flows |
| --- | --- | --- | --- |
| APPROVED | Build the local MVP; no external release/spending | User instruction | All |
| LOCKED | Separate payment acceptance from delivery state and useful work | User brief | All |
| LOCKED | Buyer-only private request/result access, finalized key membership, one-use challenges | Build orchestrator | 01, 02 |
| LOCKED | Provider equals contract account; no asynchronous payout or automatic failure refund | Build orchestrator, bounded MVP design | 01, 03 |
| LOCKED | Genesis fingerprint binds persistent state; quote intent precedes chain mutation | Architecture review + orchestrator | All |
| LOCKED | At most three lifetime worker attempts with fenced commits | Build orchestrator | 03 |
| ASSUMED | Structured-data report and API/CLI-first interaction fit the first service | Build orchestrator; reversible before wider release | All |

## Open questions
No user blocker for the local implementation. Before wider release, decide storage retention/deletion, operational quotas, deployment environment, pricing and a service-failure commercial remedy. Local default: bounded retries under the same purchase, no automatic refund; local fixtures retained until explicit operator removal. BUILD_PROMPT.txt target: at most 60 lines and 4000 characters; actual count is recorded below after generation.

BUILD_PROMPT.txt actual: 30 lines, 2006 characters (including final newline), within the 60-line/4000-character target.
