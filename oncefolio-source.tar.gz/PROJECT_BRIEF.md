# Oncefolio — project brief

Status: local API/CLI MVP implemented. Updated November 5, 2026. See README.md for commands and outputs/product/result.json for fresh verification; the original payment spike remains separate.

## Purpose
Help an agent buy one useful service with native NEAR testnet payments and recover its purchase and result after connection loss or restart, without creating another successful charge for the same purchase.

Solo hackathon MVP, independent of Lotveil. Oncefolio (formerly ReceiptLock) is provisional: preliminary name search only; domains and trademark clearance are unverified.

## Core demonstration
An agent accepts a quote, persists a purchase ID, pays, loses its connection before receiving confirmation, restarts, and retrieves the existing purchase and eventual result. Concurrent retries must converge on the same purchase. A retry with changed purchase terms must fail.

Actors: buyer agent purchases and recovers; one integrated provider delivers and recovers results; operator inspects payment and delivery failures.

## Scope and boundaries
- LOCKED: one integrated paid service; native NEAR testnet only; purchase IDs bind buyer, provider, quote and request.
- LOCKED: separate settlement accounting from useful service delivery. A settled payment does not prove useful work, and a failed result does not mean payment failed.
- LOCKED: handle concurrency, payload conflicts, ambiguous payment status, definite payment failure, pending/failed delivery and result recovery.
- LOCKED: no cross-chain support, marketplace, custom cryptography, universal exactly-once execution claim or arbitrary-work verification claim.
- Persistent data: yes. Purchase records, payment evidence and recoverable results must survive process restart.
- Sensitive categories: wallet signing credentials and potentially private request/result data. Keep keys out of source and logs; keep request bodies and results offchain by default.

## Proposed product shape
ASSUMED: API/CLI-first buyer agent with a small demonstration console later. One deterministic structured-data validation service returns a report of invalid records, duplicates and summary counts. This offers useful, replayable output without an external paid API or claims about arbitrary work. Service choice remains open.

IMPLEMENTED: the provider operates the NEAR payment contract on its own account, so acceptance credits that account in one receipt. SQLite stores requests, independent delivery states, fenced jobs and canonical results. There is no separate asynchronous payout or automatic service-failure refund.

## Success criteria
For one purchase ID and immutable binding, retries produce one accepted service payment and a recoverable purchase record. Every attached-deposit attempt is accounted for, including refunds and network/storage costs. Two independent processes cannot cause two accepted payments or publish conflicting canonical results. A fresh process can recover using persisted identity and purchase ID. Failed or pending service delivery remains visible after payment settles.

## Hackathon requirements and sources
Official source: https://nearhackathon.com/ (checked through web search November 4, 2026). It confirms development ends November 14, 2026 at 23:59 UTC (November 15 at 00:59 Africa/Lagos), a working prototype, public repository, public X demo with the required event mention/tags and video or screenshots, and submission of both links. One person may enter two independent projects if each README names the other. Oncefolio and Lotveil must cross-reference each other before submission.

Canonical rules: https://nearhackathon.com/HACKATHON.md, retrieved November 4, 2026 after the initial setup fetch failed. Q-010 permits testnet-only projects; Q-011 makes suggested integrations optional; Q-012 permits local-only demos with a public reproducible repository and an X video. Q-015 confirms reciprocal README disclosure for two independent projects. Recheck before submission. No publication or submission is currently authorized.

Suggested track: Agent Economy; final selection remains open. Target date is confirmed by the official homepage, subject to later rule changes.

## Current authority
The user subsequently authorized the local MVP build with “lets build” and “continue,” and approved the build constitution. The API/CLI, paid report, durable storage, local orchestration and recovery tests are in scope. Testnet/mainnet deployment, real-token spending, publication, public repository and submission remain unauthorized.
