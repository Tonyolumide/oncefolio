# Flow contracts

## Global contracts
| ID | Applies | Owner | Contract | Verification |
| --- | --- | --- | --- | --- |
| identity-session | All private API routes | app/auth.mjs | NEP-413 nonce binds buyer, origin, contract, fingerprint and expiry; finalized FullAccess membership; atomic consume+session; hashed 15-minute bearer; key rechecked on access | Real-key API authorization tests; pending |
| environment | All persisted operations | app/near.mjs + app/store.mjs | Genesis fingerprint and contract identify the actual chain; mismatches reject without reset | Fresh-chain mismatch/reopen test; pending |
| immutable-intent | All flows | app/report.mjs + app/store.mjs | Canonical request digest and complete binding immutable under one purchase ID | Reordered-key equivalence, changed-payload conflicts; pending |
| error-taxonomy | All flows | app/server.mjs + CLI | Validation/auth/ownership/conflict are terminal until corrected; delivery failure may retry within cap; uncertain chain outcomes stay unresolved | HTTP/CLI contract tests; pending |
| observability | All flows | Shared foundation | Correlate by purchase ID; never emit private payloads, keys, tokens or signed bytes | Log/evidence scan; pending |
| notifications | None | Shared foundation | No external notifications; caller polls/reconciles | Static scope check |
| analytics | None | Shared foundation | No external analytics or telemetry | Static scope check |

## Flow 01 → Flow 03
- Trigger: POST /v1/purchases/:id/reconcile, or equivalent provider reconciliation after payment.
- Required data/source: stored immutable request and quote; finalized chain get_purchase output matching every binding field; environment fingerprint.
- Enforcement: app/near.mjs reads finalized state independently; app/store.mjs atomically records accepted payment and eligible job. Caller transaction hashes and accepted flags are not proof.
- Actor/permission: authenticated owning buyer may request reconciliation; only the provider worker claims work. Shared payment and job owners remain distinct.
- Success: one durable pending job for a paid purchase. No external notification or callback.
- Failure/cancellation: RPC uncertainty leaves payment unresolved and work locked. Buyer interruption does not cancel accepted payment. Definite rejected payment does not imply existing accepted purchase failed.
- Retry/concurrency: unique purchase key and transactional transition; concurrent reconciliation cannot create two canonical jobs. Changed binding conflicts. Migration mismatch stops rather than resets.
- Proof: concurrent reconciliation, unknown RPC, accepted-before-DB-crash and unpaid-job denial; runtime evidence pending.

## Flow 01 → Flow 02
- Trigger: lost response, restart or explicit recover/status command.
- Required data: buyer's durable purchase ID, canonical request, exact binding, signed transaction bytes/hash, signer and environment. Persist atomically before broadcast.
- Preconditions: runtime identity/environment match; authenticate the original buyer for private API data.
- Success/return: finalized accepted binding recovered under the same ID; then obtain delivery status/result. Exact signed-byte replay and independently signed retry are distinct actions.
- Failure handoff: missing state or unavailable RPC is unresolved, never a new purchase ID. A changed request/binding is a conflict. Expired quotes cannot invalidate an accepted purchase.
- Proof: kill buyer after broadcast before response; new process recovers and result remains stable; pending.

## Flow 03 → Flow 02
- Trigger: atomic canonical result commit or durable failed delivery update.
- Required data: current fenced lease token, paid purchase ID, attempts, canonical result JSON and delivery state; SQLite owns offchain state.
- Permission: worker writes only while holding the current lease; buyer reads only owned data. No request/result content onchain.
- Success: result and succeeded state commit in one transaction; recovery returns the stored result without execution or payment.
- Failure/retry: stale worker loses commit rights; computation may repeat. A failed job can be retried only within three lifetime attempts, under the same paid purchase. Expired final-attempt leases transition to failed. No automatic refund or exactly-once computation claim.
- Proof: two workers race, stale success/failure rejection, crash before commit, last-attempt crash and result retrieval after provider restart; pending.


## Executed local verification — November 5, 2026
See outputs/product/result.json, runtime.json, authorization.json, migration-state.json and demo.json. The clean verifier covers real settlement, ownership, worker SIGKILL/fencing, failed-delivery retry, stale nonce recovery and provider/chain/stored-result restart. Historical pending entries above describe foundation-authoring status; generated proof supersedes them. Testnet/production remain unverified.
