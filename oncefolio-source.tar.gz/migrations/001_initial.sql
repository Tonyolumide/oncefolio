CREATE TABLE metadata (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE challenges (
  id TEXT PRIMARY KEY,
  buyer TEXT NOT NULL,
  nonce TEXT NOT NULL,
  message TEXT NOT NULL,
  recipient TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL DEFAULT 0 CHECK (used IN (0, 1))
);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  buyer TEXT NOT NULL,
  public_key TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX sessions_expiry ON sessions(expires_at);
CREATE INDEX challenges_expiry ON challenges(expires_at);

CREATE TABLE purchases (
  id TEXT PRIMARY KEY,
  buyer TEXT NOT NULL,
  request_json TEXT NOT NULL,
  digest TEXT NOT NULL,
  binding_json TEXT NOT NULL,
  quote_status TEXT NOT NULL DEFAULT 'pending' CHECK (quote_status IN ('pending', 'ready')),
  payment TEXT NOT NULL DEFAULT 'unknown' CHECK (payment IN ('unknown', 'accepted')),
  payment_block TEXT,
  delivery TEXT NOT NULL DEFAULT 'awaiting' CHECK (delivery IN ('awaiting', 'pending', 'running', 'succeeded', 'failed')),
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 3),
  lease_token TEXT,
  lease_until INTEGER,
  result_json TEXT,
  last_error TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  CHECK ((delivery = 'running' AND lease_token IS NOT NULL AND lease_until IS NOT NULL)
      OR (delivery != 'running' AND lease_token IS NULL AND lease_until IS NULL)),
  CHECK (delivery != 'succeeded' OR result_json IS NOT NULL),
  CHECK (delivery = 'awaiting' OR payment = 'accepted')
);
CREATE INDEX purchases_work ON purchases(delivery, lease_until, created_at);

CREATE TABLE events (
  seq INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_id TEXT NOT NULL REFERENCES purchases(id),
  kind TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX events_purchase ON events(purchase_id, seq);
