import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync, readFileSync, rmSync, statSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { localEnvironment } from './environment.mjs';

mkdirSync('evidence/verification', { recursive: true });
mkdirSync('outputs/feasibility', { recursive: true });
rmSync('outputs/feasibility/result.json', { force: true });
const manifest = JSON.parse(readFileSync('spike/BUILD_VERIFICATION.json'));
const commands = manifest.commands.map(c => {
  if (c.argv[0] !== 'node') throw new Error('Only inspected Node commands are supported');
  return { ...c, argv: [process.execPath, ...c.argv.slice(1)] };
});
const transcript = { started: new Date().toISOString(), commands: [] };
const sourceFiles = ['spike/contract.js', 'spike/client.mjs', 'spike/feasibility.test.mjs', 'spike/BUILD_VERIFICATION.json', 'package.json', 'pnpm-lock.yaml'];
transcript.source_sha256 = Object.fromEntries(sourceFiles.map(path => [path, createHash('sha256').update(readFileSync(path)).digest('hex')]));
let pass = true;
for (const command of commands) {
  const result = spawnSync(command.argv[0], command.argv.slice(1), { env: localEnvironment(), encoding: 'utf8', maxBuffer: 12 * 1024 * 1024, timeout: 300000 });
  const row = { ...command, definition_sha256: createHash('sha256').update(readFileSync(command.definition_file)).digest('hex'), exit_code: result.status, signal: result.signal, error: result.error?.message, stdout: result.stdout ?? '', stderr: result.stderr ?? '' };
  transcript.commands.push(row);
  process.stdout.write(row.stdout); process.stderr.write(row.stderr);
  writeFileSync(`outputs/feasibility/${command.name}.log`, `${row.stdout}${row.stderr}`);
  writeFileSync('evidence/verification/command-transcript.json', JSON.stringify(transcript, null, 2));
  if (result.status !== 0 || result.error) { pass = false; break; }
}
const tests = transcript.commands.find(c => c.name === 'tests-and-runtime-proof');
if (!tests || !/# tests 7\b/.test(tests.stdout) || !/# pass 7\b/.test(tests.stdout) || !/# fail 0\b/.test(tests.stdout)) pass = false;
for (const item of manifest.evidence) {
  if (!existsSync(item.path) || statSync(item.path).mtimeMs < Date.parse(transcript.started) || Date.now() - statSync(item.path).mtimeMs > item.max_age_hours * 3600000) pass = false;
}
if (pass) {
  const proof = JSON.parse(readFileSync('outputs/feasibility/evidence.json'));
  if (proof.cases.length !== 5 || !proof.same_signed_transaction_replay?.no_balance_or_storage_change || proof.unbroadcast_recovery?.status !== 'unresolved' || proof.wasm_sha256 !== createHash('sha256').update(readFileSync('build/contract.wasm')).digest('hex')) pass = false;
}
transcript.completed = new Date().toISOString(); transcript.pass = pass;
writeFileSync('evidence/verification/command-transcript.json', JSON.stringify(transcript, null, 2));
writeFileSync('outputs/feasibility/result.json', JSON.stringify({ pass, completed: transcript.completed, commands: transcript.commands.map(c => ({ name: c.name, exit_code: c.exit_code })), limitation: 'Local contract funding only. Provider payout, result delivery and testnet are unverified.' }, null, 2));
writeFileSync('spike/BUILD_STATE.json', JSON.stringify({ generated: transcript.completed, scope: 'local-payment-spike', build_evidence: pass ? 'PASS' : 'FAIL', repository_revision: null, repository_note: 'Workspace has no project Git repository; no commit or public repository created.', source_sha256: transcript.source_sha256, commands: transcript.commands.map(c => ({ argv: c.argv, definition_file: c.definition_file, exit_code: c.exit_code })), evidence: manifest.evidence, full_product_foundation: 'UNVERIFIED', product_migrations: 'UNVERIFIED — no product database or migration implementation in this spike', open_findings: ['Provider payout and failure remedy not implemented', 'Service delivery and result authorization not implemented', 'Testnet and other operating systems unverified'] }, null, 2));
process.exitCode = pass ? 0 : 1;
