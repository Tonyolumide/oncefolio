import { startLocal } from './local.mjs';
import { BuyerClient } from '../app/client.mjs';
import { readFileSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import http from 'node:http';
import assert from 'node:assert/strict';
import { rpc, persist } from '../spike/client.mjs';
import { workOnce } from '../app/worker.mjs';
import { localEnvironment } from './environment.mjs';

const directory = resolve(`work/demo-${randomUUID()}`);
mkdirSync('outputs/product', { recursive: true });
let runtime, proxy, child;
const sockets = new Set();
try {
  runtime = await startLocal({ directory, apiPort: 0, worker: false });
  let buyer = new BuyerClient({ serviceUrl: runtime.serviceUrl, rpcUrl: runtime.rpcUrl, credentials: runtime.credentials.buyer });
  const intentPath = `${directory}/purchase.json`;
  await buyer.prepare(intentPath, JSON.parse(readFileSync('examples/request.json', 'utf8')));
  console.log('1. Quote saved; buyer intent and signed payment persisted.');
  let accepted, reject;
  const forwarded = new Promise((res, rej) => { accepted = res; reject = rej; });
  proxy = http.createServer(async (req, res) => {
    try { const chunks = []; for await (const chunk of req) chunks.push(chunk); const payload = JSON.parse(Buffer.concat(chunks).toString()); accepted(await rpc(runtime.rpcUrl, payload.method, payload.params)); } catch (error) { reject(error); res.destroy(); }
  });
  proxy.on('connection', socket => { sockets.add(socket); socket.on('close', () => sockets.delete(socket)); });
  proxy.listen(0, '127.0.0.1'); await once(proxy, 'listening');
  child = spawn(process.execPath, ['tests/fixtures/interrupted-payment.mjs', intentPath, `http://127.0.0.1:${proxy.address().port}`], { env: localEnvironment(), stdio: 'ignore' });
  const outcome = await forwarded; assert.ok(outcome.status.SuccessValue !== undefined);
  const exited = once(child, 'exit'); child.kill('SIGKILL'); await exited; child = undefined;
  for (const socket of sockets) socket.destroy(); await new Promise(r => proxy.close(r)); proxy = undefined;
  console.log('2. Payment accepted. Connection response withheld; buyer process killed.');
  const configPath = `${directory}/fresh-client.json`; persist(configPath, { serviceUrl: runtime.serviceUrl, rpcUrl: runtime.rpcUrl, credentials: runtime.credentials.buyer });
  const fresh = spawn(process.execPath, ['tests/fixtures/buyer-process.mjs', configPath, intentPath], { env: localEnvironment(), stdio: ['ignore', 'pipe', 'pipe'] });
  let output = ''; fresh.stdout.on('data', chunk => { output += chunk; });
  const [code] = await once(fresh, 'exit'); assert.equal(code, 0);
  const recovered = JSON.parse(output).purchase;
  assert.equal(recovered.payment.status, 'accepted'); assert.equal(recovered.delivery.status, 'pending');
  console.log('3. Fresh buyer process recovered the same paid purchase; delivery pending.');
  await workOnce(runtime.service.store);
  const delivered = await buyer.wait(intentPath); assert.equal(delivered.purchase.delivery.status, 'succeeded');
  const beforeRestart = await rpc(runtime.rpcUrl, 'query', { request_type: 'view_account', account_id: runtime.contractId, finality: 'final' });
  const originalEnvironment = runtime.environment;
  await runtime.close(); runtime = undefined;
  runtime = await startLocal({ directory, apiPort: 0, worker: false });
  assert.equal(runtime.environment, originalEnvironment);
  buyer = new BuyerClient({ serviceUrl: runtime.serviceUrl, rpcUrl: runtime.rpcUrl, credentials: runtime.credentials.buyer });
  const final = await buyer.recover(intentPath);
  assert.deepEqual(final.purchase.result, delivered.purchase.result);
  const afterRestart = await rpc(runtime.rpcUrl, 'query', { request_type: 'view_account', account_id: runtime.contractId, finality: 'final' });
  assert.equal(afterRestart.amount, beforeRestart.amount);
  console.log('4. Restarted chain and provider; recovered stored report without another payment.');
  console.log(JSON.stringify(final.purchase.result, null, 2));
  persist('outputs/product/demo.json', { completed: new Date().toISOString(), pass: true, environment: runtime.environment, purchase_id: final.purchase.purchase_id, result: final.purchase.result, chain_and_provider_restart: true, no_additional_provider_credit: afterRestart.amount === beforeRestart.amount, transaction_hash: outcome.transaction.hash });
} finally {
  if (child) child.kill('SIGKILL');
  if (proxy) { for (const socket of sockets) socket.destroy(); proxy.close(); }
  if (runtime) await runtime.close();
}
