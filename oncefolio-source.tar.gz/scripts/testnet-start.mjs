import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { NearGateway } from '../app/near.mjs';
import { createService } from '../app/server.mjs';
import { fail } from '../app/errors.mjs';

const configPath = resolve('work/testnet/runtime.json');
let service, worker;
try {
  const config = JSON.parse(readFileSync(configPath, 'utf8'));
  if (config.network !== 'testnet' || config.rpcUrl !== 'https://rpc.testnet.near.org' || config.apiPort !== 8788 || config.serviceUrl !== 'http://127.0.0.1:8788') fail('INVALID_TESTNET_RUNTIME', 409);
  const credential = JSON.parse(readFileSync(config.providerKeyFile, 'utf8'));
  if (credential.account_id !== config.contractId) fail('ACCOUNT_KEY_MISMATCH', 409);
  const near = new NearGateway({ ...config, providerKey: credential.secret_key });
  await near.ensureEnvironment();
  const contract = (await near.view('get_config')).value;
  if (contract.provider !== config.contractId || contract.network !== 'testnet') fail('EXISTING_CONFIG_MISMATCH', 409);
  service = await createService({ dbPath: config.dbPath, near, port: config.apiPort });
  worker = spawn(process.execPath, ['app/worker.mjs', configPath], { stdio: ['ignore', 'ignore', 'inherit'] });
  console.log(JSON.stringify({ ready: true, network: 'testnet', origin: service.origin, contract_id: config.contractId }));
  let stopping = false;
  const stop = async () => { if (stopping) return; stopping = true; if (worker && worker.exitCode === null) { const exited = once(worker, 'exit'); worker.kill('SIGTERM'); await exited; } await service.close(); process.exit(0); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
} catch (error) {
  if (worker && worker.exitCode === null) worker.kill('SIGTERM');
  if (service) await service.close();
  console.error(JSON.stringify({ error: error.code ?? 'TESTNET_START_FAILED' })); process.exitCode = 1;
}
