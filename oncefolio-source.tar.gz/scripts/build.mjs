import { spawnSync } from 'node:child_process';
import { localEnvironment } from './environment.mjs';
const result = spawnSync(process.execPath, ['node_modules/near-sdk-js/lib/cli/cli.js', 'build', 'spike/contract.js', 'build/contract.wasm'], { env: localEnvironment(), stdio: 'inherit' });
if (result.error) throw result.error;
process.exitCode = result.status ?? 1;
