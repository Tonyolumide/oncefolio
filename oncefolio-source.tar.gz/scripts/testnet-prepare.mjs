import { readFileSync, existsSync, mkdirSync, chmodSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash, randomBytes } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { KeyPair, baseEncode } from 'near-api-js';
import { rpc } from '../app/rpc.mjs';
import { fingerprint } from '../app/near.mjs';
import { persist } from '../spike/client.mjs';
import { fail } from '../app/errors.mjs';

export const TESTNET_RPC = 'https://rpc.testnet.near.org';
export const TESTNET_FAUCET = 'https://helper.nearprotocol.com/account';
export const TESTNET_DIRECTORY = resolve('work/testnet');
export const sha256 = value => createHash('sha256').update(value).digest('hex');
export const planBytes = plan => `${JSON.stringify(plan, null, 2)}\n`;
export const planHash = plan => sha256(planBytes(plan));

export function validatePlan(plan) {
  if (plan?.schema_version !== 1 || plan.network !== 'testnet' || plan.rpc_url !== TESTNET_RPC || plan.faucet_url !== TESTNET_FAUCET) fail('INVALID_TESTNET_PLAN', 409);
  const provider = /^oncefolio-provider-([0-9a-f]{8})\.testnet$/.exec(plan.accounts?.provider?.account_id ?? '');
  const buyer = /^oncefolio-buyer-([0-9a-f]{8})\.testnet$/.exec(plan.accounts?.buyer?.account_id ?? '');
  if (!provider || !buyer || provider[1] !== buyer[1]) fail('INVALID_TESTNET_ACCOUNTS', 409);
  if (!/^[0-9a-f]{64}$/.test(plan.environment ?? '') || !/^[0-9a-f]{64}$/.test(plan.artifact?.wasm_sha256 ?? '') || !/^[0-9a-f]{64}$/.test(plan.artifact?.contract_source_sha256 ?? '')) fail('INVALID_TESTNET_PLAN', 409);
  for (const account of Object.values(plan.accounts)) if (!/^ed25519:[1-9A-HJ-NP-Za-km-z]{43,44}$/.test(account.public_key ?? '')) fail('INVALID_PUBLIC_KEY', 409);
  if (plan.budgets?.service_price_yoctonear !== '100000000000000000000000' || plan.budgets?.max_validation_attached_deposits_yoctonear !== '300000000000000000000000' || plan.budgets?.function_call_gas !== '100000000000000' || plan.budgets?.max_estimated_deploy_gas !== '100000000000000' || plan.budgets?.max_signed_attempts_per_action !== 2) fail('INVALID_TESTNET_BUDGET', 409);
  return plan;
}

export function verifyArtifacts(plan, wasm, source, credentials) {
  validatePlan(plan);
  if (sha256(wasm) !== plan.artifact.wasm_sha256 || baseEncode(createHash('sha256').update(wasm).digest()) !== plan.artifact.wasm_code_hash || wasm.length !== plan.artifact.wasm_bytes || sha256(source) !== plan.artifact.contract_source_sha256) fail('REVIEWED_ARTIFACT_CHANGED', 409);
  for (const role of ['provider', 'buyer']) {
    const credential = credentials[role];
    if (credential?.account_id !== plan.accounts[role].account_id || KeyPair.fromString(credential.secret_key).getPublicKey().toString() !== plan.accounts[role].public_key) fail('REVIEWED_KEY_CHANGED', 409);
  }
}

function feeCost(fee, bytes = 1n) {
  if (!fee) fail('UNSUPPORTED_PROTOCOL_FEE_CONFIG', 409);
  return (BigInt(fee.send_sir) + BigInt(fee.execution)) * bytes;
}

export function deploymentBudget(protocol, wasmBytes, gasPrice) {
  const config = protocol.runtime_config;
  const fees = config.transaction_costs;
  const actions = fees.action_creation_config;
  const estimate = feeCost(fees.action_receipt_creation_config) + feeCost(actions.deploy_contract_cost) + feeCost(actions.deploy_contract_cost_per_byte, BigInt(wasmBytes));
  if (estimate > 100_000_000_000_000n) fail('DEPLOY_GAS_ESTIMATE_EXCEEDS_PLAN', 409);
  const storageBytes = BigInt(wasmBytes + 65536);
  const storage = storageBytes * BigInt(config.storage_amount_per_byte);
  const gasReserve = 10n * 100_000_000_000_000n * BigInt(gasPrice);
  return {
    estimated_deploy_gas: estimate.toString(), storage_amount_per_byte: config.storage_amount_per_byte,
    provider_storage_reserve_bytes: Number(storageBytes), provider_storage_reserve_yoctonear: storage.toString(),
    gas_price_yoctonear_per_gas: gasPrice.toString(), gas_reserve_yoctonear: gasReserve.toString(),
    provider_extra_reserve_yoctonear: '500000000000000000000000',
    provider_minimum_balance_yoctonear: (storage + gasReserve + 500_000_000_000_000_000_000_000n).toString(),
    buyer_minimum_balance_yoctonear: (300_000_000_000_000_000_000_000n + gasReserve).toString(),
    service_price_yoctonear: '100000000000000000000000', max_validation_attached_deposits_yoctonear: '300000000000000000000000',
    function_call_gas: '100000000000000', max_estimated_deploy_gas: '100000000000000',
    max_signed_attempts_per_action: 2,
    deployment_gas_note: 'DeployContract has no configurable gas field. This is a protocol-fee estimate checked against 100 TGas before signing; FunctionCall gas is explicitly capped.',
  };
}

export async function prepareTestnet({ directory = TESTNET_DIRECTORY, outputDirectory = resolve('outputs/testnet'), refreshArtifact = false, readRpc = rpc, getFingerprint = fingerprint } = {}) {
  directory = resolve(directory); mkdirSync(directory, { recursive: true, mode: 0o700 }); chmodSync(directory, 0o700);
  const credentials = {};
  for (const role of ['provider', 'buyer']) if (existsSync(`${directory}/${role}-key.json`)) credentials[role] = JSON.parse(readFileSync(`${directory}/${role}-key.json`, 'utf8'));
  const previousId = credentials.provider?.account_id ?? credentials.buyer?.account_id;
  const suffix = previousId ? /-([0-9a-f]{8})\.testnet$/.exec(previousId)?.[1] : randomBytes(4).toString('hex');
  if (!suffix) fail('INVALID_LOCAL_TESTNET_KEY', 409);
  for (const role of ['provider', 'buyer']) {
    if (!credentials[role]) { const key = KeyPair.fromRandom('ed25519'); credentials[role] = { account_id: `oncefolio-${role}-${suffix}.testnet`, secret_key: key.toString() }; persist(`${directory}/${role}-key.json`, credentials[role]); }
    chmodSync(`${directory}/${role}-key.json`, 0o600);
  }
  const wasm = readFileSync('build/contract.wasm'), source = readFileSync('spike/contract.js');
  const planPath = `${directory}/deployment-plan.json`;
  const previous = existsSync(planPath) ? JSON.parse(readFileSync(planPath, 'utf8')) : null;
  if (previous && (previous.artifact.wasm_sha256 !== sha256(wasm) || previous.artifact.contract_source_sha256 !== sha256(source)) && !refreshArtifact) fail('ARTIFACT_CHANGED_REPREPARE_REQUIRED', 409);
  const environment = await getFingerprint(TESTNET_RPC, 'testnet');
  const protocol = await readRpc(TESTNET_RPC, 'EXPERIMENTAL_protocol_config', { finality: 'final' });
  const block = await readRpc(TESTNET_RPC, 'block', { finality: 'final' });
  const plan = {
    schema_version: 1, created_at: previous?.created_at ?? new Date().toISOString(), network: 'testnet', rpc_url: TESTNET_RPC, faucet_url: TESTNET_FAUCET, environment,
    accounts: Object.fromEntries(Object.entries(credentials).map(([role, credential]) => [role, { account_id: credential.account_id, public_key: KeyPair.fromString(credential.secret_key).getPublicKey().toString() }])),
    artifact: { file: 'build/contract.wasm', wasm_bytes: wasm.length, wasm_sha256: sha256(wasm), wasm_code_hash: baseEncode(createHash('sha256').update(wasm).digest()), contract_source_sha256: sha256(source) },
    budgets: deploymentBudget(protocol, wasm.length, block.header.gas_price),
    actions: ['Create the two fresh accounts through the named faucet if absent, sending public keys only', 'Deploy exactly the reviewed Wasm to the provider account if its code is empty', 'Initialize provider account as its own service provider on network testnet', 'Run at most the reviewed 0.3 test NEAR attached validation deposits separately'],
    prohibited: ['mainnet', 'real-token funding', 'overwriting another contract', 'public repository creation', 'social posting', 'hackathon submission'],
  };
  verifyArtifacts(plan, wasm, source, credentials);
  // The exact public file bytes are the approval boundary, not a hidden mutable config.
  writeFileSync(planPath, planBytes(plan), { mode: 0o600 });
  mkdirSync(outputDirectory, { recursive: true }); writeFileSync(`${outputDirectory}/deployment-plan.json`, planBytes(plan));
  const digest = planHash(plan);
  writeFileSync(`${outputDirectory}/deployment-plan.sha256`, `${digest}\n`);
  return { plan, plan_sha256: digest, artifact_refreshed: Boolean(previous && (previous.artifact.wasm_sha256 !== plan.artifact.wasm_sha256 || previous.artifact.contract_source_sha256 !== plan.artifact.contract_source_sha256)) };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { const result = await prepareTestnet({ refreshArtifact: process.argv.includes('--refresh-artifact') }); console.log(JSON.stringify({ prepared: true, plan_sha256: result.plan_sha256, accounts: result.plan.accounts, artifact: result.plan.artifact, budgets: result.plan.budgets, artifact_refreshed: result.artifact_refreshed }, null, 2)); }
  catch (error) { console.error(JSON.stringify({ error: error.code ?? 'TESTNET_PREPARE_FAILED' })); process.exitCode = 1; }
}
