import { spawnSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync, existsSync, statSync, rmSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { localEnvironment } from './environment.mjs';
import { sourceFiles } from './check.mjs';
mkdirSync('outputs/product', { recursive: true }); mkdirSync('evidence/verification', { recursive: true });
rmSync('outputs/product/result.json', { force: true });
const manifest = JSON.parse(readFileSync('BUILD_VERIFICATION.json'));
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const transcript = { started: new Date().toISOString(), scope: manifest.scope, source_sha256: Object.fromEntries(sourceFiles().map(file => [file, hash(file)])), commands: [] };
let pass = true, totalTests = 0;
for (const command of manifest.commands) {
  if (command.argv[0] !== 'node' || !existsSync(command.definition_file)) throw new Error('Uninspected command definition');
  const argv = [process.execPath, ...command.argv.slice(1)], started = Date.now();
  const result = spawnSync(argv[0], argv.slice(1), { env: localEnvironment(), encoding: 'utf8', timeout: 240000, maxBuffer: 16 * 1024 * 1024 });
  const row = { ...command, argv, started: new Date(started).toISOString(), definition_sha256: hash(command.definition_file), exit_code: result.status, signal: result.signal, error: result.error?.message, stdout: result.stdout ?? '', stderr: result.stderr ?? '' };
  process.stdout.write(row.stdout); process.stderr.write(row.stderr);
  writeFileSync(`outputs/product/${command.name}.log`, row.stdout + row.stderr); transcript.commands.push(row);
  if (result.status !== 0 || result.error) pass = false;
  if (command.expected_tests) {
    const testCount = Number(/^# tests (\d+)$/m.exec(row.stdout)?.[1]), passed = Number(/^# pass (\d+)$/m.exec(row.stdout)?.[1]);
    if (testCount !== command.expected_tests || passed !== testCount || !/^# fail 0$/m.test(row.stdout) || !/^# skipped 0$/m.test(row.stdout)) pass = false;
    totalTests += passed || 0;
  }
  for (const item of manifest.evidence.filter(item => item.produced_by === command.name)) if (!existsSync(item.path) || statSync(item.path).mtimeMs < started || Date.now() - statSync(item.path).mtimeMs > item.max_age_hours * 3600000) pass = false;
  writeFileSync('evidence/verification/command-transcript.json', JSON.stringify(transcript, null, 2));
  if (!pass) break;
}
if (pass) {
  const auth = JSON.parse(readFileSync('outputs/product/authorization.json')), runtime = JSON.parse(readFileSync('outputs/product/runtime.json')), demo = JSON.parse(readFileSync('outputs/product/demo.json')), migrations = JSON.parse(readFileSync('outputs/product/migration-state.json'));
  if (!auth.unauthenticated_denied || !auth.wrong_role_denied || !auth.cross_object_denied || runtime.assertions.length !== 7 || !demo.pass || migrations.open_recovery_findings.length) pass = false;
  for (const [path, digest] of Object.entries(transcript.source_sha256)) if (hash(path) !== digest) pass = false;
}
transcript.pass = pass; transcript.completed = new Date().toISOString(); transcript.tests_passed = totalTests;
writeFileSync('evidence/verification/command-transcript.json', JSON.stringify(transcript, null, 2));
writeFileSync('outputs/product/result.json', JSON.stringify({ pass, completed: transcript.completed, tests_passed: totalTests, commands: transcript.commands.map(c => ({ name: c.name, exit_code: c.exit_code })), limitations: ['Local sandbox only; no testnet/mainnet deployment', 'No browser UI', 'Provider full-access key is an administrative trust boundary', 'No automatic service-failure refunds'] }, null, 2));
writeFileSync('BUILD_STATE.json', JSON.stringify({ generated: transcript.completed, scope: manifest.scope, status: pass ? 'PASS' : 'FAIL', repository_revision: null, repository_note: 'No project Git repository or public publication created', source_sha256: transcript.source_sha256, commands: transcript.commands.map(c => ({ argv: c.argv, definition_file: c.definition_file, exit_code: c.exit_code })), evidence: manifest.evidence, migration_state: existsSync('outputs/product/migration-state.json') ? JSON.parse(readFileSync('outputs/product/migration-state.json')) : null, open_findings: ['Testnet deployment unverified and not authorized', 'macOS ARM64 toolchain only', 'Commercial failure remedy and data retention are release decisions'] }, null, 2));
console.log(`Local MVP verification: ${pass ? 'PASS' : 'FAIL'} (${totalTests} tests passed).`);
process.exitCode = pass ? 0 : 1;
