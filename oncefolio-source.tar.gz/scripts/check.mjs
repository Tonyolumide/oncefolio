import { readdirSync, readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
export function sourceFiles() {
  const files = ['oncefolio', 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'BUILD_VERIFICATION.json'];
  for (const directory of ['app', 'scripts', 'tests', 'migrations', 'spike']) {
    const walk = path => { for (const item of readdirSync(path, { withFileTypes: true })) { const name = join(path, item.name); if (item.isDirectory()) walk(name); else if (/\.(mjs|js|sql|json)$/.test(name) && !name.endsWith('BUILD_STATE.json')) files.push(name); } };
    walk(directory);
  }
  return files.sort();
}
if (process.argv[1]?.endsWith('/check.mjs')) {
  const failures = [], files = sourceFiles();
  for (const file of files) {
    const content = readFileSync(file, 'utf8');
    if (/\.(mjs|js)$/.test(file)) { const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' }); if (result.status !== 0) failures.push({ file, code: 'SYNTAX', error: result.stderr }); }
    if (file === 'oncefolio') { const result = spawnSync('/bin/sh', ['-n', file], { encoding: 'utf8' }); if (result.status !== 0) failures.push({ file, code: 'SHELL_SYNTAX', error: result.stderr }); }
    if (/['"]ed25519:[1-9A-HJ-NP-Za-km-z]{80,}['"]/.test(content) || /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/.test(content)) failures.push({ file, code: 'EMBEDDED_PRIVATE_KEY' });
  }
  const pkg = JSON.parse(readFileSync('package.json'));
  if (!Object.values(pkg.devDependencies).every(version => /^\d+\.\d+\.\d+$/.test(version))) failures.push({ code: 'UNPINNED_DEPENDENCY' });
  mkdirSync('outputs/product', { recursive: true });
  writeFileSync('outputs/product/static-check.json', JSON.stringify({ pass: !failures.length, completed: new Date().toISOString(), files_checked: files.length, checks: ['JavaScript syntax', 'embedded signing-key scan', 'exact direct dependency pins'], failures }, null, 2));
  console.log(`${files.length} source files checked; ${failures.length} failures.`);
  process.exitCode = failures.length ? 1 : 0;
}
