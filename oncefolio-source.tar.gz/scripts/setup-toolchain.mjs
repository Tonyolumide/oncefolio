import { readFileSync, existsSync, mkdirSync, realpathSync, symlinkSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';

if (process.platform !== 'darwin' || process.arch !== 'arm64') throw new Error('This spike toolchain is pinned for macOS ARM64 only. Other platforms are not verified.');
const lock = JSON.parse(readFileSync('spike/toolchain-lock.json'));
mkdirSync('work/toolchain', { recursive: true });
for (const item of lock.artifacts) {
  const path = resolve('work/toolchain', item.file);
  const valid = () => existsSync(path) && createHash('sha256').update(readFileSync(path)).digest('hex') === item.sha256;
  if (!valid()) {
    console.log(`Downloading ${item.file}`);
    const response = await fetch(item.url);
    if (!response.ok) throw new Error(`Download failed: ${response.status}`);
    writeFileSync(path, Buffer.from(await response.arrayBuffer()));
  }
  if (!valid()) throw new Error(`Checksum mismatch: ${item.file}`);
  if (item.extract) {
    mkdirSync(item.extract, { recursive: true });
    execFileSync('/usr/bin/tar', ['-xzf', path, '-C', item.extract]);
  }
}
execFileSync('/bin/chmod', ['+x', 'work/toolchain/qjsc']);
const deps = `${realpathSync('node_modules/near-sdk-js')}/lib/cli/deps`;
mkdirSync(deps, { recursive: true });
for (const [name, target] of Object.entries(lock.sdkLinks)) {
  const path = `${deps}/${name}`;
  if (!existsSync(path)) symlinkSync(resolve(target), path);
  if (realpathSync(path) !== realpathSync(target)) throw new Error(`Unexpected SDK dependency link: ${name}`);
}
console.log('Pinned local toolchain ready. No global installation performed.');
