import { readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { Store } from '../app/store.mjs';
import { fingerprint } from '../app/near.mjs';
const config = process.argv[2] ? JSON.parse(readFileSync(process.argv[2], 'utf8')) : { dbPath: 'work/bootstrap/schema.sqlite', environment: 'offline-schema-check-v1', contractId: 'schema-check.local' };
if (config.rpcUrl && await fingerprint(config.rpcUrl) !== config.environment) throw new Error('ENVIRONMENT_MISMATCH');
const store = new Store(config.dbPath, config);
try {
  const state = store.migrationState();
  mkdirSync('outputs/product', { recursive: true });
  writeFileSync('outputs/product/migration-state.json', JSON.stringify(state, null, 2));
  console.log(JSON.stringify({ bootstrap: 'ready', schema_fingerprint: state.schema_fingerprint, migrations: state.applied_migrations.length }));
} finally { store.close(); }
