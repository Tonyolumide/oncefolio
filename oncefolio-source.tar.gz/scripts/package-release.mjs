import { readdirSync, readFileSync, existsSync, mkdirSync, writeFileSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';

mkdirSync('outputs/release', { recursive: true });
const roots = ['app', 'scripts', 'tests', 'migrations', 'examples', 'spike', 'flows', 'verification'];
const files = ['oncefolio', 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', '.gitignore', '.env.example', 'README.md', 'AGENTS.md', 'SECURITY.md', 'BACKEND_SETUP.md', 'TESTNET_RUNBOOK.md', 'PROJECT_BRIEF.md', 'BUILD_PLAN.md', 'BUILD_VERIFICATION.json', 'CONTEXT.md', '00_Brief_Analysis.md', '00_Source_Inventory.md', '00_Flow_Map.md', '00_Flow_Contracts.md', 'CLIENT_QUESTIONS.md', 'BUILD_AGENT.md', 'BUILD_PROMPT.txt'];
if (existsSync('LICENSE')) files.push('LICENSE');
for (const root of roots) {
  const walk = path => { for (const item of readdirSync(path, { withFileTypes: true })) {
    const file = join(path, item.name);
    if (item.isSymbolicLink()) throw new Error(`Refusing release symlink: ${file}`);
    if (item.isDirectory()) walk(file);
    else if (!file.endsWith('BUILD_STATE.json') && !file.endsWith('.DS_Store')) files.push(file);
  } };
  walk(root);
}
const manifest = files.sort().map(path => {
  const content = readFileSync(path);
  if (/(?:['"]ed25519:[1-9A-HJ-NP-Za-km-z]{80,}['"]|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)/.test(content.toString())) throw new Error(`Possible embedded private key: ${path}`);
  if (!lstatSync(path).isFile()) throw new Error(`Not a regular file: ${path}`);
  return { path, bytes: content.length, sha256: createHash('sha256').update(content).digest('hex') };
});
const archive = 'outputs/release/oncefolio-source.tar.gz';
execFileSync('/usr/bin/tar', ['--uid', '0', '--gid', '0', '--uname', 'root', '--gname', 'root', '-czf', archive, ...files], { env: { ...process.env, COPYFILE_DISABLE: '1' } });
writeFileSync('outputs/release/source-manifest.json', JSON.stringify({ created: new Date().toISOString(), archive, archive_sha256: createHash('sha256').update(readFileSync(archive)).digest('hex'), files: manifest, omitted: ['work/', 'node_modules/', 'build/', 'outputs/', '.git/', 'credentials, databases and signed intents'], license: existsSync('LICENSE') ? 'Included; inspect LICENSE' : 'Not selected — publication approval pending', publication_status: 'Prepared locally; no repository created or pushed' }, null, 2));
console.log(`Prepared ${manifest.length} source files; no work directory, keys, database, native binaries or build outputs included.`);
