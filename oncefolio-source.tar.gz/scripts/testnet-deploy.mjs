import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { Account, actions, baseEncode } from 'near-api-js';
import { rpc, StrictJsonRpcProvider } from '../app/rpc.mjs';
import { fingerprint } from '../app/near.mjs';
import { persist } from '../spike/client.mjs';
import { fail } from '../app/errors.mjs';
import { TESTNET_DIRECTORY, TESTNET_RPC, TESTNET_FAUCET, validatePlan, verifyArtifacts, planBytes, planHash, deploymentBudget } from './testnet-prepare.mjs';

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const EMPTY_CODE = '11111111111111111111111111111111';

export function assertExecutionApproval(plan, approvedHash, execute) {
  validatePlan(plan);
  if (execute && (!/^[0-9a-f]{64}$/.test(approvedHash ?? '') || approvedHash !== planHash(plan))) fail('EXACT_PLAN_APPROVAL_REQUIRED', 409);
  if (approvedHash && approvedHash !== planHash(plan)) fail('REVIEWED_PLAN_CHANGED', 409);
  return Boolean(execute);
}

export function loadDeploymentInputs(directory = TESTNET_DIRECTORY) {
  const rawPlan = readFileSync(`${directory}/deployment-plan.json`, 'utf8');
  const plan = JSON.parse(rawPlan); validatePlan(plan);
  if (rawPlan !== planBytes(plan)) fail('NONCANONICAL_PLAN_FORMAT', 409);
  const credentials = Object.fromEntries(['provider', 'buyer'].map(role => [role, JSON.parse(readFileSync(`${directory}/${role}-key.json`, 'utf8'))]));
  const wasm = readFileSync('build/contract.wasm'), source = readFileSync('spike/contract.js');
  verifyArtifacts(plan, wasm, source, credentials);
  return { plan, credentials, wasm };
}

function isUnknownAccount(error) { return /UNKNOWN_ACCOUNT/.test(error.message); }

async function accountState(plan, role, readRpc = rpc) {
  const account = plan.accounts[role];
  let state;
  try { state = await readRpc(TESTNET_RPC, 'query', { request_type: 'view_account', finality: 'final', account_id: account.account_id }); }
  catch (error) { if (isUnknownAccount(error)) return null; throw error; }
  let key;
  try { key = await readRpc(TESTNET_RPC, 'query', { request_type: 'view_access_key', finality: 'final', account_id: account.account_id, public_key: account.public_key }); }
  catch { fail('ACCOUNT_KEY_MISMATCH', 409); }
  if (key.permission !== 'FullAccess') fail('ACCOUNT_KEY_MISMATCH', 409);
  return state;
}

async function contractConfig(plan, readRpc = rpc) {
  try {
    const response = await readRpc(TESTNET_RPC, 'query', { request_type: 'call_function', finality: 'final', account_id: plan.accounts.provider.account_id, method_name: 'get_config', args_base64: 'e30=' });
    return JSON.parse(Buffer.from(response.result).toString());
  } catch (error) { if (/NOT_INITIALIZED/.test(error.message)) return null; throw error; }
}

export async function testnetPreflight(inputs, { readRpc = rpc, getFingerprint = fingerprint } = {}) {
  const { plan } = inputs; validatePlan(plan);
  if (await getFingerprint(TESTNET_RPC, 'testnet') !== plan.environment) fail('ENVIRONMENT_MISMATCH', 409);
  const protocol = await readRpc(TESTNET_RPC, 'EXPERIMENTAL_protocol_config', { finality: 'final' });
  const block = await readRpc(TESTNET_RPC, 'block', { finality: 'final' });
  const liveBudget = deploymentBudget(protocol, inputs.wasm.length, block.header.gas_price);
  if (liveBudget.storage_amount_per_byte !== plan.budgets.storage_amount_per_byte || BigInt(liveBudget.provider_minimum_balance_yoctonear) > BigInt(plan.budgets.provider_minimum_balance_yoctonear) || BigInt(liveBudget.buyer_minimum_balance_yoctonear) > BigInt(plan.budgets.buyer_minimum_balance_yoctonear)) fail('LIVE_COST_EXCEEDS_REVIEWED_PLAN', 409);
  const accounts = {};
  for (const role of ['provider', 'buyer']) {
    const state = await accountState(plan, role, readRpc);
    const minimum = BigInt(plan.budgets[`${role}_minimum_balance_yoctonear`]);
    if (state && BigInt(state.amount) < minimum) fail('INSUFFICIENT_TESTNET_FUNDS', 409);
    accounts[role] = { account_id: plan.accounts[role].account_id, exists: Boolean(state), state };
  }
  const provider = accounts.provider.state;
  if (provider && provider.code_hash !== EMPTY_CODE && provider.code_hash !== plan.artifact.wasm_code_hash) fail('EXISTING_CONTRACT_NOT_REVIEWED', 409);
  let config = null;
  if (provider?.code_hash === plan.artifact.wasm_code_hash) {
    config = await contractConfig(plan, readRpc);
    if (config && (config.provider !== plan.accounts.provider.account_id || config.network !== 'testnet')) fail('EXISTING_CONFIG_MISMATCH', 409);
  }
  return { network: 'testnet', environment: plan.environment, plan_sha256: planHash(plan), accounts, config, live_budget: liveBudget };
}

function safeOutcome(outcome) {
  const result = JSON.parse(JSON.stringify(outcome));
  for (const action of result.transaction?.actions ?? []) if (action.DeployContract?.code) action.DeployContract = { code: '[omitted; exact reviewed Wasm hash is recorded in the plan]' };
  return result;
}

export async function deployTestnet({ directory = TESTNET_DIRECTORY, execute = false, approvedHash } = {}) {
  directory = resolve(directory);
  const inputs = loadDeploymentInputs(directory), { plan, credentials, wasm } = inputs;
  assertExecutionApproval(plan, approvedHash, execute);
  const preflight = await testnetPreflight(inputs);
  mkdirSync('outputs/testnet', { recursive: true });
  writeFileSync('outputs/testnet/preflight.json', JSON.stringify({ ...preflight, execute_requested: execute, checked_at: new Date().toISOString() }, null, 2));
  if (!execute) return { preflight: true, plan_sha256: planHash(plan), mutations_performed: false, accounts: preflight.accounts };

  const receipt = { started: new Date().toISOString(), network: 'testnet', environment: plan.environment, plan_sha256: planHash(plan), artifact: plan.artifact, faucet_calls: [], actions: [] };
  for (const role of ['provider', 'buyer']) {
    if (await accountState(plan, role)) continue;
    let responseStatus;
    try {
      const response = await fetch(TESTNET_FAUCET, { method: 'POST', redirect: 'error', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ newAccountId: plan.accounts[role].account_id, newAccountPublicKey: plan.accounts[role].public_key }), signal: AbortSignal.timeout(20000) });
      responseStatus = response.status;
    } catch { responseStatus = 'response_unavailable'; }
    let created = false;
    for (let i = 0; i < 20; i++) { const state = await accountState(plan, role); if (state) { created = true; break; } await wait(1000); }
    receipt.faucet_calls.push({ role, account_id: plan.accounts[role].account_id, response_status: responseStatus, verified_final_account_and_key: created });
    if (!created) fail('FAUCET_ACCOUNT_NOT_CONFIRMED', 503);
  }
  await testnetPreflight(inputs); // Balance/storage and network checks after faucet, before any signing.
  const provider = new Account(plan.accounts.provider.account_id, new StrictJsonRpcProvider(TESTNET_RPC), credentials.provider.secret_key);
  mkdirSync(`${directory}/transactions`, { recursive: true, mode: 0o700 });

  async function signedAction(name, action, reconciled) {
    if (await reconciled()) { receipt.actions.push({ name, recovered_existing_state: true }); return; }
    const file = `${directory}/transactions/${name}.json`;
    let pending = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : null;
    if (pending && (pending.plan_sha256 !== planHash(plan) || pending.action !== name || pending.signer !== plan.accounts.provider.account_id)) fail('PENDING_DEPLOYMENT_PLAN_MISMATCH', 409);
    let nextAttempt = pending?.attempt_number ?? 1;
    if (!Number.isInteger(nextAttempt) || nextAttempt < 1 || nextAttempt > plan.budgets.max_signed_attempts_per_action) fail('DEPLOYMENT_ATTEMPT_LIMIT', 409);
    for (let attempt = 0; attempt < 2; attempt++) {
      if (!pending) {
        if (await fingerprint(TESTNET_RPC, 'testnet') !== plan.environment) fail('ENVIRONMENT_MISMATCH', 409);
        const signed = await provider.createSignedTransaction({ receiverId: plan.accounts.provider.account_id, actions: [action] });
        pending = { plan_sha256: planHash(plan), action: name, signer: plan.accounts.provider.account_id, attempt_number: nextAttempt, tx_hash: baseEncode(createHash('sha256').update(signed.transaction.encode()).digest()), signed_tx_base64: Buffer.from(signed.encode()).toString('base64') };
        persist(file, pending);
      }
      try {
        const outcome = await rpc(TESTNET_RPC, 'send_tx', { signed_tx_base64: pending.signed_tx_base64, wait_until: 'FINAL' });
        receipt.actions.push({ name, tx_hash: pending.tx_hash, outcome: safeOutcome(outcome) });
        if (outcome.status.Failure) fail('DEPLOYMENT_ACTION_REJECTED', 409);
      } catch (error) {
        if (await reconciled()) { receipt.actions.push({ name, tx_hash: pending.tx_hash, recovered_after_ambiguous_response: true }); return; }
        if (/InvalidNonce|Expired|INVALID_NONCE|EXPIRED_TRANSACTION/.test(error.message) && attempt === 0) {
          nextAttempt = (pending.attempt_number ?? 1) + 1;
          if (nextAttempt > plan.budgets.max_signed_attempts_per_action) fail('DEPLOYMENT_ATTEMPT_LIMIT', 409);
          persist(`${file}.previous`, pending); pending = null; continue;
        }
        throw error;
      }
      if (!await reconciled()) fail('DEPLOYMENT_STATE_NOT_CONFIRMED', 503);
      return;
    }
    fail('DEPLOYMENT_ATTEMPT_LIMIT', 409);
  }

  await signedAction('deploy', actions.deployContract(wasm), async () => {
    const state = await accountState(plan, 'provider');
    if (state.code_hash !== EMPTY_CODE && state.code_hash !== plan.artifact.wasm_code_hash) fail('EXISTING_CONTRACT_NOT_REVIEWED', 409);
    return state.code_hash === plan.artifact.wasm_code_hash;
  });
  await signedAction('init', actions.functionCall('init', { provider: plan.accounts.provider.account_id, network: 'testnet' }, BigInt(plan.budgets.function_call_gas), 0n), async () => {
    const config = await contractConfig(plan);
    if (!config) return false;
    if (config.provider !== plan.accounts.provider.account_id || config.network !== 'testnet') fail('EXISTING_CONFIG_MISMATCH', 409);
    return true;
  });
  const runtime = { network: 'testnet', rpcUrl: TESTNET_RPC, environment: plan.environment, contractId: plan.accounts.provider.account_id, providerKeyFile: `${directory}/provider-key.json`, buyerKeyFile: `${directory}/buyer-key.json`, dbPath: `${directory}/provider.sqlite`, apiPort: 8788, serviceUrl: 'http://127.0.0.1:8788', workerLeaseMs: 5000 };
  persist(`${directory}/runtime.json`, runtime);
  receipt.completed = new Date().toISOString(); receipt.config = await contractConfig(plan); receipt.accounts = Object.fromEntries(['provider', 'buyer'].map(role => [role, plan.accounts[role].account_id]));
  receipt.verified = true;
  writeFileSync('outputs/testnet/deployment.json', JSON.stringify(receipt, null, 2));
  return { deployed: true, contract_id: runtime.contractId, plan_sha256: planHash(plan), runtime_file: `${directory}/runtime.json` };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const index = process.argv.indexOf('--plan-sha256');
  try { console.log(JSON.stringify(await deployTestnet({ execute: process.argv.includes('--execute'), approvedHash: index >= 0 ? process.argv[index + 1] : undefined }), null, 2)); }
  catch (error) { console.error(JSON.stringify({ error: error.code ?? 'TESTNET_DEPLOY_FAILED', mutations_may_be_pending: process.argv.includes('--execute') })); process.exitCode = 1; }
}
