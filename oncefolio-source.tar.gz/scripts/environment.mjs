import { dirname, resolve, join } from 'node:path';
import { homedir } from 'node:os';
import { existsSync } from 'node:fs';

export function localEnvironment() {
  const env = { ...process.env, PATH: `${dirname(process.execPath)}:${process.env.PATH}`, NEAR_SANDBOX_BIN_PATH: resolve('work/toolchain/Darwin-arm64/near-sandbox') };
  const bundledLib = join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/poppler/lib');
  const lib = process.env.ONCEFOLIO_NATIVE_LIB_DIR ?? (existsSync(`${bundledLib}/liblzma.5.dylib`) ? bundledLib : undefined);
  if (lib) env.DYLD_FALLBACK_LIBRARY_PATH = lib;
  return env;
}
