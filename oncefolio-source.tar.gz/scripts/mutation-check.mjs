import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { localEnvironment } from './environment.mjs';
const path = 'spike/contract.js';
const original = readFileSync(path, 'utf8');
const target = "throw new Error('DUPLICATE_PURCHASE');";
if (original.split(target).length !== 2) throw new Error('Mutation target must match exactly once');
mkdirSync('outputs/feasibility', { recursive: true });
let build, tests;
try {
  writeFileSync(path, original.replace(target, 'reply(old); return; // Deliberately incorrect: retains a duplicate deposit.'));
  build = spawnSync(process.execPath, ['scripts/build.mjs'], { env: localEnvironment(), encoding: 'utf8', timeout: 60000 });
  if (build.status !== 0) throw new Error(`Mutation did not compile: ${build.stderr}`);
  tests = spawnSync(process.execPath, ['--test', '--test-reporter=tap', 'spike/feasibility.test.mjs'], { env: localEnvironment(), encoding: 'utf8', timeout: 240000 });
  const detected = tests.status !== 0 && /two buyer keys race[\s\S]*?2 !== 1/.test(tests.stdout);
  writeFileSync('outputs/feasibility/mutation.log', `${tests.stdout}${tests.stderr}`);
  writeFileSync('outputs/feasibility/mutation.json', JSON.stringify({ detected, build_exit_code: build.status, test_exit_code: tests.status, fault: 'Duplicate path returns success and retains second deposit', source_restored: true }, null, 2));
  if (!detected) throw new Error('Regression test did not detect the duplicate-acceptance mutation');
  console.log('Mutation detected: duplicate acceptance fails the concurrency test. Source restored; rebuild required.');
} finally {
  writeFileSync(path, original);
}
