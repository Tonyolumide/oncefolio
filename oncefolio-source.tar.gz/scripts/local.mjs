import { spawn, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { readFileSync, existsSync, mkdirSync, chmodSync, openSync, closeSync } from 'node:fs';
import { resolve } from 'node:path';
import net from 'node:net';
import { Account, JsonRpcProvider, KeyPair, nearToYocto, baseEncode, actions } from 'near-api-js';
import { createHash } from 'node:crypto';
import { localEnvironment } from './environment.mjs';
import { rpc, persist } from '../spike/client.mjs';
import { NearGateway, fingerprint } from '../app/near.mjs';
import { createService } from '../app/server.mjs';
import { fail } from '../app/errors.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function freePort() {
  const socket = net.createServer(); socket.listen(0, '127.0.0.1'); await once(socket, 'listening');
  const port = socket.address().port; await new Promise(r => socket.close(r)); return port;
}
async function stop(child) {
  if (!child || child.exitCode !== null || child.signalCode !== null) return;
  const done = once(child, 'exit'); child.kill('SIGTERM'); await done;
}

export async function startLocal({ directory = resolve('work/local'), apiPort = 8787, worker = true } = {}) {
  const env = localEnvironment();
  directory = resolve(directory); mkdirSync(directory, { recursive: true, mode: 0o700 }); chmodSync(directory, 0o700);
  const chainDir = `${directory}/chain`; mkdirSync(chainDir, { recursive: true, mode: 0o700 });
  const portsFile = `${directory}/ports.json`;
  const ports = existsSync(portsFile) ? JSON.parse(readFileSync(portsFile, 'utf8')) : { rpcPort: await freePort(), netPort: await freePort() };
  if (!existsSync(portsFile)) persist(portsFile, ports);
  const { rpcPort, netPort } = ports;
  if (!existsSync(`${chainDir}/genesis.json`)) {
    const init = spawnSync(env.NEAR_SANDBOX_BIN_PATH, ['--home', chainDir, 'init', '--fast'], { env, encoding: 'utf8', timeout: 30000 });
    if (init.status !== 0) fail('LOCAL_CHAIN_INIT_FAILED', 500);
  }
  for (const name of ['validator_key.json', 'node_key.json']) if (existsSync(`${chainDir}/${name}`)) chmodSync(`${chainDir}/${name}`, 0o600);
  const logFd = openSync(`${directory}/chain.log`, 'a', 0o600);
  const node = spawn(env.NEAR_SANDBOX_BIN_PATH, ['--home', chainDir, 'run', '--rpc-addr', `127.0.0.1:${rpcPort}`, '--network-addr', `127.0.0.1:${netPort}`], { env, stdio: ['ignore', logFd, logFd] });
  closeSync(logFd);
  let service, workerProcess;
  const close = async () => { await stop(workerProcess); if (service) await service.close(); await stop(node); };
  try {
    const rpcUrl = `http://127.0.0.1:${rpcPort}`;
    let ready = false;
    for (let i = 0; i < 200; i++) { if (node.exitCode !== null) fail('LOCAL_CHAIN_START_FAILED', 500); try { await rpc(rpcUrl, 'status', []); ready = true; break; } catch { await sleep(100); } }
    if (!ready) fail('LOCAL_CHAIN_START_TIMEOUT', 500);
    const environment = await fingerprint(rpcUrl);
    const provider = new JsonRpcProvider({ url: rpcUrl });
    const rootKey = JSON.parse(readFileSync(`${chainDir}/validator_key.json`, 'utf8'));
    const root = new Account(rootKey.account_id, provider, rootKey.secret_key);
    const credentials = {};
    for (const role of ['provider', 'buyer']) {
      const keyPath = `${directory}/${role}-key.json`;
      const account_id = `${role}.${rootKey.account_id}`;
      let existing;
      try { existing = await rpc(rpcUrl, 'query', { request_type: 'view_account', account_id, finality: 'final' }); } catch (error) { if (!String(error.message).includes('UNKNOWN_ACCOUNT')) throw error; }
      if (existsSync(keyPath)) credentials[role] = JSON.parse(readFileSync(keyPath, 'utf8'));
      else {
        if (existing) fail('LOCAL_CREDENTIALS_MISSING', 409);
        const key = KeyPair.fromRandom('ed25519'); credentials[role] = { account_id, secret_key: key.toString() }; persist(keyPath, credentials[role]);
      }
      if (!existing) await root.signAndSendTransaction({ receiverId: account_id, actions: [actions.createAccount(), actions.addFullAccessKey(KeyPair.fromString(credentials[role].secret_key).getPublicKey()), actions.transfer(nearToYocto('100'))], waitUntil: 'FINAL' });
    }
    const contractId = credentials.provider.account_id;
    const account = new Account(contractId, provider, credentials.provider.secret_key);
    const wasm = readFileSync('build/contract.wasm');
    const state = await rpc(rpcUrl, 'query', { request_type: 'view_account', account_id: contractId, finality: 'final' });
    const codeHash = baseEncode(createHash('sha256').update(wasm).digest());
    if (state.code_hash === '11111111111111111111111111111111') await account.signAndSendTransaction({ receiverId: contractId, actions: [actions.deployContract(wasm)], waitUntil: 'FINAL' });
    else if (state.code_hash !== codeHash) fail('LOCAL_CONTRACT_VERSION_MISMATCH', 409);
    const configState = await rpc(rpcUrl, 'query', { request_type: 'view_state', account_id: contractId, finality: 'final', prefix_base64: Buffer.from('config').toString('base64') });
    if (!configState.values.length) await account.callFunctionRaw({ contractId, methodName: 'init', args: { provider: contractId }, waitUntil: 'FINAL' });
    const runtime = { rpcUrl, environment, contractId, dbPath: `${directory}/provider.sqlite`, providerKeyFile: `${directory}/provider-key.json`, buyerKeyFile: `${directory}/buyer-key.json`, apiPort, workerLeaseMs: 5000 };
    const near = new NearGateway({ ...runtime, providerKey: credentials.provider.secret_key });
    service = await createService({ dbPath: runtime.dbPath, near, port: apiPort });
    runtime.serviceUrl = service.origin;
    const configPath = `${directory}/runtime.json`; persist(configPath, runtime);
    if (worker) workerProcess = spawn(process.execPath, ['app/worker.mjs', configPath], { env, stdio: ['ignore', 'ignore', 'inherit'] });
    return { ...runtime, configPath, service, credentials, close };
  } catch (error) { await close(); throw error; }
}
