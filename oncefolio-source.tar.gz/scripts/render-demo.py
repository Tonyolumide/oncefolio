"""Render an actual asciicast capture; frames are terminal output, not synthetic actions."""
import json
import math
import pathlib
import re
import subprocess
from PIL import Image, ImageDraw, ImageFont

root = pathlib.Path(__file__).resolve().parents[1]
capture = [json.loads(line) for line in (root / 'outputs/release/oncefolio-local-demo.cast').read_text().splitlines()]
events = capture[1:]
encoder = next((root / 'work/toolchain/ffmpeg').glob('ffmpeg-*'))
output = root / 'outputs/release/oncefolio-local-demo.mp4'
font = ImageFont.truetype('/System/Library/Fonts/Menlo.ttc', 20)
small = ImageFont.truetype('/System/Library/Fonts/Menlo.ttc', 16)
title = ImageFont.truetype('/System/Library/Fonts/Menlo.ttc', 25)
fps, speed = 12, 3.5
# Preserve the raw capture separately; trim idle setup and pace actual output for viewing.
first_output = events[1][0] if len(events) > 1 else 0
paced = [events[0]]
previous = 0
for event in events[1:]:
    shown_at = max(0.5 + (event[0] - first_output) * speed, previous + 2)
    paced.append([shown_at, event[1], event[2]])
    previous = shown_at
events = paced
duration = max(15, events[-1][0] + 6)
command = [str(encoder), '-y', '-loglevel', 'error', '-f', 'rawvideo', '-vcodec', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1600x1000', '-r', str(fps), '-i', '-', '-an', '-c:v', 'libx264', '-preset', 'fast', '-crf', '20', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(output)]
process = subprocess.Popen(command, stdin=subprocess.PIPE)
index, transcript = 0, ''
for frame in range(math.ceil(duration * fps)):
    moment = frame / fps
    while index < len(events) and events[index][0] <= moment:
        transcript += events[index][2]
        index += 1
    image = Image.new('RGB', (1600, 1000), '#0b1018')
    draw = ImageDraw.Draw(image)
    draw.text((48, 28), 'ONCEFOLIO', font=title, fill='#e6edf6')
    draw.rounded_rectangle((1240, 24, 1550, 64), radius=9, fill='#263423')
    draw.text((1258, 33), 'LOCAL NEAR SANDBOX', font=small, fill='#c3e4a0')
    draw.text((48, 79), 'Pay → lose response → restart → recover purchase and result', font=font, fill='#96a5ba')
    draw.rounded_rectangle((36, 130, 1564, 925), radius=14, fill='#141d2a', outline='#26364b', width=2)
    clean = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', transcript).replace('\r', '')
    all_lines = clean.split('\n')
    milestones = [line for line in all_lines if re.match(r'^[1-4]\. ', line)]
    draw.text((61, 150), '$ ./oncefolio demo', font=font, fill='#e2e8f0')
    for row, line in enumerate(milestones):
        draw.text((61, 187 + row * 27), line[:120], font=font, fill='#a4e7b1')
    draw.line((61, 310, 1539, 310), fill='#26364b', width=2)
    lines = [line for line in all_lines if not re.match(r'^[1-4]\. ', line) and not line.startswith('$ ')][-24:]
    for row, line in enumerate(lines):
        color = '#a4e7b1' if re.match(r'^[1-4]\. ', line) else '#e2e8f0'
        draw.text((61, 333 + row * 23), line[:120], font=font, fill=color)
    draw.text((48, 954), 'Actual CLI capture · replay paced for readability · testnet deployment pending approval', font=small, fill='#899ab0')
    process.stdin.write(image.tobytes())
    if frame == math.ceil(duration * fps) - 1:
        image.save(root / 'outputs/release/demo-poster.png')
process.stdin.close()
if process.wait() != 0:
    raise RuntimeError('Video encoding failed')
metadata = json.loads((root / 'outputs/release/recording.json').read_text())
metadata.update({'video_seconds': duration, 'video': output.name, 'codec': 'H.264', 'resolution': '1600x1000', 'source_capture': 'oncefolio-local-demo.cast'})
(root / 'outputs/release/recording.json').write_text(json.dumps(metadata, indent=2))
print(output)
