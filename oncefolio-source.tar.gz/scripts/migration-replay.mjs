import { mkdtempSync, rmSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import { Store } from '../app/store.mjs';
const directory = mkdtempSync(join(tmpdir(), 'oncefolio-replay-'));
try {
  const states = [];
  for (const name of ['a', 'b']) { const store = new Store(join(directory, name, 'db.sqlite'), { environment: 'offline-schema-check-v1', contractId: 'schema-check.local' }); states.push(store.migrationState()); store.close(); }
  assert.equal(states[0].schema_fingerprint, states[1].schema_fingerprint);
  assert.deepEqual(states[0].tracked_migrations, states[1].tracked_migrations);
  mkdirSync('outputs/product', { recursive: true });
  writeFileSync('outputs/product/migration-replay.json', JSON.stringify({ pass: true, ...states[0], independent_databases: 2 }, null, 2));
  console.log('Migrations replay identically from two empty databases.');
} finally { rmSync(directory, { recursive: true, force: true }); }
