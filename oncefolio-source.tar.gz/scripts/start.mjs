import { startLocal } from './local.mjs';
try {
  const runtime = await startLocal({ directory: process.argv[2] });
  console.log(`Oncefolio is ready at ${runtime.serviceUrl}`);
  console.log(`Buyer config: ${runtime.configPath}`);
  console.log('Buy: ./oncefolio buy work/local/my-purchase.json examples/request.json');
  console.log('Resume: ./oncefolio recover work/local/my-purchase.json');
  let stopping = false;
  const stop = async () => { if (stopping) return; stopping = true; await runtime.close(); process.exit(0); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
} catch (error) { console.error(JSON.stringify({ error: error.code ?? 'START_FAILED' })); process.exitCode = 1; }
