import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { once } from 'node:events';

mkdirSync('outputs/release', { recursive: true });
const start = performance.now(), frames = [];
frames.push([0, 'o', '$ ./oncefolio demo\r\n']);
const child = spawn('./oncefolio', ['demo'], { stdio: ['ignore', 'pipe', 'pipe'] });
for (const stream of [child.stdout, child.stderr]) stream.on('data', chunk => {
  const text = chunk.toString().replace(/\r?\n/g, '\r\n');
  frames.push([(performance.now() - start) / 1000, 'o', text]);
  process.stdout.write(chunk);
});
const [code] = await once(child, 'exit');
if (code !== 0) throw new Error('DEMO_RECORDING_FAILED');
const header = { version: 2, width: 110, height: 34, timestamp: Math.floor(Date.now() / 1000), title: 'Oncefolio — real local sandbox run', env: { TERM: 'xterm-256color' } };
writeFileSync('outputs/release/oncefolio-local-demo.cast', [header, ...frames].map(x => JSON.stringify(x)).join('\n') + '\n');
writeFileSync('outputs/release/recording.json', JSON.stringify({ recorded: new Date().toISOString(), command: './oncefolio demo', exit_code: code, duration_seconds: (performance.now() - start) / 1000, network: 'local NEAR sandbox', footage: 'Terminal output captured from actual execution; MP4 renders this capture with slower playback for readability', events: frames.length }, null, 2));
