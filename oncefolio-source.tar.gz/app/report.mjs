import { createHash } from 'node:crypto';

const MAX_BYTES = 128 * 1024;
const TOP_FIELDS = new Set(['rows', 'required_fields', 'unique_fields', 'field_types']);
const RESERVED = new Set(['__proto__', 'constructor', 'prototype']);
const TYPES = new Set(['string', 'number', 'boolean']);
const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

function invalid(message) {
  const error = new Error(message);
  error.code = 'INVALID_REQUEST';
  error.status = 400;
  throw error;
}

function plain(value) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return (prototype === Object.prototype || prototype === null) && Object.getOwnPropertySymbols(value).length === 0;
}

function fieldName(value) {
  return typeof value === 'string' && /^[a-zA-Z][a-zA-Z0-9_]{0,63}$/.test(value) && !RESERVED.has(value);
}

function primitive(value) {
  return value === null || typeof value === 'boolean' ||
    (typeof value === 'string' && value.length <= 2000) ||
    (typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= Number.MAX_SAFE_INTEGER);
}

/** JSON representation with lexicographically ordered object keys and unchanged array order. */
export function canonicalJson(value) {
  if (value === null || typeof value === 'boolean' || typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${Array.from(value, canonicalJson).join(',')}]`;
  if (plain(value)) return `{${Object.keys(value).sort(compare).map(key => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
  invalid('Only JSON values can be serialized.');
}

function fields(input, name) {
  if (!own(input, name)) return [];
  const value = input[name];
  if (!Array.isArray(value) || value.length > 32 || !Array.from(value).every(fieldName) || new Set(value).size !== value.length) invalid(`${name} must contain up to 32 distinct field names.`);
  return [...value].sort(compare);
}

/** Validate bounded flat records and return a fresh canonical request with explicit rule defaults. */
export function normalizeRequest(input) {
  if (!plain(input) || Object.keys(input).some(key => !TOP_FIELDS.has(key))) invalid('The request must contain rows and supported report rules only.');
  if (!Array.isArray(input.rows) || input.rows.length < 1 || input.rows.length > 1000) invalid('rows must contain between 1 and 1000 records.');
  const rows = Array.from(input.rows, row => {
    if (!plain(row) || Object.keys(row).length > 32) invalid('Each row must be a flat object with at most 32 fields.');
    return Object.fromEntries(Object.keys(row).sort(compare).map(key => {
      if (!fieldName(key) || !primitive(row[key])) invalid('Row fields must have valid names and bounded scalar JSON values.');
      return [key, row[key] === 0 ? 0 : row[key]];
    }));
  });
  const required_fields = fields(input, 'required_fields');
  const unique_fields = fields(input, 'unique_fields');
  const types = own(input, 'field_types') ? input.field_types : {};
  if (!plain(types) || Object.keys(types).length > 32) invalid('field_types must be an object with at most 32 rules.');
  const field_types = Object.fromEntries(Object.keys(types).sort(compare).map(key => {
    if (!fieldName(key) || !TYPES.has(types[key])) invalid('Field types must be string, number, or boolean.');
    return [key, types[key]];
  }));
  const normalized = { rows, required_fields, unique_fields, field_types };
  if (Buffer.byteLength(canonicalJson(normalized), 'utf8') > MAX_BYTES) invalid('The canonical request exceeds 128 KiB.');
  return normalized;
}

export function requestDigest(normalized) {
  return createHash('sha256').update(canonicalJson(normalizeRequest(normalized)), 'utf8').digest('hex');
}

/** Deterministic validation work only: report findings do not prove any arbitrary external task. */
export function buildReport(input) {
  const { rows, required_fields, unique_fields, field_types } = normalizeRequest(input);
  const issues = [];
  const duplicates = [];
  const invalidRows = new Set();
  const duplicateRows = new Set();
  const issue = (row, field, code) => { issues.push({ row, field, code }); invalidRows.add(row); };

  rows.forEach((record, index) => {
    const row = index + 1;
    for (const field of required_fields) {
      if (!own(record, field) || record[field] === null || record[field] === '') issue(row, field, 'REQUIRED');
    }
    for (const [field, type] of Object.entries(field_types)) {
      if (own(record, field) && record[field] !== null && typeof record[field] !== type) issue(row, field, 'TYPE_MISMATCH');
    }
  });

  for (const field of unique_fields) {
    const groups = new Map();
    rows.forEach((record, index) => {
      if (!own(record, field) || record[field] === null || record[field] === '') return;
      const key = canonicalJson(record[field]);
      if (!groups.has(key)) groups.set(key, { value: record[field], rows: [] });
      groups.get(key).rows.push(index + 1);
    });
    for (const [, group] of [...groups.entries()].sort(([a], [b]) => compare(a, b))) {
      if (group.rows.length < 2) continue;
      duplicates.push({ field, value: group.value, rows: group.rows });
      for (const row of group.rows) { issue(row, field, 'DUPLICATE_VALUE'); duplicateRows.add(row); }
    }
  }

  issues.sort((a, b) => a.row - b.row || compare(a.field, b.field) || compare(a.code, b.code));
  return {
    schema_version: 1,
    summary: { total_rows: rows.length, valid_rows: rows.length - invalidRows.size, invalid_rows: invalidRows.size, duplicate_rows: duplicateRows.size },
    issues,
    duplicates,
  };
}
