import { fail } from './errors.mjs';
import { JsonRpcProvider } from 'near-api-js';

const TESTNET_HOSTS = new Set(['rpc.testnet.near.org', 'archival-rpc.testnet.near.org', 'test.rpc.fastnear.com']);

/** RPC destinations are deliberately narrower than arbitrary application URLs. */
export function rpcUrl(value) {
  if (typeof value !== 'string') fail('INVALID_RPC_URL');
  let url; try { url = new URL(value); } catch { fail('INVALID_RPC_URL'); }
  if (url.username || url.password || value.includes('?') || value.includes('#') || /^[a-z]+:\/\/[^/]*@/i.test(value) || url.pathname !== '/') fail('INVALID_RPC_URL');
  const loopback = url.protocol === 'http:' && url.hostname === '127.0.0.1';
  const testnet = url.protocol === 'https:' && TESTNET_HOSTS.has(url.hostname) && !url.port;
  if (!loopback && !testnet) fail('RPC_DESTINATION_NOT_ALLOWED');
  return value;
}

export function assertNetwork(endpoint, network) {
  rpcUrl(endpoint);
  if (!['sandbox', 'testnet'].includes(network)) fail('UNSUPPORTED_NETWORK');
  if (new URL(endpoint).protocol === 'https:' && network !== 'testnet') fail('NETWORK_MISMATCH', 409);
}

export async function rpc(endpoint, method, params) {
  const response = await fetch(rpcUrl(endpoint), {
    method: 'POST', redirect: 'error', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 'oncefolio', method, params }),
    signal: AbortSignal.timeout(20000),
  });
  if (!response.ok) throw new Error(`RPC_HTTP_${response.status}`);
  const body = await response.json();
  if (body.error) throw new Error(JSON.stringify(body.error));
  if (!Object.prototype.hasOwnProperty.call(body, 'result')) throw new Error('INVALID_RPC_RESPONSE');
  return body.result;
}

// The SDK transport follows fetch redirects by default. Keep its public helpers,
// but route their actual network access through the same restrictive transport.
export class StrictJsonRpcProvider extends JsonRpcProvider {
  constructor(endpoint) { super({ url: rpcUrl(endpoint) }); }
  async sendJsonRpc(method, params) { return rpc(this.connection.url, method, params); }
}
