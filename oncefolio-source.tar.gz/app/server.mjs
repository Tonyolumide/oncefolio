import http from 'node:http';
import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { Store, publicPurchase } from './store.mjs';
import { Auth } from './auth.mjs';
import { NearGateway, PRICE } from './near.mjs';
import { normalizeRequest, requestDigest } from './report.mjs';
import { purchaseId, fail } from './errors.mjs';

async function body(req) {
  if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] ?? '')) fail('JSON_REQUIRED', 415);
  let size = 0; const chunks = [];
  for await (const chunk of req) { size += chunk.length; if (size > 128 * 1024) fail('REQUEST_TOO_LARGE', 413); chunks.push(chunk); }
  try { const result = JSON.parse(Buffer.concat(chunks).toString()); if (!result || typeof result !== 'object' || Array.isArray(result)) fail('INVALID_JSON'); return result; } catch { fail('INVALID_JSON'); }
}

export async function createService({ dbPath, near, port = 0, now = Date.now, log = () => {} }) {
  await near.ensureEnvironment();
  const store = new Store(dbPath, { environment: near.environment, contractId: near.contractId, now });
  let auth;
  const rate = new Map();
  const server = http.createServer(async (req, res) => {
    const request_id = randomUUID();
    res.setHeader('content-type', 'application/json'); res.setHeader('cache-control', 'no-store');
    res.setHeader('x-content-type-options', 'nosniff'); res.setHeader('x-request-id', request_id);
    try {
      if (req.headers.origin) fail('BROWSER_ORIGIN_UNSUPPORTED', 403);
      const path = new URL(req.url, 'http://127.0.0.1').pathname;
      if (req.method === 'GET' && path === '/health') { await near.ensureEnvironment(); res.end(JSON.stringify({ status: 'ok' })); return; }
      const peer = req.socket.remoteAddress;
      const current = rate.get(peer);
      if (!current || current.reset <= now()) rate.set(peer, { n: 1, reset: now() + 60000 });
      else if (++current.n > 240) fail('RATE_LIMITED', 429);
      if (req.method === 'GET' && path === '/v1/service') { res.end(JSON.stringify({ name: 'Oncefolio', service: 'structured-data-report-v1', network: near.network ?? 'sandbox', environment: near.environment, contract_id: near.contractId, provider: near.contractId, price_yoctonear: PRICE, max_rows: 1000, max_request_bytes: 128 * 1024, origin: auth.origin })); return; }
      if (req.method === 'POST' && path === '/v1/auth/challenges') { const input = await body(req); res.end(JSON.stringify(auth.challenge(input.buyer))); return; }
      if (req.method === 'POST' && path === '/v1/auth/sessions') { res.end(JSON.stringify(await auth.login(await body(req)))); return; }
      const session = await auth.session(req.headers.authorization);
      if (req.method === 'DELETE' && path === '/v1/auth/session') { auth.logout(req.headers.authorization); res.end(JSON.stringify({ signed_out: true })); return; }
      if (req.method === 'POST' && path === '/v1/quotes') {
        const input = await body(req);
        if (!purchaseId(input.purchase_id)) fail('INVALID_PURCHASE_ID');
        const owned = store.get(input.purchase_id);
        if (owned && owned.buyer !== session.buyer) fail('NOT_FOUND', 404);
        const request = normalizeRequest(input.request), digest = requestDigest(request);
        const count = store.db.prepare('SELECT count(*) AS n FROM purchases').get().n;
        if (!store.get(input.purchase_id) && count >= 10000) fail('CAPACITY_REACHED', 429);
        // The first DB write fixes expiry and quote identity before any registration transaction.
        const binding = { network: near.network ?? 'sandbox', contract_id: near.contractId, provider: near.contractId, buyer: session.buyer, purchase_id: input.purchase_id, quote_id: `q-${input.purchase_id}`.slice(0, 64), quote_version: '1', amount: PRICE, request_digest: digest, expires_at_ns: (BigInt(now()) * 1_000_000n + 600_000_000_000n).toString() };
        const row = store.ensurePurchase({ id: input.purchase_id, buyer: session.buyer, request, digest, binding });
        await near.registerQuote(JSON.parse(row.binding_json)); store.markQuoteReady(row.id);
        res.end(JSON.stringify({ purchase_id: row.id, binding: JSON.parse(row.binding_json), environment: near.environment })); return;
      }
      const match = /^\/v1\/purchases\/([a-z0-9][a-z0-9_-]{0,63})(?:\/(reconcile|retry))?$/.exec(path);
      if (!match) fail('NOT_FOUND', 404);
      const row = store.get(match[1]);
      if (!row || row.buyer !== session.buyer) fail('NOT_FOUND', 404);
      if (req.method === 'POST' && match[2] === 'reconcile') {
        const block = await near.accepted(JSON.parse(row.binding_json));
        if (block) store.confirmPayment(row.id, JSON.stringify(block));
      } else if (req.method === 'POST' && match[2] === 'retry') {
        if (!await near.accepted(JSON.parse(row.binding_json))) fail('PAYMENT_UNRESOLVED', 409);
        store.retry(row.id);
      } else if (req.method !== 'GET' || match[2]) fail('NOT_FOUND', 404);
      res.end(JSON.stringify(publicPurchase(store.get(row.id))));
    } catch (error) {
      const status = Number.isInteger(error.status) ? error.status : 500;
      const code = error.code && /^[A-Z_]+$/.test(error.code) ? error.code : 'INTERNAL_ERROR';
      log({ request_id, status, code });
      res.statusCode = status; res.end(JSON.stringify({ error: { code, request_id } }));
    }
  });
  server.requestTimeout = 15000; server.headersTimeout = 10000;
  await new Promise((res, rej) => { server.once('error', rej); server.listen(port, '127.0.0.1', res); });
  const origin = `http://127.0.0.1:${server.address().port}`;
  auth = new Auth(store, near, origin, { now });
  return { origin, store, server, auth, async close() { server.closeAllConnections(); await new Promise(r => server.close(r)); store.close(); } };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const config = JSON.parse(readFileSync(process.argv[2], 'utf8'));
  const credential = JSON.parse(readFileSync(config.providerKeyFile, 'utf8'));
  const near = new NearGateway({ ...config, providerKey: credential.secret_key });
  const service = await createService({ dbPath: config.dbPath, near, port: config.apiPort ?? 8787, log: entry => console.error(JSON.stringify(entry)) });
  console.log(JSON.stringify({ ready: true, origin: service.origin }));
  const stop = async () => { await service.close(); process.exit(0); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
