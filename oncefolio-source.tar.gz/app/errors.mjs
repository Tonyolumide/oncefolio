export function fail(code, status = 400) {
  const error = new Error(code); error.code = code; error.status = status; throw error;
}
export const purchaseId = value => typeof value === 'string' && /^[a-z0-9][a-z0-9_-]{0,63}$/.test(value);
export const accountId = value => typeof value === 'string' && value.length >= 2 && value.length <= 64 && /^(([a-z0-9]+[-_])*[a-z0-9]+\.)*([a-z0-9]+[-_])*[a-z0-9]+$/.test(value);
