import { createHash } from 'node:crypto';
import { Account, actions } from 'near-api-js';
import { rpc, rpcUrl as checkedRpcUrl, assertNetwork, StrictJsonRpcProvider } from './rpc.mjs';
import { canonicalJson } from './report.mjs';
import { fail } from './errors.mjs';

export const PRICE = '100000000000000000000000';
export const GAS = 100_000_000_000_000n;
export const sameBinding = (a, b) => canonicalJson(a) === canonicalJson(b);

export async function fingerprint(rpcUrl, network = new URL(checkedRpcUrl(rpcUrl)).protocol === 'https:' ? 'testnet' : 'sandbox') {
  assertNetwork(rpcUrl, network);
  if (network === 'testnet') {
    const status = await rpc(rpcUrl, 'status', []);
    if (status.chain_id !== 'testnet') fail('NETWORK_MISMATCH', 409);
    if (!/^[1-9A-HJ-NP-Za-km-z]{43,44}$/.test(status.genesis_hash ?? '')) fail('NETWORK_IDENTITY_UNAVAILABLE', 503);
    // Public nodes can expose different normalized genesis configuration fields.
    // The chain's genesis block hash is its immutable identity across those nodes.
    return createHash('sha256').update(canonicalJson({ chain_id: status.chain_id, genesis_hash: status.genesis_hash })).digest('hex');
  }
  const genesis = await rpc(rpcUrl, 'EXPERIMENTAL_genesis_config', {});
  return createHash('sha256').update(canonicalJson(genesis)).digest('hex');
}

export class NearGateway {
  constructor({ rpcUrl, contractId, providerKey, environment, network = 'sandbox' }) {
    assertNetwork(rpcUrl, network);
    this.rpcUrl = checkedRpcUrl(rpcUrl); this.contractId = contractId; this.environment = environment; this.network = network;
    this.provider = new StrictJsonRpcProvider(this.rpcUrl);
    if (providerKey) this.account = new Account(contractId, this.provider, providerKey);
  }
  async ensureEnvironment() {
    try { if (await fingerprint(this.rpcUrl, this.network) !== this.environment) fail('ENVIRONMENT_MISMATCH', 409); }
    catch (error) { if (['ENVIRONMENT_MISMATCH', 'NETWORK_MISMATCH'].includes(error.code)) throw error; fail('CHAIN_UNAVAILABLE', 503); }
  }
  async accessKey(buyer, publicKey) {
    await this.ensureEnvironment();
    try { return await rpc(this.rpcUrl, 'query', { request_type: 'view_access_key', finality: 'final', account_id: buyer, public_key: publicKey.toString() }); }
    catch (error) {
      if (/UNKNOWN_ACCESS_KEY|UNKNOWN_ACCOUNT/.test(error.message)) fail('AUTH_KEY_NOT_FOUND', 401);
      fail('CHAIN_UNAVAILABLE', 503);
    }
  }
  async view(method, purchase_id) {
    await this.ensureEnvironment();
    try {
      const response = await rpc(this.rpcUrl, 'query', { request_type: 'call_function', finality: 'final', account_id: this.contractId, method_name: method, args_base64: Buffer.from(JSON.stringify({ purchase_id })).toString('base64') });
      return { value: JSON.parse(Buffer.from(response.result).toString()), block: { hash: response.block_hash, height: response.block_height } };
    } catch { fail('CHAIN_UNAVAILABLE', 503); }
  }
  async registerQuote(binding) {
    const existing = (await this.view('get_quote', binding.purchase_id)).value;
    if (existing) { if (!sameBinding(existing, binding)) fail('QUOTE_CONFLICT', 409); return; }
    try {
      await this.account.signAndSendTransaction({ receiverId: this.contractId, actions: [actions.functionCall('register_quote', { binding }, GAS, 0n)], waitUntil: 'FINAL', throwOnFailure: false });
    } catch { /* An ambiguous response is resolved by the authoritative read below. */ }
    const confirmed = (await this.view('get_quote', binding.purchase_id)).value;
    if (!confirmed) fail('QUOTE_PENDING', 503);
    if (!sameBinding(confirmed, binding)) fail('QUOTE_CONFLICT', 409);
  }
  async accepted(binding) {
    const { value, block } = await this.view('get_purchase', binding.purchase_id);
    if (!value) return null;
    if (value.payment !== 'accepted' || !sameBinding(value.binding, binding)) fail('PURCHASE_CONFLICT', 409);
    return block;
  }
}
