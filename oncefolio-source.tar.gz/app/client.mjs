import { Account, actions, baseEncode } from 'near-api-js';
import { signMessage } from 'near-api-js/nep413';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, readFileSync, mkdirSync, openSync, closeSync, writeFileSync, unlinkSync } from 'node:fs';
import { dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { persist, localUrl } from '../spike/client.mjs';
import { rpc, rpcUrl as checkedRpcUrl, assertNetwork, StrictJsonRpcProvider } from './rpc.mjs';
import { canonicalJson, normalizeRequest, requestDigest } from './report.mjs';
import { fingerprint, GAS, sameBinding } from './near.mjs';
import { fail } from './errors.mjs';
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function locked(path, fn) {
  mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  const lock = `${path}.lock`;
  let fd;
  for (let i = 0; ; i++) {
    try { fd = openSync(lock, 'wx', 0o600); writeFileSync(fd, String(process.pid)); break; }
    catch (error) {
      if (error.code !== 'EEXIST') throw error;
      try { const pid = Number(readFileSync(lock, 'utf8')); if (Number.isInteger(pid) && pid > 0) process.kill(pid, 0); }
      catch (error) { if (error.code === 'ESRCH') { try { unlinkSync(lock); } catch {} continue; } }
      if (i > 160) fail('INTENT_BUSY', 409);
      await sleep(30);
    }
  }
  try { return await fn(); } finally { closeSync(fd); unlinkSync(lock); }
}

export class BuyerClient {
  constructor({ serviceUrl, rpcUrl, credentials, network = new URL(checkedRpcUrl(rpcUrl)).protocol === 'https:' ? 'testnet' : 'sandbox' }) {
    assertNetwork(rpcUrl, network);
    this.serviceUrl = localUrl(serviceUrl).replace(/\/$/, ''); this.rpcUrl = checkedRpcUrl(rpcUrl); this.network = network;
    this.credentials = credentials;
    this.account = new Account(credentials.account_id, new StrictJsonRpcProvider(this.rpcUrl), credentials.secret_key);
  }
  async api(path, { method = 'GET', body, auth = true, retry = true } = {}) {
    if (auth && !this.token) await this.login();
    const response = await fetch(`${this.serviceUrl}${path}`, { method, redirect: 'error', headers: { ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...(auth ? { authorization: `Bearer ${this.token}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(20000) });
    const result = await response.json();
    if (response.status === 401 && auth && retry) { await this.login(); return this.api(path, { method, body, auth, retry: false }); }
    if (!response.ok) fail(result.error?.code ?? 'SERVICE_UNAVAILABLE', response.status);
    return result;
  }
  async login() {
    const challenge = await this.api('/v1/auth/challenges', { method: 'POST', body: { buyer: this.credentials.account_id }, auth: false });
    const signed = await signMessage({ signerAccount: this.account, payload: { message: challenge.message, nonce: Buffer.from(challenge.nonce, 'base64'), recipient: challenge.recipient } });
    const session = await this.api('/v1/auth/sessions', { method: 'POST', body: { challenge_id: challenge.id, public_key: signed.publicKey.toString(), signature: Buffer.from(signed.signature).toString('base64') }, auth: false });
    this.token = session.token; return session;
  }
  async metadata() {
    const meta = await this.api('/v1/service', { auth: false });
    if (meta.network !== this.network) fail('NETWORK_MISMATCH', 409);
    if (meta.environment !== await fingerprint(this.rpcUrl, this.network)) fail('ENVIRONMENT_MISMATCH', 409);
    return meta;
  }
  async quote(purchase_id, request) { return this.api('/v1/quotes', { method: 'POST', body: { purchase_id, request } }); }
  async signAttempt(intent) {
    const signed = await this.account.createSignedTransaction({ receiverId: intent.contract_id, actions: [actions.functionCall('accept', { binding: intent.binding }, GAS, BigInt(intent.binding.amount))] });
    intent.signed_tx_base64 = Buffer.from(signed.encode()).toString('base64');
    intent.tx_hash = baseEncode(createHash('sha256').update(signed.transaction.encode()).digest());
  }
  validateIntent(intent, meta) {
    if ((intent.network ?? intent.binding?.network ?? 'sandbox') !== (meta.network ?? this.network)) fail('NETWORK_MISMATCH', 409);
    if (intent.environment !== meta.environment || intent.contract_id !== meta.contract_id || intent.buyer !== this.credentials.account_id || intent.rpcUrl !== this.rpcUrl) fail('ENVIRONMENT_MISMATCH', 409);
  }
  async prepare(path, input, { purchaseId } = {}) {
    return locked(path, async () => {
      const request = normalizeRequest(input), digest = requestDigest(request), meta = await this.metadata();
      let intent;
      if (existsSync(path)) {
        intent = JSON.parse(readFileSync(path, 'utf8')); this.validateIntent(intent, meta);
        if (intent.request_digest !== digest || canonicalJson(intent.request) !== canonicalJson(request) || (purchaseId && purchaseId !== intent.purchase_id)) fail('PURCHASE_CONFLICT', 409);
      } else {
        intent = { schema_version: 1, rpcUrl: this.rpcUrl, network: this.network, environment: meta.environment, contract_id: meta.contract_id, buyer: this.credentials.account_id, purchase_id: purchaseId ?? randomUUID(), request, request_digest: digest, attempt: { status: 'not_submitted' } };
        persist(path, intent); // ID and request survive even a lost quote-registration response.
      }
      const quote = await this.quote(intent.purchase_id, request);
      if (quote.environment !== intent.environment || quote.binding.network !== this.network || quote.binding.buyer !== intent.buyer || quote.binding.request_digest !== digest || quote.binding.contract_id !== meta.contract_id || quote.binding.provider !== meta.provider || quote.binding.amount !== meta.price_yoctonear) fail('QUOTE_CONFLICT', 409);
      if (intent.binding && !sameBinding(intent.binding, quote.binding)) fail('QUOTE_CONFLICT', 409);
      intent.binding = quote.binding;
      if (!intent.signed_tx_base64) {
        await this.signAttempt(intent);
      }
      persist(path, intent); return intent;
    });
  }
  async _recover(intent, { lookupAttempt = true } = {}) {
    const meta = await this.metadata(); this.validateIntent(intent, meta);
    if (!intent.binding) fail('INTENT_NOT_PREPARED', 409);
    const purchase = await this.api(`/v1/purchases/${intent.purchase_id}/reconcile`, { method: 'POST' });
    if (!sameBinding(purchase.binding, intent.binding)) fail('PURCHASE_CONFLICT', 409);
    let attempt = intent.attempt?.status === 'rejected' ? { ...intent.attempt } : { status: 'unknown', tx_hash: intent.tx_hash };
    if (purchase.payment.status === 'accepted') attempt = { status: 'accepted', tx_hash: intent.tx_hash };
    else if (intent.tx_hash && lookupAttempt) {
      try {
        const outcome = await rpc(this.rpcUrl, 'tx', { tx_hash: intent.tx_hash, sender_account_id: intent.buyer, wait_until: 'FINAL' });
        if (outcome.status.Failure) {
          const message = JSON.stringify(outcome.status);
          const code = ['QUOTE_EXPIRED', 'WRONG_DEPOSIT', 'BUYER_ONLY', 'DUPLICATE_PURCHASE'].find(code => message.includes(code)) ?? 'TRANSACTION_FAILED';
          attempt = { ...attempt, status: 'rejected', error: code };
        }
      } catch { /* Unknown transaction is not proof of rejection. */ }
    }
    return { purchase, attempt };
  }
  async recover(path) {
    return locked(path, async () => {
      const intent = JSON.parse(readFileSync(path, 'utf8'));
      const result = await this._recover(intent); intent.attempt = result.attempt; persist(path, intent); return result;
    });
  }
  async pay(path) {
    return locked(path, async () => {
      const intent = JSON.parse(readFileSync(path, 'utf8'));
      const before = await this._recover(intent, { lookupAttempt: false });
      if (before.purchase.payment.status === 'accepted') return before;
      if (!intent.signed_tx_base64) fail('INTENT_NOT_PREPARED', 409);
      intent.attempt = { status: 'unknown', tx_hash: intent.tx_hash }; persist(path, intent);
      try { await rpc(this.rpcUrl, 'send_tx', { signed_tx_base64: intent.signed_tx_base64, wait_until: 'FINAL' }); }
      catch (error) {
        // Only definitive transaction-validation rejections can renew an attempt here.
        // A lost response never authorizes an automatic new signed transaction.
        if (/InvalidNonce|Expired|INVALID_NONCE|EXPIRED_TRANSACTION/.test(error.message)) {
          const checked = await this._recover(intent, { lookupAttempt: false });
          if (checked.purchase.payment.status === 'accepted') { intent.attempt = checked.attempt; persist(path, intent); return checked; }
          intent.signed_attempts ??= [];
          if (intent.signed_attempts.length >= 10) fail('PAYMENT_ATTEMPT_LIMIT', 409);
          intent.signed_attempts.push({ tx_hash: intent.tx_hash, signed_tx_base64: intent.signed_tx_base64, rejection: 'NONCE_OR_REFERENCE_EXPIRED' });
          await this.signAttempt(intent); persist(path, intent);
          try { await rpc(this.rpcUrl, 'send_tx', { signed_tx_base64: intent.signed_tx_base64, wait_until: 'FINAL' }); }
          catch (renewalError) {
            if (/InvalidNonce|Expired|INVALID_NONCE|EXPIRED_TRANSACTION/.test(renewalError.message)) {
              intent.attempt = { status: 'rejected', tx_hash: intent.tx_hash, error: 'PAYMENT_NONCE_RETRY_REQUIRED' }; persist(path, intent);
              return { purchase: checked.purchase, attempt: intent.attempt };
            }
          }
        }
      }
      const result = await this._recover(intent); intent.attempt = result.attempt; persist(path, intent); return result;
    });
  }
  async wait(path, { timeoutMs = 10000 } = {}) {
    let result = await this.recover(path); const end = Date.now() + timeoutMs;
    while (result.purchase.payment.status === 'accepted' && !['succeeded', 'failed'].includes(result.purchase.delivery.status) && Date.now() < end) {
      await sleep(100);
      result = { ...result, purchase: await this.api(`/v1/purchases/${result.purchase.purchase_id}`) };
    }
    return result;
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const [command, configPath, intentPath, requestPath] = process.argv.slice(2);
    if (!command || !configPath || !intentPath) fail('USAGE_BUY_OR_RECOVER_CONFIG_INTENT_REQUEST');
    const config = JSON.parse(readFileSync(configPath, 'utf8'));
    const credentials = JSON.parse(readFileSync(config.buyerKeyFile, 'utf8'));
    const client = new BuyerClient({ serviceUrl: config.serviceUrl, rpcUrl: config.rpcUrl, network: config.network, credentials });
    if (command === 'buy' || command === 'prepare') {
      const intent = await client.prepare(intentPath, JSON.parse(readFileSync(requestPath, 'utf8')));
      if (command === 'prepare') { console.log(JSON.stringify({ purchase_id: intent.purchase_id, binding: intent.binding, attempt: intent.attempt }, null, 2)); process.exit(0); }
      await client.pay(intentPath); console.log(JSON.stringify(await client.wait(intentPath), null, 2));
    } else if (command === 'recover' || command === 'status') console.log(JSON.stringify(await client.wait(intentPath), null, 2));
    else if (command === 'retry') { const state = await client.recover(intentPath); await client.api(`/v1/purchases/${state.purchase.purchase_id}/retry`, { method: 'POST' }); console.log(JSON.stringify(await client.wait(intentPath), null, 2)); }
    else fail('UNKNOWN_COMMAND');
  } catch (error) { console.error(JSON.stringify({ error: error.code ?? 'CLIENT_FAILED' })); process.exitCode = 1; }
}
