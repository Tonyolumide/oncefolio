import { randomBytes, randomUUID, createHash } from 'node:crypto';
import { verifyMessage } from 'near-api-js/nep413';
import { accountId, fail } from './errors.mjs';

const hash = value => createHash('sha256').update(value).digest('hex');
export class Auth {
  constructor(store, near, origin, { now = Date.now } = {}) { Object.assign(this, { store, near, origin, now }); }
  challenge(buyer) {
    if (!accountId(buyer)) fail('INVALID_BUYER');
    const now = this.now();
    this.store.db.prepare('DELETE FROM challenges WHERE expires_at < ?').run(now);
    this.store.db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now);
    if (this.store.db.prepare('SELECT count(*) AS n FROM challenges WHERE buyer=? AND used=0').get(buyer).n >= 10 || this.store.db.prepare('SELECT count(*) AS n FROM challenges').get().n >= 1000) fail('RATE_LIMITED', 429);
    const challenge = { id: randomUUID(), buyer, nonce: randomBytes(32).toString('base64'), recipient: this.origin, expires_at: now + 60000 };
    challenge.message = `Sign in to Oncefolio as ${buyer}. Service ${this.origin}. Contract ${this.near.contractId}. Chain ${this.near.environment}. Expires ${challenge.expires_at}. Challenge ${challenge.id}.`;
    this.store.db.prepare('INSERT INTO challenges(id,buyer,nonce,message,recipient,expires_at,used) VALUES(?,?,?,?,?,?,0)').run(challenge.id, buyer, challenge.nonce, challenge.message, challenge.recipient, challenge.expires_at);
    return challenge;
  }
  async login({ challenge_id, public_key, signature }) {
    if (typeof challenge_id !== 'string' || typeof public_key !== 'string' || public_key.length > 120 || typeof signature !== 'string' || signature.length > 200) fail('INVALID_AUTH');
    const challenge = this.store.db.prepare('SELECT * FROM challenges WHERE id=?').get(challenge_id);
    if (!challenge || challenge.used || challenge.expires_at <= this.now()) fail('AUTH_CHALLENGE_INVALID', 401);
    try {
      await verifyMessage({ signerAccountId: challenge.buyer, signerPublicKey: public_key, payload: { message: challenge.message, recipient: challenge.recipient, nonce: Buffer.from(challenge.nonce, 'base64') }, signature: Buffer.from(signature, 'base64'), provider: { viewAccessKey: ({ accountId, publicKey }) => this.near.accessKey(accountId, publicKey) } });
    } catch (error) { if (['CHAIN_UNAVAILABLE', 'ENVIRONMENT_MISMATCH', 'NETWORK_MISMATCH'].includes(error.code)) throw error; fail('AUTH_SIGNATURE_INVALID', 401); }
    const token = randomBytes(32).toString('base64url');
    const expires_at = this.now() + 15 * 60000;
    this.store.transaction(() => {
      const changed = this.store.db.prepare('UPDATE challenges SET used=1 WHERE id=? AND used=0 AND expires_at>?').run(challenge.id, this.now());
      if (!changed.changes) fail('AUTH_CHALLENGE_INVALID', 401);
      this.store.db.prepare('INSERT INTO sessions(token_hash,buyer,public_key,expires_at) VALUES(?,?,?,?)').run(hash(token), challenge.buyer, public_key, expires_at);
    });
    return { token, expires_at, buyer: challenge.buyer };
  }
  async session(header) {
    if (typeof header !== 'string' || !/^Bearer [A-Za-z0-9_-]{43}$/.test(header)) fail('AUTH_REQUIRED', 401);
    const token = header.slice(7);
    const session = this.store.db.prepare('SELECT * FROM sessions WHERE token_hash=? AND expires_at>?').get(hash(token), this.now());
    if (!session) fail('AUTH_REQUIRED', 401);
    try {
      const key = await this.near.accessKey(session.buyer, session.public_key);
      if (key.permission !== 'FullAccess') fail('AUTH_REQUIRED', 401);
    } catch (error) { if (['CHAIN_UNAVAILABLE', 'ENVIRONMENT_MISMATCH', 'NETWORK_MISMATCH'].includes(error.code)) throw error; fail('AUTH_REQUIRED', 401); }
    if (!this.store.db.prepare('SELECT 1 FROM sessions WHERE token_hash=? AND expires_at>?').get(hash(token), this.now())) fail('AUTH_REQUIRED', 401);
    return session;
  }
  logout(header) { if (typeof header === 'string') this.store.db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hash(header.slice(7))); }
}
