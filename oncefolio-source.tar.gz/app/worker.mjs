import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { Store } from './store.mjs';
import { buildReport } from './report.mjs';
const delay = ms => new Promise(r => setTimeout(r, ms));

export async function workOnce(store, { leaseMs = 5000, compute = buildReport, delayMs = 0, onClaim = () => {} } = {}) {
  const job = store.claim(leaseMs);
  if (!job) return false;
  onClaim(job);
  try {
    if (delayMs) await delay(Math.min(delayMs, 10000));
    const result = await compute(JSON.parse(job.request_json));
    store.complete(job.id, job.lease_token, result);
  } catch { store.fail(job.id, job.lease_token, 'SERVICE_FAILED'); }
  return true;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const config = JSON.parse(readFileSync(process.argv[2], 'utf8'));
  const store = new Store(config.dbPath, { environment: config.environment, contractId: config.contractId });
  let stopping = false;
  process.on('SIGTERM', () => { stopping = true; }); process.on('SIGINT', () => { stopping = true; });
  try {
    do {
      await workOnce(store, { leaseMs: config.workerLeaseMs ?? 5000, delayMs: config.workerDelayMs ?? 0, onClaim: job => console.log(JSON.stringify({ event: 'claimed', purchase_id: job.id, attempt: job.attempts })) });
      if (process.argv.includes('--once')) break;
      await delay(100);
    } while (!stopping);
  } finally { store.close(); }
}
