import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, chmodSync, readFileSync, readdirSync, lstatSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';
import { canonicalJson } from './report.mjs';

const MAX_ATTEMPTS = 3;
const migrationDirectory = fileURLToPath(new URL('../migrations/', import.meta.url));
const hash = text => createHash('sha256').update(text).digest('hex');
const error = (code, status = 409) => Object.assign(new Error(code), { code, status });

function trackedMigrations() {
  return readdirSync(migrationDirectory).filter(name => /^\d+_[a-z0-9_]+\.sql$/.test(name)).sort().map(name => {
    const sql = readFileSync(resolve(migrationDirectory, name), 'utf8');
    return { version: Number(name.split('_')[0]), sha256: hash(sql), sql };
  });
}

export class Store {
  constructor(dbPath, { environment, contractId, now = Date.now } = {}) {
    if (typeof environment !== 'string' || !environment || typeof contractId !== 'string' || !contractId) throw error('ENVIRONMENT_REQUIRED', 500);
    this.now = now;
    this.savepoint = 0;
    this.closed = false;
    if (dbPath !== ':memory:') {
      const path = resolve(dbPath);
      mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
      chmodSync(dirname(path), 0o700);
      if (existsSync(path) && lstatSync(path).isSymbolicLink()) throw error('INVALID_DB_PATH', 500);
      this.db = new DatabaseSync(path);
      chmodSync(path, 0o600);
    } else this.db = new DatabaseSync(':memory:');
    try {
      this.db.exec('PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL;');
      this.transaction(() => {
        this.db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, sha256 TEXT NOT NULL, applied_at INTEGER NOT NULL)');
        const tracked = trackedMigrations();
        const applied = this.db.prepare('SELECT version, sha256 FROM schema_migrations ORDER BY version').all();
        if (new Set(tracked.map(m => m.version)).size !== tracked.length) throw error('MIGRATION_MISMATCH', 500);
        for (const previous of applied) {
          if (!tracked.some(m => m.version === previous.version && m.sha256 === previous.sha256)) throw error('MIGRATION_MISMATCH', 500);
        }
        for (const migration of tracked) {
          if (applied.some(m => m.version === migration.version)) continue;
          this.db.exec(migration.sql);
          this.db.prepare('INSERT INTO schema_migrations(version, sha256, applied_at) VALUES (?, ?, ?)').run(migration.version, migration.sha256, this.now());
        }
        for (const [key, value] of Object.entries({ environment, contract_id: contractId })) {
          const existing = this.db.prepare('SELECT value FROM metadata WHERE key = ?').get(key);
          if (existing && existing.value !== value) throw error('ENVIRONMENT_MISMATCH');
          if (!existing) this.db.prepare('INSERT INTO metadata(key, value) VALUES (?, ?)').run(key, value);
        }
      });
    } catch (cause) {
      this.close();
      throw cause;
    }
  }

  close() {
    if (this.closed) return;
    this.db.close();
    this.closed = true;
  }

  transaction(fn) {
    const nested = this.db.isTransaction;
    const name = `oncefolio_${++this.savepoint}`;
    this.db.exec(nested ? `SAVEPOINT ${name}` : 'BEGIN IMMEDIATE');
    try {
      const result = fn();
      if (result && typeof result.then === 'function') throw error('ASYNC_TRANSACTION_NOT_SUPPORTED', 500);
      this.db.exec(nested ? `RELEASE SAVEPOINT ${name}` : 'COMMIT');
      return result;
    } catch (cause) {
      if (nested) this.db.exec(`ROLLBACK TO SAVEPOINT ${name}; RELEASE SAVEPOINT ${name}`);
      else this.db.exec('ROLLBACK');
      throw cause;
    }
  }

  migrationState() {
    const schema = this.db.prepare("SELECT type, name, tbl_name, sql FROM sqlite_master ORDER BY type, name").all().map(row => ({ ...row }));
    return {
      tracked_migrations: trackedMigrations().map(({ version, sha256 }) => ({ version, sha256 })),
      applied_migrations: this.db.prepare('SELECT version, sha256, applied_at FROM schema_migrations ORDER BY version').all().map(row => ({ ...row })),
      schema_fingerprint: hash(canonicalJson(schema)),
      open_recovery_findings: [],
    };
  }

  event(id, kind) {
    this.db.prepare('INSERT INTO events(purchase_id, kind, created_at) VALUES (?, ?, ?)').run(id, kind, this.now());
  }

  get(id) { return this.db.prepare('SELECT * FROM purchases WHERE id = ?').get(id); }

  ensurePurchase({ id, buyer, request, digest, binding }) {
    const requestJson = canonicalJson(request);
    const bindingJson = canonicalJson(binding);
    return this.transaction(() => {
      const existing = this.get(id);
      if (existing) {
        if (existing.buyer !== buyer || existing.digest !== digest || existing.request_json !== requestJson) throw error('PURCHASE_CONFLICT');
        return existing;
      }
      const time = this.now();
      this.db.prepare('INSERT INTO purchases(id, buyer, request_json, digest, binding_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(id, buyer, requestJson, digest, bindingJson, time, time);
      this.event(id, 'PURCHASE_CREATED');
      return this.get(id);
    });
  }

  markQuoteReady(id) {
    return this.transaction(() => {
      const row = this.get(id);
      if (!row) throw error('PURCHASE_NOT_FOUND', 404);
      if (row.quote_status === 'pending') {
        this.db.prepare("UPDATE purchases SET quote_status = 'ready', updated_at = ? WHERE id = ?").run(this.now(), id);
        this.event(id, 'QUOTE_READY');
      }
      return this.get(id);
    });
  }

  confirmPayment(id, block) {
    return this.transaction(() => {
      const row = this.get(id);
      if (!row) throw error('PURCHASE_NOT_FOUND', 404);
      if (row.payment !== 'accepted') {
        this.db.prepare("UPDATE purchases SET payment = 'accepted', payment_block = ?, delivery = CASE WHEN delivery = 'awaiting' THEN 'pending' ELSE delivery END, updated_at = ? WHERE id = ?").run(block, this.now(), id);
        this.event(id, 'PAYMENT_ACCEPTED');
      }
      return this.get(id);
    });
  }

  claim(leaseMs = 5000) {
    if (!Number.isSafeInteger(leaseMs) || leaseMs < 1 || leaseMs > 600000) throw error('INVALID_LEASE', 400);
    return this.transaction(() => {
      const time = this.now();
      const exhausted = this.db.prepare("SELECT id FROM purchases WHERE delivery = 'running' AND lease_until <= ? AND attempts >= ?").all(time, MAX_ATTEMPTS);
      for (const row of exhausted) {
        this.db.prepare("UPDATE purchases SET delivery = 'failed', last_error = 'LEASE_EXHAUSTED', lease_token = NULL, lease_until = NULL, updated_at = ? WHERE id = ?").run(time, row.id);
        this.event(row.id, 'LEASE_EXHAUSTED');
      }
      const row = this.db.prepare("SELECT * FROM purchases WHERE payment = 'accepted' AND attempts < ? AND (delivery = 'pending' OR (delivery = 'running' AND lease_until <= ?)) ORDER BY created_at, id LIMIT 1").get(MAX_ATTEMPTS, time);
      if (!row) return undefined;
      this.db.prepare("UPDATE purchases SET delivery = 'running', attempts = attempts + 1, lease_token = ?, lease_until = ?, last_error = NULL, updated_at = ? WHERE id = ?").run(randomUUID(), time + leaseMs, time, row.id);
      this.event(row.id, 'DELIVERY_CLAIMED');
      return this.get(row.id);
    });
  }

  complete(id, token, result) {
    return this.transaction(() => {
      const time = this.now();
      const row = this.get(id);
      if (!row || row.delivery !== 'running' || row.lease_token !== token || row.lease_until <= time) return false;
      this.db.prepare("UPDATE purchases SET delivery = 'succeeded', result_json = ?, lease_token = NULL, lease_until = NULL, last_error = NULL, updated_at = ? WHERE id = ?").run(canonicalJson(result), time, id);
      this.event(id, 'DELIVERY_SUCCEEDED');
      return true;
    });
  }

  fail(id, token, code = 'SERVICE_FAILED') {
    return this.transaction(() => {
      const time = this.now();
      const row = this.get(id);
      if (!row || row.delivery !== 'running' || row.lease_token !== token || row.lease_until <= time) return false;
      const safeCode = typeof code === 'string' && /^[A-Z][A-Z0-9_]{0,63}$/.test(code) ? code : 'SERVICE_FAILED';
      this.db.prepare("UPDATE purchases SET delivery = 'failed', last_error = ?, lease_token = NULL, lease_until = NULL, updated_at = ? WHERE id = ?").run(safeCode, time, id);
      this.event(id, 'DELIVERY_FAILED');
      return true;
    });
  }

  retry(id) {
    return this.transaction(() => {
      const row = this.get(id);
      if (!row || row.payment !== 'accepted' || row.delivery !== 'failed' || row.attempts >= MAX_ATTEMPTS) throw error('RETRY_NOT_ALLOWED');
      this.db.prepare("UPDATE purchases SET delivery = 'pending', last_error = NULL, updated_at = ? WHERE id = ?").run(this.now(), id);
      this.event(id, 'DELIVERY_RETRY');
      return this.get(id);
    });
  }
}

export function publicPurchase(row) {
  return {
    purchase_id: row.id,
    binding: JSON.parse(row.binding_json),
    payment: { status: row.payment, block: row.payment_block },
    delivery: { status: row.delivery, attempts: row.attempts, max_attempts: MAX_ATTEMPTS, error: row.last_error },
    result: row.result_json === null ? null : JSON.parse(row.result_json),
  };
}
