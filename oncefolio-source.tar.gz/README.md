# Oncefolio

Buy a structured-data validation report with native NEAR, lose the payment response, restart, and recover the same purchase and report. Payment acceptance and useful service delivery have separate durable states.

This is a working **local API/CLI MVP** on a real NEAR sandbox, with SQLite persistence. It has no browser UI or remote deployment. No real tokens are required.

## Try it

The pinned native toolchain supports macOS ARM64. It uses Node 24.22.1 and pnpm 11.25.0; `./oncefolio` also finds the bundled Codex runtime on this machine. If dependencies/tools are already installed, start with the demo:

```sh
./oncefolio demo
```

See a quote persisted, a payment executed while its response is withheld, the buyer killed, a fresh buyer recover the purchase, and the same report recovered after restarting the chain and provider. The demo exits and leaves its isolated fixture under ignored `work/demo-*`.

On a fresh checkout:

```sh
./oncefolio setup
./oncefolio test
```

Setup downloads pinned tools into the workspace; it does not install global software. The sandbox needs an existing compatible `liblzma.5.dylib`; the wrapper reuses the Codex bundle here, or supply `ONCEFOLIO_NATIVE_LIB_DIR`. Other operating systems are unverified. See [toolchain details](spike/README.md).

## Use the service

Start the chain, provider API and worker in one terminal:

```sh
./oncefolio start
```

In another terminal, buy a report and then recover it:

```sh
./oncefolio buy work/local/my-purchase.json examples/request.json
./oncefolio recover work/local/my-purchase.json
```

The service listens at `http://127.0.0.1:8787`. Keep `start` running while using the CLI. Ctrl+C stops it; the chain, database, credentials and purchase intents remain under ignored `work/local/`. Starting again reuses the same chain identity and data. An incompatible contract version or chain/database mismatch stops safely; there is no automatic reset.

Other commands: `prepare`, `status`, and `retry` take the same intent path; `prepare` also takes the request file. `prepare` signs and persists without broadcasting. `retry` reruns a failed paid service within three lifetime delivery attempts and does not pay again. `buy` with an existing intent resumes its original ID and rejects changed input. New purchases use new intent paths. Do not reuse the same intent path for different requests.

## The paid service

Input is 1–1000 flat JSON rows with optional `required_fields`, `unique_fields` and `field_types` rules; at most 32 fields and 128 KiB. The deterministic report shows invalid rows, missing/type issues and type-sensitive duplicate groups. `examples/request.json` demonstrates three problematic rows. Requests and results remain offchain.

Each purchase costs **0.1 local sandbox NEAR**, plus gas. The provider operates the payment contract on its own account, so the accepted attached deposit credits that account in the same receipt; gas rewards and storage locks are accounted separately. This is not an asynchronous payout, escrow, arbitrary-work verifier or universal exactly-once execution system. Provider full-access control remains a trust boundary.

The server verifies buyer identity with standard NEP-413 signed challenges and current finalized FullAccess keys. All private purchase routes enforce ownership. The client persists immutable intent and signed bytes before broadcast. A lost response triggers reconciliation; definite nonce/reference expiry can renew a signed attempt under the same ID/binding. Onchain duplicate rejection prevents another accepted service deposit. Retrying can still burn gas.

Worker leases use fenced atomic commits. Computation may repeat after a crash, but an old worker cannot overwrite the canonical result. A paid-but-failed report remains paid and visibly failed; up to three lifetime delivery attempts are allowed, with no automatic service-failure refund.

## Proof and limitations

`./oncefolio test` builds fresh Wasm, checks source syntax/signing-key leakage, bootstraps twice, replays migrations, runs authentication/report/storage/payment/process-interruption tests, and executes the full restart demo. It generates `outputs/product/result.json`, raw receipts, authorization evidence, migration state, logs and a command transcript; `BUILD_STATE.json` is generated from those results and source hashes. The original local MVP verification passed 43 tests; the testnet-ready release adds network and deployment-plan guard tests. See the generated result for the current count. `pnpm test:spike` or `node scripts/verify.mjs` runs the separate original payment regression.

No testnet/mainnet deployment, public repository, publication or submission has occurred. Public operational security, encrypted storage, commercial failure remedies, data-retention policy and other platforms remain release work. All current dependencies install for local development; production-only dependency installation is not supported. The dependency scan has one unpatched low-severity `deepmerge` advisory in the SDK's Rollup build tooling; no moderate/high/critical findings remain after pinned transitive overrides.

NEP-413 reference: https://docs.near.org/web3-apps/backend/backend. See [architecture](BACKEND_SETUP.md), [security](SECURITY.md), [flows](00_Flow_Map.md), [brief](PROJECT_BRIEF.md) and [build plan](BUILD_PLAN.md).

## Independence and attribution

Oncefolio (formerly ReceiptLock) is provisional; domain/trademark clearance is unverified. **Lotveil is a separate independent MVP by the same solo builder**; neither project is a second submission of the other. Final READMEs must cross-reference each other under the [official rules](https://nearhackathon.com/HACKATHON.md). This workspace has not been submitted.

Built with AI assistance and the pinned NEAR SDK JS, NEAR API JS, NEAR Sandbox, QuickJS, Binaryen and WASI SDK. Their packages retain their respective licenses; no older product code is claimed as new hackathon work. The project uses the MIT license; see LICENSE.


## Testnet-ready release
Testnet runtime support is implemented but an actual deployment has not yet been approved or performed. RPC endpoints are strictly allowlisted, mainnet is rejected, and testnet chain identity is pinned to its genesis block hash. The API stays on localhost.

`./oncefolio testnet-prepare` generates local private keys and a public exact-artifact deployment plan using read-only RPC. `./oncefolio testnet-deploy` without execution flags performs read-only preflight. Actual faucet/account creation and deployment require explicit approval of that plan and its exact hash. See TESTNET_RUNBOOK.md.

This contract version adds network configuration. Existing old local chains intentionally stop on a code-version mismatch; no data is erased or upgraded automatically. To keep old fixtures and start a fresh local instance, use `./oncefolio start work/local-v2`. In another terminal, set `ONCEFOLIO_RUNTIME_CONFIG=work/local-v2/runtime.json` before using buy/recover and put new intent files in work/local-v2/.
