# Security model

Scope: local API/CLI MVP, not a production security audit. Build/runtime checks are generated in outputs/product/result.json; the final local pack contains 43 passing tests.

## Trust boundaries and data
The buyer controls its signing key, request and persisted intent. The provider controls its backend, worker, SQLite file and contract full-access key. NEAR finalized state authorizes payment acceptance; it does not verify report usefulness. The backend trusts its configured local RPC and validates the actual genesis fingerprint. Provider full-access control can change code or move funds; the MVP is not trustless custody.

Keep raw requests/results, session material and signing credentials offchain. Public chain metadata includes identities, price, digests and purchase bindings. Store keys/config under ignored local runtime directories with restrictive permissions; redact keys, bearer tokens, signed bytes and private data from logs and proof packs. SQLite/local disk is not application-level encrypted.

## Authorization matrix
| Actor | Allowed | Denied |
| --- | --- | --- |
| Anonymous | Health/service metadata, bounded authentication challenge request | Quote creation, purchase status, request/result data, reconcile, retry |
| Buyer with current finalized FullAccess key | Sign bound nonce challenge; access and mutate its own purchase workflow | Other buyer's objects, provider quote registration, worker commits |
| Restricted/revoked key or expired session | Fresh legitimate authentication if the account has an eligible key | Private API access with invalid/replayed proof |
| Provider account | Register immutable quotes on its own contract | Alter existing bindings or claim payment proves delivery |
| Current fenced worker | Claim paid jobs; commit its current unexpired lease | Unpaid jobs, stale-token commits, attempt counter reset |

Every private route resolves buyer identity from the session, then enforces stored object ownership. A purchase ID and transaction hash are not credentials. Recheck finalized key membership for session access. Bind challenge nonce to buyer, service origin, contract, fingerprint and expiry; consume and create the session atomically to prevent concurrent replay. Store only a digest of the random bearer token; expire after 15 minutes and allow logout/revocation.

## Replay, payment and concurrency
Persist quote intent before registration; recover an ambiguous registration by get_quote and full comparison. Persist buyer purchase intent and signed bytes before broadcast. Check accepted purchase before new-quote expiry. A duplicate paid call must reject without retaining a second service deposit; inspect completed refunds and gas separately. Only independent finalized exact-binding lookup can unlock delivery. A fresh sandbox reusing account names must not reuse an old database or buyer intent.

SQLite unique keys and short transactions protect durable idempotency. Worker lease token must match on success and failure; result+terminal state commit atomically. There is no lease renewal in this bounded deterministic service; expired computations lose commit rights. Never reset lifetime attempts. Recover expired leases even when the third attempt crashed. State precisely that work may be recomputed.

## Input and abuse controls
Bind localhost only and reject nonlocal RPC targets/redirects. Accept bounded JSON with at most 128 KiB canonical service input, 1000 flat rows and 32 fields; validate rule names, scalar lengths/types and unsupported prototype keys before persistence. Queries use bound SQL parameters. Bound authentication requests and stored sessions/challenges; public deployment quotas, pruning and storage economics require explicit release review. No untrusted code execution, URLs, file uploads or external service calls are part of the report service.

## Failure, retention and release
Payment and delivery remain separate after crashes. Paid-but-failed output has no automatic refund promise; buyer retry stays within the same purchase and lifetime cap. Canonical results are immutable once committed. No destructive deletion API is in scope; local fixtures/results remain on disk until explicit operator cleanup. Back up a real database before migrations; refuse checksum drift. Never silently reset on environment or schema mismatch.

Required adversarial proof: unauthenticated/wrong-role/cross-object denial; challenge expiry/replay/concurrency; restricted/revoked keys; payload conflicts; independent finalized payment; fresh-chain mismatch; two workers/stale commits; all crash windows; final-attempt exhaustion; malformed/oversized inputs; secret/log scan. Production TLS, external rate limiting, operational monitoring, deployment hardening, commercial remedies and testnet behavior remain outside local proof.


## Dependency advisory result
The November 5 scan found zero moderate/high/critical advisories after pinned tar/decode-uri-component overrides. One unpatched low-severity deepmerge advisory remains in @rollup/plugin-node-resolve under near-sdk-js build tooling; the running API/report code does not use it to merge buyer input. The full audit result is in outputs/product/dependency-audit.json. External deployment requires a fresh audit.
