# Oncefolio — build plan

Status: local MVP implemented and exercised. Updated November 5, 2026. Latest product status is generated in outputs/product/result.json; README.md contains runnable commands. Historical payment proof remains in outputs/feasibility/.

## First technical feasibility test — payment recovery and concurrency
The user authorized this local test. The spike uses NEAR sandbox 2.13.4 and a minimal NEAR SDK JS 2.0.0 contract. Testnet confirmation remains separate. Official receipt/finality documentation and the pinned runtime implementation underpin the accounting checks.

1. Define a canonical immutable binding: buyer account, provider account, quote ID/version, amount in yoctoNEAR, expiry and canonical request digest. Scope purchase IDs globally in the contract or explicitly namespace them by buyer; never use an unqualified client key as authorization.
2. Persist the purchase ID and exact binding before any signing. Contract acceptance authenticates the buyer and binds the actual transferred amount to the quote. A finalized accepted purchase must be discoverable through a read method without paying again.
3. Send two independently signed, concurrent calls for the same ID and binding. Interrupt the client after broadcast but before its response. Restart it with an empty in-memory cache and recover through durable state and chain reads.
4. Reject changed buyer, provider, amount, quote or request under an existing ID. Preserve the original record. Require ownership checks for private offchain results; possession of an ID is insufficient.
5. Inject a pre-acceptance failure and an accepted-but-response-lost outcome. Retry only according to observed state; pending/unknown is never permission to create a fresh purchase ID.
6. Inspect final execution outcomes and receipt chains, contract/provider balances, attached deposits, refunds, gas and storage effects. Rejected duplicate calls must not retain a second service payment. A refund scheduled asynchronously is not proof that it completed.

PASS: one immutable accepted purchase and one retained service payment across retries; every duplicate deposit is rejected/refunded with verified outcomes; a new process retrieves the accepted purchase. Report gas and storage separately, since retries can still incur costs. FAIL: duplicate retention, conflicting bindings, missing recovery evidence or unexplained funds. If refunds/payouts cross asynchronous receipts, model those transitions explicitly before proceeding.

The executed checks cover the bounded payment invariant only. They do not prove exactly-once external work, useful delivery, provider payout or a production payment system. Full final receipt trees, exact system deposit refunds, per-payer gas charges, protocol-derived contract gas rewards and storage lock changes are captured. The mutation check deliberately accepts a duplicate deposit and verifies that the race test fails; the source is restored before the final clean run.

## Actor-goal flows and proof
| Flow | Entry → outcome | Essential failure/recovery proof |
| --- | --- | --- |
| Buyer purchases a report | Request → quote → durable purchase ID → payment → report | Expired quote, wrong amount, payload conflict, payment rejection, lost response and concurrent retries |
| Buyer resumes a purchase | Restart + persisted identity/ID → existing payment and result/status | Unknown transaction, pending result, failed result, unavailable RPC and unauthorized lookup |
| Provider completes delivery | Finalized payment → claimed job → durable canonical result | Worker restart, lease expiry, duplicated work, stale worker completion and recoverable stored result |

Payment state and service state are separate. ASSUMED payment states: unsubmitted, pending/unknown, accepted, rejected; add refund/payout states if the tested design requires them. ASSUMED delivery states: not-started, pending, succeeded, failed. Delivery retry reuses the paid purchase and creates no new charge. A worker lease and fenced result commit may allow repeated computation while preserving one canonical result; describe that limitation honestly.

Dependencies/regression map: quote immutability → contract acceptance → finality reconciliation → durable job eligibility → provider execution → result ownership/retrieval. Changes to identity, canonicalization, quotes or payment recognition require rerunning the complete interrupted-purchase flow.

## Key open decisions
The local MVP resolves service, stack, identity, storage and failure-retry defaults below. Release choices remain open.

| Decision | Recommended default | Resolve before |
| --- | --- | --- |
| Integrated service | IMPLEMENTED: bounded deterministic structured-data validation report | Service extensions deferred |
| Payment custody and provider payout | IMPLEMENTED: provider equals contract account; first accepted deposit credits provider in one receipt. No separate payout or automatic service-failure refund | Commercial remedy before external release |
| Quote authority and expiry | IMPLEMENTED: provider-only immutable onchain quote, canonical request digest, decimal price and expiry | Expired unpaid quote renewal deferred |
| Buyer identity/signing | IMPLEMENTED: separate buyer/provider accounts; standard NEP-413 challenges and finalized FullAccess checks; durable signed attempts and buyer-only results | Hardware wallets/external networks deferred |
| Stack and storage | IMPLEMENTED: Node 24 ESM API/CLI, node:sqlite WAL and checksum migrations, NEAR SDK JS contract with pinned native ARM tools | Other platforms before release |
| Recovery and retention | IMPLEMENTED: durable request/results, unique purchases, fenced commits and environment mismatch rejection. Local fixtures retained until explicit removal | Release retention/deletion policy |
| Failure remedy | IMPLEMENTED: visibly paid-but-failed; three lifetime delivery attempts under same purchase, no automatic refund | Commercial remedy before release |
| Submission compliance | Canonical rules retrieved: testnet and local-only demos are eligible. Confirm final track, prepare a video for local-only submission and name Lotveil in README | Submission |

## Proposed sequence after authorization
- November 4–5: retrieve rules, resolve critical decisions, run first feasibility test. Stop and revise if payment accounting cannot be demonstrated.
- November 6–7: implement one buyer-to-provider slice with durable records, authenticated retrieval, migrations and restart recovery.
- November 8–9: inject concurrency, network interruption and worker failures; verify authorization and payment/delivery separation.
- November 10–11: prototype and review any substantial demo UI before implementation; complete the recovery walkthrough and accessible status/error states.
- November 12–13: run fresh sandbox/testnet evidence, reconcile money movements, prepare reproducible README and demo materials; cross-reference independent Lotveil project.
- November 14: recheck official requirements and perform final reproducibility review with time before 23:59 UTC. Public repo, demo posting and submission require subsequent authorization.

## Evidence and completion gates
Setup check: both requested documents exist and cover scope, recovery, first test and open decisions. Self-reviewed, lower assurance; no independent technical review in this setup task.

Local foundation execution, migrations, real-caller authorization, delivery and recovery are now exercised by scripts/product-verify.mjs using BUILD_VERIFICATION.json. Toolchain bootstrap and database bootstrap are idempotent; schema replay is deterministic. Independent review addressed stale signing nonce recovery, transient key-query errors, session expiry/logout races and CLI entrypoint collision. Production security, external payout/remedies, other operating systems and testnet remain unverified.

Preserve screenshots/logs/transaction hashes and a balance reconciliation for the final demo. Demonstrate pay → disconnect → restart → same purchase/result, plus concurrent retry, changed payload, payment failure and pending/failed delivery cases. Record verified behavior separately from limitations.
