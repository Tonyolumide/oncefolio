# Client questions

## Decisions that unblock correctness
None pending for the authorized local MVP. The user has authorized building; no further permission is needed for local reversible implementation and tests.

## Confirm or correct
The build orchestrator's reversible default is an API/CLI structured-data validation service with required-field, type and duplicate checks. The local provider is its own contract account, reports payment and delivery separately, and offers bounded reruns under the same purchase rather than an automatic service-failure refund. These choices are explicit in the brief and security model; they must be revisited before a public paid launch.

## Deferred or discoverable
- Buyer wallet UX and a substantial web UI: separate later product scope; this headless flow does not need a visual prototype.
- Testnet deployment, hosting, mainnet credentials, publication, submission and expenditure: outside current authority, not blockers to local proof.
- Production retention/deletion, quotas, price, refund policy and custody: operator/user decisions before public release; local data is retained until an explicit local cleanup.
- Exact route/CLI behavior and evidence paths: inspect implementation and generated proof, rather than ask the user to specify internals.
- Name availability and legal clearance: provisional; neither domains nor trademarks have been cleared.
