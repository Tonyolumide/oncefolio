import { readFileSync, writeFileSync, openSync, closeSync, fsyncSync, renameSync } from 'node:fs';
import { dirname } from 'node:path';
import { randomUUID } from 'node:crypto';
import { pathToFileURL } from 'node:url';

export function localUrl(url) {
  const u = new URL(url);
  if (u.protocol !== 'http:' || u.hostname !== '127.0.0.1') throw new Error('LOCAL_RPC_ONLY');
  return url;
}

export async function rpc(url, method, params) {
  const response = await fetch(localUrl(url), {
    method: 'POST', redirect: 'error', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 'oncefolio-spike', method, params }),
    signal: AbortSignal.timeout(20000),
  });
  if (!response.ok) throw new Error(`RPC_HTTP_${response.status}`);
  const body = await response.json();
  if (body.error) throw new Error(JSON.stringify(body.error));
  return body.result;
}

export function persist(path, value) {
  const tmp = `${path}.${randomUUID()}.tmp`;
  const fd = openSync(tmp, 'wx', 0o600);
  try { writeFileSync(fd, JSON.stringify(value, null, 2)); fsyncSync(fd); } finally { closeSync(fd); }
  renameSync(tmp, path);
  const dir = openSync(dirname(path), 'r');
  try { fsyncSync(dir); } finally { closeSync(dir); }
}

export async function recover(intent, url = intent.rpcUrl) {
  try {
    const response = await rpc(url, 'query', {
      request_type: 'call_function', finality: 'final', account_id: intent.binding.contract_id,
      method_name: 'get_purchase',
      args_base64: Buffer.from(JSON.stringify({ purchase_id: intent.binding.purchase_id })).toString('base64'),
    });
    const purchase = JSON.parse(Buffer.from(response.result).toString());
    if (!purchase) return { status: 'unresolved', purchase_id: intent.binding.purchase_id };
    if (purchase.payment !== 'accepted') return { status: 'unresolved', purchase_id: intent.binding.purchase_id };
    const fields = Object.keys(intent.binding);
    if (Object.keys(purchase.binding).length !== fields.length || !fields.every(f => purchase.binding[f] === intent.binding[f])) {
      return { status: 'conflict', purchase_id: intent.binding.purchase_id };
    }
    return { status: 'accepted', purchase, block_hash: response.block_hash, block_height: response.block_height };
  } catch {
    return { status: 'unresolved', purchase_id: intent.binding.purchase_id };
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [mode, path, overrideUrl] = process.argv.slice(2);
  const intent = JSON.parse(readFileSync(path, 'utf8'));
  if (mode === 'broadcast') {
    process.stdout.write('broadcast-started\n');
    await rpc(overrideUrl ?? intent.rpcUrl, 'send_tx', {
      signed_tx_base64: intent.signed_tx_base64, wait_until: 'FINAL',
    });
    process.stdout.write('broadcast-response-received\n');
  } else if (mode === 'recover') {
    process.stdout.write(`${JSON.stringify(await recover(intent, overrideUrl))}\n`);
  } else throw new Error('UNKNOWN_MODE');
}
