# Local payment feasibility spike

This is a bounded experiment, not the Oncefolio application. It executes a real NEAR contract on an ephemeral local sandbox with generated local accounts. It never connects to testnet/mainnet, spends real tokens, or publishes anything.

## Boundary
The provider registers a quote binding a globally scoped purchase ID to network label, contract, provider, buyer, quote ID/version, decimal yoctoNEAR amount, lowercase SHA-256 request digest and nanosecond expiry. The contract authenticates the immediate caller, retains the first accepted deposit and rejects duplicates through receipt failure. The runtime handles rejected attached-deposit refunds. Accepted records take precedence over expiry checks.

Funds remain in the contract. There is no provider payout, service execution, result storage, wallet UI or production custody mechanism. The contract's full-access key remains an administrative trust boundary. Onchain metadata is public; do not put private requests or results in it. The provider subsidizes state storage from the local contract's initial balance. Quote registration is provider-only and immutable, but total quote count/retention is not production-bounded.

The restarted client reads finalized chain state and compares every bound field. Missing state and RPC failure both remain unresolved. It does not invent a new purchase ID or automatically sign another payment. Exact signed bytes can be rebroadcast; a new independently signed retry instead reaches the contract's duplicate check and can still burn gas.

## Reproduce
The verified toolchain targets macOS ARM64 and requires Node 24.22.1 and pnpm 11.25.0. Package versions and integrity data are locked in `pnpm-lock.yaml`; native download URLs and SHA-256 hashes are in `spike/toolchain-lock.json`. Native hashes pin the observed downloads; they are not a separate publisher signature verification.

```sh
pnpm install --ignore-scripts
node scripts/setup-toolchain.mjs
node scripts/verify.mjs
```

Setup downloads tools into `work/` and links them into the workspace's SDK installation. It performs no global installation. NEAR SDK JS's default compiler download is Intel-only on this host; this spike uses the pinned native ARM WASI SDK 25 instead. Other operating systems have not been verified.

The sandbox binary needs `liblzma.5.dylib`. A normal Homebrew xz installation supplies it. On this machine `scripts/environment.mjs` reuses the bundled Codex runtime library. An existing compatible library directory can also be supplied with `ONCEFOLIO_NATIVE_LIB_DIR`; the script does not install system libraries. Localhost port binding must be permitted.

`scripts/verify.mjs` builds fresh Wasm, runs the integration tests, checks exit codes and expected test counts, and writes `outputs/feasibility/result.json`. Raw final outcomes, public transaction hashes and account/storage snapshots are in `outputs/feasibility/evidence.json`. Build/test logs are alongside them; command definitions, hashes and exit codes are captured in `evidence/verification/command-transcript.json`.

The test stores signed local transaction bytes and purchase intents under ignored `work/intents/` with mode 0600, using fsync and atomic rename before broadcast. Generated private account keys remain in the temporary sandbox directory, which is torn down after the run. Never fund these ephemeral test accounts or reuse them outside the sandbox.

## Required observations
- Two independent buyer keys race: one purchase accepted, one duplicate rejected.
- Changed bound fields conflict; the original record survives.
- Wrong caller, wrong deposit, expired quote, missing quote and invalid input reject; quote registration and overwrites enforce provider permissions.
- A localhost proxy forwards payment to the node but withholds its response. Kill the client with SIGKILL, start a fresh process and recover the same finalized purchase.
- Replay identical signed bytes without another balance change; unavailable RPC stays unresolved.
- Persist an intent without broadcasting: recovery does not claim payment or charge.
- Retry an accepted purchase after quote expiry: preserve the purchase and reject another deposit.

## Sources and rules
Official rules retrieved November 4, 2026: https://nearhackathon.com/HACKATHON.md (snapshot under ignored `work/HACKATHON.md`). Q-010 permits testnet-only entries; Q-012 permits local-only demos with public reproducible code and an X video. Q-015 requires independent Oncefolio and Lotveil projects to name each other in their final READMEs. Deadline: November 14, 2026 at 23:59 UTC. Recheck the live rules before submission. No publication or submission is authorized here.

NEAR integration testing: https://docs.near.org/smart-contracts/testing/integration-test

Receipt execution/finality: https://docs.near.org/protocol/transaction-execution

Transaction and receipt RPC: https://docs.near.org/api/rpc/transactions

Pinned runtime accounting implementation: https://github.com/near/nearcore/blob/2.13.4/runtime/runtime/src/lib.rs

## Assurance
The payment design and implementation received an independent adversarial review; review findings led to per-payer accounting, full receipt retrieval, strict local-only redirects, explicit payment-state checks and exit-code-gated reporting. This is not an audit. Product foundation, delivery/result recovery, testnet behavior and production security remain unverified.
