import { near } from 'near-sdk-js';

const FIELDS = ['network', 'contract_id', 'provider', 'buyer', 'purchase_id', 'quote_id', 'quote_version', 'amount', 'request_digest', 'expires_at_ns'];
const check = (condition, error) => { if (!condition) throw new Error(error); };
const args = () => JSON.parse(near.input() || '{}');
const read = key => { const value = near.storageRead(key); return value === null ? null : JSON.parse(value); };
const write = (key, value) => near.storageWrite(key, JSON.stringify(value));
const reply = value => near.valueReturn(JSON.stringify(value));
const id = value => typeof value === 'string' && /^[a-z0-9][a-z0-9_-]{0,63}$/.test(value);
const account = value => typeof value === 'string' && value.length >= 2 && value.length <= 64 && /^(([a-z0-9]+[-_])*[a-z0-9]+\.)*([a-z0-9]+[-_])*[a-z0-9]+$/.test(value);
const positive = value => typeof value === 'string' && /^[1-9][0-9]{0,38}$/.test(value) && BigInt(value) < (1n << 128n);
const nonpayable = () => check(near.attachedDeposit() === 0n, 'NONPAYABLE');
const config = () => { const c = read('config'); check(c !== null, 'NOT_INITIALIZED'); return c; };

function canonical(b) {
  check(b && typeof b === 'object' && Object.keys(b).length === FIELDS.length, 'INVALID_BINDING');
  check(FIELDS.every(f => Object.prototype.hasOwnProperty.call(b, f)), 'INVALID_BINDING');
  return Object.fromEntries(FIELDS.map(f => [f, b[f]]));
}

function validate(b) {
  check(b.network === (config().network || 'sandbox') && b.contract_id === near.currentAccountId(), 'WRONG_SCOPE');
  check(account(b.buyer) && account(b.provider), 'INVALID_ACCOUNT');
  check(id(b.purchase_id) && id(b.quote_id) && id(b.quote_version), 'INVALID_ID');
  check(positive(b.amount) && positive(b.expires_at_ns), 'INVALID_AMOUNT_OR_EXPIRY');
  check(typeof b.request_digest === 'string' && /^[0-9a-f]{64}$/.test(b.request_digest), 'INVALID_DIGEST');
}

export function init() {
  nonpayable();
  check(near.predecessorAccountId() === near.currentAccountId(), 'SELF_ONLY');
  check(read('config') === null, 'ALREADY_INITIALIZED');
  const { provider, network = 'sandbox' } = args(); check(account(provider), 'INVALID_ACCOUNT');
  check(network === 'sandbox' || network === 'testnet', 'INVALID_NETWORK');
  write('config', { provider, network });
}

export function register_quote() {
  nonpayable();
  const c = config(); check(near.predecessorAccountId() === c.provider, 'PROVIDER_ONLY');
  const b = canonical(args().binding); validate(b);
  check(b.provider === c.provider, 'WRONG_PROVIDER');
  check(read(`quote:${b.purchase_id}`) === null, 'QUOTE_EXISTS');
  write(`quote:${b.purchase_id}`, b);
  reply(b);
}

export function accept() {
  const c = config();
  const b = canonical(args().binding);
  check(id(b.purchase_id), 'INVALID_ID');
  const old = read(`purchase:${b.purchase_id}`);
  if (old !== null) {
    check(JSON.stringify(old.binding) === JSON.stringify(b), 'PURCHASE_CONFLICT');
    check(near.predecessorAccountId() === old.binding.buyer, 'BUYER_ONLY');
    // Panic rolls back this receipt and invokes the runtime's deposit refund path.
    // Do not return success and silently retain a repeated attached deposit.
    throw new Error('DUPLICATE_PURCHASE');
  }
  validate(b);
  check(near.predecessorAccountId() === b.buyer, 'BUYER_ONLY');
  check(b.provider === c.provider, 'WRONG_PROVIDER');
  const quote = read(`quote:${b.purchase_id}`);
  check(quote !== null, 'QUOTE_MISSING');
  check(JSON.stringify(quote) === JSON.stringify(b), 'QUOTE_CONFLICT');
  check(near.blockTimestamp() <= BigInt(b.expires_at_ns), 'QUOTE_EXPIRED');
  check(near.attachedDeposit() === BigInt(b.amount), 'WRONG_DEPOSIT');
  const purchase = { binding: b, payment: 'accepted', accepted_at_ns: near.blockTimestamp().toString() };
  write(`purchase:${b.purchase_id}`, purchase);
  reply(purchase);
}

export function get_purchase() {
  nonpayable();
  const { purchase_id } = args(); check(id(purchase_id), 'INVALID_ID');
  reply(read(`purchase:${purchase_id}`));
}

export function get_quote() {
  nonpayable();
  const { purchase_id } = args(); check(id(purchase_id), 'INVALID_ID');
  reply(read(`quote:${purchase_id}`));
}

export function get_config() {
  nonpayable();
  reply(config());
}
