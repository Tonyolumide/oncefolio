import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, mkdirSync, rmSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import http from 'node:http';
import { resolve } from 'node:path';
import { Sandbox } from 'near-sandbox';
import { Account, JsonRpcProvider, KeyPair, actions, baseEncode, nearToYocto } from 'near-api-js';
import { rpc, persist } from './client.mjs';

const EVIDENCE = resolve('outputs/feasibility');
const GAS = 100_000_000_000_000n;
const PRICE = nearToYocto('0.1');
const bindingFields = ['network', 'contract_id', 'provider', 'buyer', 'purchase_id', 'quote_id', 'quote_version', 'amount', 'request_digest', 'expires_at_ns'];
const digest = createHash('sha256').update('structured-report-request-v1').digest('hex');
const artifact = resolve('build/contract.wasm');
const wait = ms => new Promise(r => setTimeout(r, ms));
const asJson = x => JSON.parse(JSON.stringify(x, (_, v) => typeof v === 'bigint' ? v.toString() : v));

async function runClient(mode, path, url) {
  const child = spawn(process.execPath, [resolve('spike/client.mjs'), mode, path, ...(url ? [url] : [])]);
  let stdout = '', stderr = '';
  child.stdout.on('data', x => { stdout += x; });
  child.stderr.on('data', x => { stderr += x; });
  const [code] = await once(child, 'exit');
  assert.equal(code, 0, stderr);
  return JSON.parse(stdout.trim());
}

test('local NEAR payment acceptance survives retries and client restart', { timeout: 240000 }, async t => {
  const wasm = readFileSync(artifact); // Must be a real compiled contract, never a mock.
  mkdirSync(EVIDENCE, { recursive: true });
  rmSync(`${EVIDENCE}/evidence.json`, { force: true });
  mkdirSync('work/intents', { recursive: true });
  const sandbox = await Sandbox.start({ version: '2.13.4' });
  const provider = new JsonRpcProvider({ url: sandbox.rpcUrl });
  const protocol = await rpc(sandbox.rpcUrl, 'EXPERIMENTAL_protocol_config', { finality: 'final' });
  const rewardRatio = protocol.runtime_config.transaction_costs.burnt_gas_reward;
  assert.equal(rewardRatio.length, 2);
  const validator = JSON.parse(readFileSync(`${sandbox.homeDir}/validator_key.json`, 'utf8'));
  const root = new Account(validator.account_id, provider, validator.secret_key);
  const accounts = {};
  const keys = {};
  const evidence = { started: new Date().toISOString(), versions: { node: process.version, sandbox: '2.13.4', sdk: '2.0.0', api: '7.4.0' }, protocol_version: protocol.protocol_version, gas_reward_ratio: rewardRatio, storage_amount_per_byte: protocol.runtime_config.storage_amount_per_byte, wasm_sha256: createHash('sha256').update(wasm).digest('hex'), scope: 'local-sandbox-only; funds retained in contract; no provider payout or delivery', cases: [] };
  let proxy;
  try {
    for (const name of ['buyer', 'provider', 'contract', 'other']) {
      keys[name] = KeyPair.fromRandom('ed25519');
      const accountId = `${name}.${root.accountId}`;
      await root.createAccount({ newAccountId: accountId, publicKey: keys[name].getPublicKey(), nearToTransfer: nearToYocto('20') });
      accounts[name] = new Account(accountId, provider, keys[name].toString());
    }
    const secondKey = KeyPair.fromRandom('ed25519');
    await accounts.buyer.signAndSendTransaction({ receiverId: accounts.buyer.accountId, actions: [actions.addFullAccessKey(secondKey.getPublicKey())], waitUntil: 'FINAL' });
    const buyer2 = new Account(accounts.buyer.accountId, provider, secondKey.toString());
    await accounts.contract.deployContract(wasm);

    async function send(account, methodName, args, deposit = 0n) {
      const signed = await account.createSignedTransaction({ receiverId: accounts.contract.accountId, actions: [actions.functionCall(methodName, args, GAS, deposit)] });
      const result = await rpc(sandbox.rpcUrl, 'send_tx', { signed_tx_base64: Buffer.from(signed.encode()).toString('base64'), wait_until: 'FINAL' });
      return await rpc(sandbox.rpcUrl, 'EXPERIMENTAL_tx_status', { tx_hash: result.transaction.hash, sender_account_id: account.accountId, wait_until: 'FINAL' });
    }
    async function view(method, args) {
      const result = await rpc(sandbox.rpcUrl, 'query', { request_type: 'call_function', finality: 'final', account_id: accounts.contract.accountId, method_name: method, args_base64: Buffer.from(JSON.stringify(args)).toString('base64') });
      return JSON.parse(Buffer.from(result.result).toString());
    }
    async function snapshot() {
      const result = {};
      for (const [name, account] of Object.entries(accounts)) result[name] = await rpc(sandbox.rpcUrl, 'query', { request_type: 'view_account', finality: 'final', account_id: account.accountId });
      return result;
    }
    async function binding(id, expiry) {
      const block = await rpc(sandbox.rpcUrl, 'block', { finality: 'final' });
      return { network: 'sandbox', contract_id: accounts.contract.accountId, provider: accounts.provider.accountId, buyer: accounts.buyer.accountId, purchase_id: id, quote_id: `quote-${id}`, quote_version: '1', amount: PRICE.toString(), request_digest: digest, expires_at_ns: expiry ?? (BigInt(block.header.timestamp_nanosec) + 300_000_000_000n).toString() };
    }
    function ok(outcome) { assert.ok(outcome.status.SuccessValue !== undefined, JSON.stringify(outcome.status)); }
    function rejected(outcome, code) { assert.match(JSON.stringify(outcome.status), new RegExp(code)); }
    async function register(b) { const o = await send(accounts.provider, 'register_quote', { binding: b }); ok(o); return o; }
    async function record(name, before, outcomes, accepted, extra = {}) {
      // FINAL includes refund receipts. Retry snapshot only to let final query advance to receipt finality.
      const after = await snapshot();
      persist('work/accounting-debug.json', asJson({ name, before, after, outcomes, accepted }));
      const payerDebits = {};
      let totalReportedGas = 0n;
      let expectedContractReward = 0n;
      const refundProof = [];
      for (const outcome of outcomes) {
        assert.equal(outcome.final_execution_status, 'FINAL');
        const all = [outcome.transaction_outcome, ...outcome.receipts_outcome];
        const ids = new Set(all.map(r => r.id));
        const receiptDetails = new Map(outcome.receipts.map(r => [r.receipt_id, r]));
        for (const r of all) for (const id of r.outcome.receipt_ids) assert.ok(ids.has(id), `Missing receipt ${id}`);
        const refunds = outcome.receipts.filter(r => r.predecessor_id === 'system' && r.receipt.Action?.signer_id === 'system');
        let refundedDeposit = 0n;
        for (const r of refunds) {
          assert.equal(r.receiver_id, outcome.transaction.signer_id, 'Deposit refund sent to wrong account');
          assert.ok(all.find(o => o.id === r.receipt_id)?.outcome.status.SuccessValue !== undefined, 'Deposit refund receipt did not succeed');
          for (const action of r.receipt.Action.actions) { assert.ok(action.Transfer); refundedDeposit += BigInt(action.Transfer.deposit); }
        }
        const attachedDeposit = BigInt(outcome.transaction.actions[0].FunctionCall.deposit);
        assert.equal(refundedDeposit, outcome.status.Failure ? attachedDeposit : 0n, 'Exact rejected deposit not refunded');
        refundProof.push({ tx_hash: outcome.transaction.hash, deposit_refund: refundedDeposit.toString(), receipts: refunds.map(r => r.receipt_id) });
        for (const receipt of outcome.receipts_outcome) {
          // Failed function-call receipts are intentional; refund transfer receipts must succeed.
          if (receipt.outcome.executor_id !== accounts.contract.accountId) assert.ok(!receipt.outcome.status.Failure, JSON.stringify(receipt));
          else {
            const detail = receiptDetails.get(receipt.id);
            assert.equal(detail?.receipt.Action.actions.length, 1);
            assert.ok(detail.receipt.Action.actions[0].FunctionCall);
            const hostGas = receipt.outcome.metadata.gas_profile.filter(p => p.cost_category === 'WASM_HOST_COST').reduce((sum, p) => sum + BigInt(p.gas_used), 0n);
            const block = await rpc(sandbox.rpcUrl, 'block', { block_id: receipt.block_hash });
            expectedContractReward += (hostGas * BigInt(rewardRatio[0]) / BigInt(rewardRatio[1])) * BigInt(block.header.gas_price);
          }
        }
        const gas = all.reduce((sum, r) => sum + BigInt(r.outcome.tokens_burnt), 0n);
        totalReportedGas += gas;
        const payer = outcome.transaction.signer_id;
        payerDebits[payer] = (payerDebits[payer] ?? 0n) + gas;
      }
      let actualPayerDebit = 0n;
      const perPayer = {};
      for (const [name, account] of Object.entries(accounts)) {
        if (account.accountId in payerDebits) {
          const actual = BigInt(before[name].amount) - BigInt(after[name].amount);
          const acceptedByPayer = outcomes.filter(o => o.transaction.signer_id === account.accountId && o.status.SuccessValue !== undefined).reduce((sum, o) => sum + BigInt(o.transaction.actions[0].FunctionCall.deposit), 0n);
          assert.equal(actual, acceptedByPayer + payerDebits[account.accountId], `Payer ${name} funds do not reconcile`);
          actualPayerDebit += actual;
          perPayer[name] = { actual_debit: actual, retained_deposit: acceptedByPayer, gas_charge: payerDebits[account.accountId] };
        }
      }
      const retained = BigInt(accepted) * PRICE;
      const contractDelta = BigInt(after.contract.amount) - BigInt(before.contract.amount);
      const reward = contractDelta - retained;
      assert.equal(reward, expectedContractReward, 'Contract balance differs from accepted deposits plus protocol gas rewards');
      assert.equal(actualPayerDebit, retained + totalReportedGas, 'Attached deposits/refunds or charged gas do not reconcile');
      assert.equal(BigInt(after.provider.amount), BigInt(before.provider.amount), 'Spike must not claim provider payout');
      const row = asJson({ name, before, after, accepted_deposits: retained, attached_deposits: outcomes.reduce((sum, o) => sum + BigInt(o.transaction.actions[0].FunctionCall.deposit), 0n), actual_payer_debit: actualPayerDebit, per_payer: perPayer, refund_proof: refundProof, reported_gas_charge: totalReportedGas, contract_delta: contractDelta, contract_gas_reward: reward, expected_contract_gas_reward: expectedContractReward, storage_bytes_delta: after.contract.storage_usage - before.contract.storage_usage, storage_lock_delta: BigInt(after.contract.storage_usage - before.contract.storage_usage) * BigInt(protocol.runtime_config.storage_amount_per_byte), outcomes, ...extra });
      evidence.cases.push(row);
      persist(`${EVIDENCE}/evidence.json`, evidence);
    }

    ok(await send(accounts.contract, 'init', { provider: accounts.provider.accountId }));

    await t.test('two buyer keys race; only one purchase accepts a deposit', async () => {
      const b = await binding('race'); await register(b);
      const before = await snapshot();
      const outcomes = await Promise.all([send(accounts.buyer, 'accept', { binding: b }, PRICE), send(buyer2, 'accept', { binding: b }, PRICE)]);
      assert.equal(outcomes.filter(o => o.status.SuccessValue !== undefined).length, 1);
      rejected(outcomes.find(o => o.status.Failure), 'DUPLICATE_PURCHASE');
      assert.deepEqual((await view('get_purchase', { purchase_id: b.purchase_id })).binding, b);
      await record('concurrent-retries', before, outcomes, 1);
    });

    await t.test('every changed bound field rejects without mutating the accepted purchase', async () => {
      const b = await binding('conflict'); await register(b);
      const before = await snapshot(); const initial = await send(accounts.buyer, 'accept', { binding: b }, PRICE); ok(initial);
      const outcomes = [initial];
      for (const field of bindingFields.filter(f => f !== 'purchase_id')) {
        const changed = { ...b, [field]: field === 'amount' ? (PRICE + 1n).toString() : field === 'expires_at_ns' ? (BigInt(b.expires_at_ns) + 1n).toString() : field === 'request_digest' ? 'f'.repeat(64) : `${b[field]}-changed` };
        const outcome = await send(accounts.buyer, 'accept', { binding: changed }, PRICE);
        rejected(outcome, 'PURCHASE_CONFLICT'); outcomes.push(outcome);
      }
      assert.deepEqual((await view('get_purchase', { purchase_id: b.purchase_id })).binding, b);
      const wrongBuyer = await send(accounts.other, 'accept', { binding: b }, PRICE);
      rejected(wrongBuyer, 'BUYER_ONLY'); outcomes.push(wrongBuyer);
      await record('binding-conflicts', before, outcomes, 1);
    });

    await t.test('wrong caller, wrong deposit, expiry, missing quote and quote permissions', async () => {
      const b = await binding('invalid'); await register(b);
      rejected(await send(accounts.other, 'register_quote', { binding: await binding('unauthorized') }), 'PROVIDER_ONLY');
      rejected(await send(accounts.provider, 'register_quote', { binding: b }), 'QUOTE_EXISTS');
      rejected(await send(accounts.other, 'init', { provider: accounts.other.accountId }), 'SELF_ONLY');
      const expired = await binding('expired', '1'); await register(expired);
      const before = await snapshot(); const outcomes = [];
      for (const [account, value, deposit, error] of [
        [accounts.other, b, PRICE, 'BUYER_ONLY'],
        [accounts.buyer, b, PRICE - 1n, 'WRONG_DEPOSIT'],
        [accounts.buyer, expired, PRICE, 'QUOTE_EXPIRED'],
        [accounts.buyer, { ...b, purchase_id: 'missing' }, PRICE, 'QUOTE_MISSING'],
        [accounts.buyer, { ...b, request_digest: 'invalid' }, PRICE, 'INVALID_DIGEST'],
        [accounts.buyer, { ...b, amount: '0' }, PRICE, 'INVALID_AMOUNT_OR_EXPIRY'],
        [accounts.buyer, { ...b, amount: (PRICE + 1n).toString() }, PRICE, 'QUOTE_CONFLICT'],
        [accounts.buyer, { ...b, surprise: true }, PRICE, 'INVALID_BINDING'],
      ]) { const o = await send(account, 'accept', { binding: value }, deposit); rejected(o, error); outcomes.push(o); }
      for (const purchase_id of ['invalid', 'expired', 'missing', 'unauthorized']) assert.equal(await view('get_purchase', { purchase_id }), null);
      await record('rejected-payments', before, outcomes, 0);
    });

    await t.test('process is killed after broadcast; new process recovers; same signed bytes never recharge', async () => {
      const b = await binding('restart'); await register(b);
      const signed = await accounts.buyer.createSignedTransaction({ receiverId: b.contract_id, actions: [actions.functionCall('accept', { binding: b }, GAS, PRICE)] });
      const path = resolve('work/intents/restart.json');
      const txHash = baseEncode(createHash('sha256').update(signed.transaction.encode()).digest());
      persist(path, { rpcUrl: sandbox.rpcUrl, binding: b, txHash, signer: b.buyer, signed_tx_base64: Buffer.from(signed.encode()).toString('base64') });
      let forwarded;
      const received = new Promise((res, rej) => { forwarded = { res, rej }; });
      const sockets = new Set();
      proxy = http.createServer(async (req, response) => {
        try {
          const chunks = []; for await (const chunk of req) chunks.push(chunk);
          const payload = JSON.parse(Buffer.concat(chunks).toString());
          assert.equal(payload.method, 'send_tx');
          const outcome = await rpc(sandbox.rpcUrl, payload.method, payload.params);
          forwarded.res(outcome); // Intentionally withhold every byte of the HTTP response.
        } catch (e) { forwarded.rej(e); response.destroy(); }
      });
      proxy.on('connection', socket => { sockets.add(socket); socket.on('close', () => sockets.delete(socket)); });
      proxy.listen(0, '127.0.0.1'); await once(proxy, 'listening');
      const before = await snapshot();
      const child = spawn(process.execPath, [resolve('spike/client.mjs'), 'broadcast', path, `http://127.0.0.1:${proxy.address().port}`]);
      let output = ''; child.stdout.on('data', x => { output += x; });
      const initialOutcome = await received; ok(initialOutcome);
      const outcome = await rpc(sandbox.rpcUrl, 'EXPERIMENTAL_tx_status', { tx_hash: txHash, sender_account_id: b.buyer, wait_until: 'FINAL' });
      child.kill('SIGKILL'); const [, signal] = await once(child, 'exit');
      assert.equal(signal, 'SIGKILL'); assert.equal(output, 'broadcast-started\n');
      for (const socket of sockets) socket.destroy(); await new Promise(r => proxy.close(r)); proxy = undefined;
      const recovered = await runClient('recover', path);
      assert.equal(recovered.status, 'accepted'); assert.deepEqual(recovered.purchase.binding, b);
      await record('lost-response-process-restart', before, [outcome], 1, { txHash, child_signal: signal, client_output: output, recovered });
      const beforeReplay = await snapshot();
      const replay = await rpc(sandbox.rpcUrl, 'send_tx', { signed_tx_base64: Buffer.from(signed.encode()).toString('base64'), wait_until: 'FINAL' });
      assert.equal(replay.transaction.hash, txHash);
      const afterReplay = await snapshot();
      for (const name of Object.keys(accounts)) {
        assert.equal(afterReplay[name].amount, beforeReplay[name].amount);
        assert.equal(afterReplay[name].storage_usage, beforeReplay[name].storage_usage);
      }
      evidence.same_signed_transaction_replay = { txHash, no_balance_or_storage_change: true };
      const unresolved = await runClient('recover', path, 'http://127.0.0.1:1');
      assert.equal(unresolved.status, 'unresolved'); assert.equal(unresolved.purchase_id, b.purchase_id);
      const conflicting = resolve('work/intents/conflicting.json'); persist(conflicting, { ...JSON.parse(readFileSync(path)), binding: { ...b, request_digest: 'a'.repeat(64) } });
      assert.equal((await runClient('recover', conflicting)).status, 'conflict');
    });

    await t.test('persisted intent before broadcast stays unresolved without charging', async () => {
      const b = await binding('unbroadcast'); await register(b);
      const signed = await accounts.buyer.createSignedTransaction({ receiverId: b.contract_id, actions: [actions.functionCall('accept', { binding: b }, GAS, PRICE)] });
      const path = resolve('work/intents/unbroadcast.json'); persist(path, { rpcUrl: sandbox.rpcUrl, binding: b, signed_tx_base64: Buffer.from(signed.encode()).toString('base64') });
      const before = await snapshot(); const recovered = await runClient('recover', path);
      assert.equal(recovered.status, 'unresolved');
      const after = await snapshot();
      for (const name of Object.keys(accounts)) assert.equal(after[name].amount, before[name].amount);
      evidence.unbroadcast_recovery = recovered;
    });

    await t.test('accepted purchase remains recoverable after quote expiry', async () => {
      const block = await rpc(sandbox.rpcUrl, 'block', { finality: 'final' });
      const b = await binding('after-expiry', (BigInt(block.header.timestamp_nanosec) + 20_000_000_000n).toString());
      await register(b);
      const before = await snapshot(); const initial = await send(accounts.buyer, 'accept', { binding: b }, PRICE); ok(initial);
      await rpc(sandbox.rpcUrl, 'sandbox_fast_forward', { delta_height: 100 });
      for (let i = 0; i < 50; i++) { const latest = await rpc(sandbox.rpcUrl, 'block', { finality: 'final' }); if (BigInt(latest.header.timestamp_nanosec) > BigInt(b.expires_at_ns)) break; await wait(100); }
      const latest = await rpc(sandbox.rpcUrl, 'block', { finality: 'final' }); assert.ok(BigInt(latest.header.timestamp_nanosec) > BigInt(b.expires_at_ns));
      const outcome = await send(accounts.buyer, 'accept', { binding: b }, PRICE);
      rejected(outcome, 'DUPLICATE_PURCHASE'); assert.deepEqual((await view('get_purchase', { purchase_id: b.purchase_id })).binding, b);
      await record('accepted-after-expiry', before, [initial, outcome], 1);
    });
    evidence.completed = new Date().toISOString();
    persist(`${EVIDENCE}/evidence.json`, evidence);
  } finally {
    if (proxy) { proxy.closeAllConnections(); proxy.close(); }
    await sandbox.tearDown();
  }
});
