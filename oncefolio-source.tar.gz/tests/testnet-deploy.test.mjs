import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { prepareTestnet, planHash, deploymentBudget, verifyArtifacts } from '../scripts/testnet-prepare.mjs';
import { assertExecutionApproval, loadDeploymentInputs, testnetPreflight, deployTestnet } from '../scripts/testnet-deploy.mjs';

const protocol = { runtime_config: { storage_amount_per_byte: '10000000000000000000', transaction_costs: { action_receipt_creation_config: { send_sir: 10, execution: 10 }, action_creation_config: { deploy_contract_cost: { send_sir: 10, execution: 10 }, deploy_contract_cost_per_byte: { send_sir: 10, execution: 10 } } } } };
const environment = 'e'.repeat(64);

async function fixture(t) {
  const directory = mkdtempSync(join(tmpdir(), 'oncefolio-testnet-plan-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const options = { directory: join(directory, 'private'), outputDirectory: join(directory, 'public'), getFingerprint: async () => environment, readRpc: async (_url, method) => method === 'EXPERIMENTAL_protocol_config' ? protocol : { header: { gas_price: '100000000' } } };
  const prepared = await prepareTestnet(options);
  return { directory, options, prepared, inputs: loadDeploymentInputs(options.directory) };
}

test('local preparation is idempotent, keeps keys private and exports public plan only', async t => {
  const f = await fixture(t);
  const before = readFileSync(`${f.options.directory}/provider-key.json`, 'utf8');
  const repeated = await prepareTestnet(f.options);
  assert.equal(repeated.plan_sha256, f.prepared.plan_sha256);
  assert.equal(readFileSync(`${f.options.directory}/provider-key.json`, 'utf8'), before);
  assert.equal(statSync(`${f.options.directory}/provider-key.json`).mode & 0o777, 0o600);
  assert.equal(statSync(`${f.options.directory}/buyer-key.json`).mode & 0o777, 0o600);
  const publicPlan = readFileSync(`${f.options.outputDirectory}/deployment-plan.json`, 'utf8');
  assert.ok(!publicPlan.includes('secret_key'));
  assert.ok(!publicPlan.includes(JSON.parse(before).secret_key));
  assert.equal(planHash(JSON.parse(publicPlan)), repeated.plan_sha256);
});

test('execution requires exact reviewed public plan hash and refuses changed artifacts', async t => {
  const f = await fixture(t), plan = f.prepared.plan;
  assert.equal(assertExecutionApproval(plan, undefined, false), false);
  assert.throws(() => assertExecutionApproval(plan, undefined, true), e => e.code === 'EXACT_PLAN_APPROVAL_REQUIRED');
  assert.throws(() => assertExecutionApproval(plan, '0'.repeat(64), true), e => e.code === 'EXACT_PLAN_APPROVAL_REQUIRED');
  assert.equal(assertExecutionApproval(plan, planHash(plan), true), true);
  await assert.rejects(deployTestnet({ directory: f.options.directory, execute: true, approvedHash: '0'.repeat(64) }), e => e.code === 'EXACT_PLAN_APPROVAL_REQUIRED');
  const source = readFileSync('spike/contract.js');
  assert.throws(() => verifyArtifacts(plan, Buffer.from('changed artifact'), source, f.inputs.credentials), e => e.code === 'REVIEWED_ARTIFACT_CHANGED');
  assert.throws(() => verifyArtifacts(plan, f.inputs.wasm, Buffer.from('changed source'), f.inputs.credentials), e => e.code === 'REVIEWED_ARTIFACT_CHANGED');
  assert.throws(() => verifyArtifacts(plan, f.inputs.wasm, source, { ...f.inputs.credentials, provider: f.inputs.credentials.buyer }), e => e.code === 'REVIEWED_KEY_CHANGED');
});

test('mainnet, malformed accounts and larger attached validation budgets are rejected before any RPC', async t => {
  const { prepared } = await fixture(t);
  for (const plan of [
    { ...prepared.plan, network: 'mainnet' },
    { ...prepared.plan, rpc_url: 'https://rpc.mainnet.near.org' },
    { ...prepared.plan, accounts: { ...prepared.plan.accounts, provider: { ...prepared.plan.accounts.provider, account_id: 'existing.near' } } },
    { ...prepared.plan, budgets: { ...prepared.plan.budgets, max_validation_attached_deposits_yoctonear: '400000000000000000000000' } },
  ]) assert.throws(() => assertExecutionApproval(plan, undefined, false));
});

test('read-only preflight reports missing accounts without creating or funding anything', async t => {
  const f = await fixture(t), methods = [];
  const result = await testnetPreflight(f.inputs, { getFingerprint: async () => environment, readRpc: async (_url, method) => {
    methods.push(method);
    if (method === 'EXPERIMENTAL_protocol_config') return protocol;
    if (method === 'block') return { header: { gas_price: '100000000' } };
    throw new Error('UNKNOWN_ACCOUNT');
  } });
  assert.equal(result.accounts.provider.exists, false); assert.equal(result.accounts.buyer.exists, false);
  assert.deepEqual(methods, ['EXPERIMENTAL_protocol_config', 'block', 'query', 'query']);
});

test('preflight rejects wrong live environment, insufficient funding and unrelated existing contract', async t => {
  const f = await fixture(t);
  await assert.rejects(testnetPreflight(f.inputs, { getFingerprint: async () => 'different-chain' }), e => e.code === 'ENVIRONMENT_MISMATCH');
  async function readRpc(_url, method, params) {
    if (method === 'EXPERIMENTAL_protocol_config') return protocol;
    if (method === 'block') return { header: { gas_price: '100000000' } };
    if (params.request_type === 'view_access_key') return { permission: 'FullAccess' };
    return { amount: '0', code_hash: 'unrelated', storage_usage: 0 };
  }
  await assert.rejects(testnetPreflight(f.inputs, { getFingerprint: async () => environment, readRpc }), e => e.code === 'INSUFFICIENT_TESTNET_FUNDS');
  await assert.rejects(testnetPreflight(f.inputs, { getFingerprint: async () => environment, readRpc: async (...args) => { const result = await readRpc(...args); return args[2]?.request_type === 'view_account' ? { ...result, amount: '100000000000000000000000000' } : result; } }), e => e.code === 'EXISTING_CONTRACT_NOT_REVIEWED');
});

test('deployment storage/gas estimates are bounded and distinguish native deploy gas from FunctionCall caps', () => {
  const budget = deploymentBudget(protocol, 1000, '100000000');
  assert.equal(budget.provider_storage_reserve_bytes, 66536);
  assert.match(budget.deployment_gas_note, /no configurable gas field/);
  const expensive = structuredClone(protocol); expensive.runtime_config.transaction_costs.action_creation_config.deploy_contract_cost.execution = '100000000000001';
  assert.throws(() => deploymentBudget(expensive, 1000, '100000000'), e => e.code === 'DEPLOY_GAS_ESTIMATE_EXCEEDS_PLAN');
});
