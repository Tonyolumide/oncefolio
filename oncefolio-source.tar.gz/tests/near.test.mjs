import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { once } from 'node:events';
import { NearGateway, fingerprint } from '../app/near.mjs';

async function fixture(t, queryError) {
  const requests = [];
  const server = http.createServer(async (req, res) => {
    const chunks = []; for await (const part of req) chunks.push(part);
    const call = JSON.parse(Buffer.concat(chunks)); requests.push(call);
    const result = call.method === 'EXPERIMENTAL_genesis_config' ? { result: { chain_id: 'sandbox', genesis_time: 'fixed-fixture' } } : { error: queryError };
    res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ jsonrpc: '2.0', id: call.id, ...result }));
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(async () => { server.closeAllConnections(); await new Promise(r => server.close(r)); });
  const rpcUrl = `http://127.0.0.1:${server.address().port}`;
  const gateway = new NearGateway({ rpcUrl, contractId: 'provider.local', environment: await fingerprint(rpcUrl) });
  return { gateway, requests };
}

test('access-key RPC failure after valid genesis is unavailable rather than invalid identity', async t => {
  const { gateway, requests } = await fixture(t, { code: -32603, message: 'temporarily unavailable' });
  await assert.rejects(gateway.accessKey('buyer.local', 'ed25519:fixture'), e => e.code === 'CHAIN_UNAVAILABLE' && e.status === 503);
  assert.equal(requests.at(-1).params.finality, 'final');
});

test('definite missing access key is an authentication rejection', async t => {
  const { gateway } = await fixture(t, { data: { name: 'UNKNOWN_ACCESS_KEY' } });
  await assert.rejects(gateway.accessKey('buyer.local', 'ed25519:fixture'), e => e.code === 'AUTH_KEY_NOT_FOUND' && e.status === 401);
});

test('genesis mismatch prevents any key lookup', async t => {
  const { gateway, requests } = await fixture(t, { data: { name: 'UNKNOWN_ACCESS_KEY' } });
  gateway.environment = 'changed-chain';
  await assert.rejects(gateway.accessKey('buyer.local', 'ed25519:fixture'), e => e.code === 'ENVIRONMENT_MISMATCH' && e.status === 409);
  assert.ok(requests.every(r => r.method === 'EXPERIMENTAL_genesis_config'));
});
