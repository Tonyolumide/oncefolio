import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import http from 'node:http';
import { Sandbox } from 'near-sandbox';
import { Account, JsonRpcProvider, KeyPair, actions, nearToYocto } from 'near-api-js';
import { DatabaseSync } from 'node:sqlite';
import { BuyerClient } from '../app/client.mjs';
import { fingerprint } from '../app/near.mjs';
import { rpc, persist } from '../spike/client.mjs';

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const REQUEST = {
  rows: [{ email: 'ada@example.test', amount: 8 }, { email: 'ada@example.test', amount: 'bad' }, { email: '', amount: 2 }],
  required_fields: ['email'], unique_fields: ['email'], field_types: { email: 'string', amount: 'number' },
};
const EXPECTED_REPORT = {
  schema_version: 1,
  summary: { total_rows: 3, valid_rows: 0, invalid_rows: 3, duplicate_rows: 2 },
  issues: [{ row: 1, field: 'email', code: 'DUPLICATE_VALUE' }, { row: 2, field: 'amount', code: 'TYPE_MISMATCH' }, { row: 2, field: 'email', code: 'DUPLICATE_VALUE' }, { row: 3, field: 'email', code: 'REQUIRED' }],
  duplicates: [{ field: 'email', value: 'ada@example.test', rows: [1, 2] }],
};

function processNode(path, args = []) {
  const child = spawn(process.execPath, [resolve(path), ...args], { env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
  child.output = ''; child.errors = ''; child.lines = []; child.waiters = [];
  let pending = '';
  child.stdout.on('data', chunk => {
    child.output += chunk;
    pending += chunk;
    const lines = pending.split('\n'); pending = lines.pop();
    for (const line of lines) {
      let value; try { value = JSON.parse(line); } catch { continue; }
      child.lines.push(value);
      for (const waiter of [...child.waiters]) if (waiter.match(value)) { child.waiters.splice(child.waiters.indexOf(waiter), 1); waiter.resolve(value); }
    }
  });
  child.stderr.on('data', chunk => { child.errors += chunk; });
  child.done = new Promise(resolve => child.once('exit', (code, signal) => resolve({ code, signal })));
  child.until = (match, timeout = 20000) => {
    const found = child.lines.find(match); if (found) return Promise.resolve(found);
    return Promise.race([
      new Promise((resolve, reject) => { child.waiters.push({ match, resolve, reject }); }),
      child.done.then(({ code, signal }) => { throw new Error(`Child exited before readiness (${code ?? signal}): ${child.errors}`); }),
      new Promise((_, reject) => { const timer = setTimeout(() => reject(new Error(`Child readiness timed out: ${child.errors}`)), timeout); timer.unref(); }),
    ]);
  };
  return child;
}

async function stop(child, signal = 'SIGTERM') {
  if (!child || child.exitCode !== null || child.signalCode !== null) return;
  child.kill(signal);
  await Promise.race([child.done, wait(4000).then(() => { child.kill('SIGKILL'); return child.done; })]);
}

async function request(origin, path, { method = 'GET', body, token } = {}) {
  const response = await fetch(`${origin}${path}`, {
    method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined, redirect: 'error', signal: AbortSignal.timeout(20000),
  });
  return { status: response.status, body: await response.json() };
}

async function signLogin(origin, buyerAccount, buyerId = buyerAccount.accountId) {
  const challenge = await request(origin, '/v1/auth/challenges', { method: 'POST', body: { buyer: buyerId } });
  assert.equal(challenge.status, 200);
  const value = challenge.body;
  const signed = await buyerAccount.getSigner().signNep413Message(buyerId, { message: value.message, recipient: value.recipient, nonce: Buffer.from(value.nonce, 'base64') });
  return { challenge: value, body: { challenge_id: value.id, public_key: signed.publicKey.toString(), signature: Buffer.from(signed.signature).toString('base64') } };
}

test('paid report survives buyer, worker and service interruption with real NEAR settlement', { timeout: 180000 }, async t => {
  const directory = resolve(`work/product-test-${randomUUID()}`);
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  mkdirSync('outputs/product', { recursive: true });
  rmSync('outputs/product/runtime.json', { force: true });
  const proof = { started: new Date().toISOString(), scope: 'real local NEAR sandbox + HTTP + SQLite + independent buyer/server/worker processes', assertions: [], transactions: [] };
  const authorization = { unauthenticated_denied: false, wrong_role_denied: false, cross_object_denied: false };
  const children = new Set();
  const sandbox = await Sandbox.start({ version: '2.13.4' });
  let serviceProcess, proxy;
  const sockets = new Set();
  try {
    const provider = new JsonRpcProvider({ url: sandbox.rpcUrl });
    const rootKey = JSON.parse(readFileSync(`${sandbox.homeDir}/validator_key.json`, 'utf8'));
    const root = new Account(rootKey.account_id, provider, rootKey.secret_key);
    const accounts = {}, credentials = {};
    for (const role of ['provider', 'buyer', 'other']) {
      const key = KeyPair.fromRandom('ed25519'); const account_id = `${role}.${root.accountId}`;
      await root.createAccount({ newAccountId: account_id, publicKey: key.getPublicKey(), nearToTransfer: nearToYocto('20') });
      credentials[role] = { account_id, secret_key: key.toString() };
      accounts[role] = new Account(account_id, provider, key.toString());
    }
    await accounts.provider.deployContract(readFileSync('build/contract.wasm'));
    await accounts.provider.callFunctionRaw({ contractId: accounts.provider.accountId, methodName: 'init', args: { provider: accounts.provider.accountId }, waitUntil: 'FINAL' });
    const environment = await fingerprint(sandbox.rpcUrl);
    proof.environment = environment; proof.contract_id = accounts.provider.accountId;
    const providerKeyFile = `${directory}/provider.json`; persist(providerKeyFile, credentials.provider);
    const configPath = `${directory}/service.json`;
    const config = { providerKeyFile, dbPath: `${directory}/oncefolio.sqlite`, rpcUrl: sandbox.rpcUrl, contractId: accounts.provider.accountId, environment, apiPort: 0, workerLeaseMs: 700, workerDelayMs: 0 };
    persist(configPath, config);
    async function startService() {
      serviceProcess = processNode('app/server.mjs', [configPath]); children.add(serviceProcess);
      const ready = await serviceProcess.until(value => value.ready === true);
      return ready.origin;
    }
    let origin = await startService();
    let buyer = new BuyerClient({ serviceUrl: origin, rpcUrl: sandbox.rpcUrl, credentials: credentials.buyer });
    await buyer.login();
    const other = new BuyerClient({ serviceUrl: origin, rpcUrl: sandbox.rpcUrl, credentials: credentials.other }); await other.login();
    async function accountSnapshot() {
      const result = {};
      for (const role of ['buyer', 'provider']) result[role] = await rpc(sandbox.rpcUrl, 'query', { request_type: 'view_account', finality: 'final', account_id: accounts[role].accountId });
      return result;
    }
    async function runWorker(path = configPath, fixture = 'app/worker.mjs') {
      const child = processNode(fixture, fixture === 'app/worker.mjs' ? [path, '--once'] : [path]); children.add(child);
      const exit = await child.done; assert.equal(exit.code, 0, child.errors); return child;
    }
    function saved() { persist('outputs/product/runtime.json', proof); }

    await t.test('real HTTP authorization rejects missing, forged, replayed, expired, restricted and revoked credentials', async () => {
      const unauthenticated = await request(origin, '/v1/purchases/absent'); assert.equal(unauthenticated.status, 401); authorization.unauthenticated_denied = true;
      const forged = await signLogin(origin, accounts.other, accounts.buyer.accountId);
      assert.equal((await request(origin, '/v1/auth/sessions', { method: 'POST', body: forged.body })).status, 401);
      const replay = await signLogin(origin, accounts.buyer);
      assert.equal((await request(origin, '/v1/auth/sessions', { method: 'POST', body: replay.body })).status, 200);
      assert.equal((await request(origin, '/v1/auth/sessions', { method: 'POST', body: replay.body })).status, 401);
      const expired = await signLogin(origin, accounts.buyer);
      const db = new DatabaseSync(config.dbPath);
      db.prepare('UPDATE challenges SET expires_at=0 WHERE id=?').run(expired.challenge.id); db.close();
      assert.equal((await request(origin, '/v1/auth/sessions', { method: 'POST', body: expired.body })).status, 401);
      const restricted = KeyPair.fromRandom('ed25519'); const revocable = KeyPair.fromRandom('ed25519');
      await accounts.buyer.signAndSendTransaction({ receiverId: accounts.buyer.accountId, waitUntil: 'FINAL', actions: [actions.addFunctionCallAccessKey(restricted.getPublicKey(), accounts.provider.accountId, ['accept'], nearToYocto('1')), actions.addFullAccessKey(revocable.getPublicKey())] });
      const restrictedAccount = new Account(accounts.buyer.accountId, provider, restricted.toString());
      const restrictedLogin = await signLogin(origin, restrictedAccount);
      assert.equal((await request(origin, '/v1/auth/sessions', { method: 'POST', body: restrictedLogin.body })).status, 401); authorization.wrong_role_denied = true;
      const revocableAccount = new Account(accounts.buyer.accountId, provider, revocable.toString());
      const revocableLogin = await signLogin(origin, revocableAccount);
      const session = await request(origin, '/v1/auth/sessions', { method: 'POST', body: revocableLogin.body }); assert.equal(session.status, 200);
      await accounts.buyer.signAndSendTransaction({ receiverId: accounts.buyer.accountId, waitUntil: 'FINAL', actions: [actions.deleteKey(revocable.getPublicKey())] });
      assert.equal((await request(origin, '/v1/purchases/absent', { token: session.body.token })).status, 401);
      proof.assertions.push('unauthenticated, forged, replayed, expired, restricted-key and revoked-session HTTP requests denied'); saved();
    });

    const intentPath = `${directory}/purchase.json`;
    await t.test('concurrent quotes converge and changed request conflicts before payment', async () => {
      const [a, b] = await Promise.all([buyer.quote('report-recovery', REQUEST), buyer.quote('report-recovery', REQUEST)]);
      assert.deepEqual(a.binding, b.binding);
      await assert.rejects(() => buyer.quote('report-recovery', { ...REQUEST, required_fields: [] }), e => e.code === 'PURCHASE_CONFLICT');
      await assert.rejects(() => other.api('/v1/purchases/report-recovery'), e => e.status === 404); authorization.cross_object_denied = true;
      await assert.rejects(() => other.api('/v1/purchases/report-recovery/reconcile', { method: 'POST', body: {} }), e => e.status === 404);
      await buyer.prepare(intentPath, REQUEST, { purchaseId: 'report-recovery' });
      const intent = JSON.parse(readFileSync(intentPath, 'utf8'));
      assert.ok(intent.signed_tx_base64); assert.equal(intent.binding.purchase_id, 'report-recovery');
      const current = await buyer.api('/v1/purchases/report-recovery'); assert.notEqual(current.payment.status, 'accepted'); assert.equal(current.result, null);
      proof.binding = intent.binding; proof.assertions.push('concurrent quote identity stable, changed request rejected and cross-owner access hidden'); saved();
    });

    await t.test('kill buyer after payment executes without returning its response; fresh process recovers pending purchase', async () => {
      let resolveForward, rejectForward;
      const forwarded = new Promise((res, rej) => { resolveForward = res; rejectForward = rej; });
      proxy = http.createServer(async (req, res) => {
        try {
          const chunks = []; for await (const chunk of req) chunks.push(chunk);
          const payload = JSON.parse(Buffer.concat(chunks).toString()); assert.equal(payload.method, 'send_tx');
          const outcome = await rpc(sandbox.rpcUrl, 'send_tx', payload.params);
          resolveForward(outcome); // Withhold all HTTP response bytes so the buyer remains uncertain.
        } catch (error) { rejectForward(error); res.destroy(); }
      });
      proxy.on('connection', socket => { sockets.add(socket); socket.once('close', () => sockets.delete(socket)); });
      proxy.listen(0, '127.0.0.1'); await once(proxy, 'listening');
      const before = await accountSnapshot();
      const child = processNode('tests/fixtures/interrupted-payment.mjs', [intentPath, `http://127.0.0.1:${proxy.address().port}`]); children.add(child);
      const outcome = await forwarded; assert.ok(outcome.status.SuccessValue !== undefined, JSON.stringify(outcome.status));
      child.kill('SIGKILL'); const killed = await child.done; assert.equal(killed.signal, 'SIGKILL'); assert.equal(child.output, 'broadcast-started\n');
      for (const socket of sockets) socket.destroy(); await new Promise(res => proxy.close(res)); proxy = undefined;
      const after = await accountSnapshot();
      const buyerDebit = BigInt(before.buyer.amount) - BigInt(after.buyer.amount);
      const gas = [outcome.transaction_outcome, ...outcome.receipts_outcome].reduce((sum, o) => sum + BigInt(o.outcome.tokens_burnt), 0n);
      assert.equal(buyerDebit, nearToYocto('0.1') + gas);
      const fixtureConfig = `${directory}/client.json`; persist(fixtureConfig, { serviceUrl: origin, rpcUrl: sandbox.rpcUrl, credentials: credentials.buyer });
      const restarted = processNode('tests/fixtures/buyer-process.mjs', [fixtureConfig, intentPath]); children.add(restarted);
      const exit = await restarted.done; assert.equal(exit.code, 0, restarted.errors);
      const recovered = JSON.parse(restarted.output.trim()).purchase;
      assert.equal(recovered.payment.status, 'accepted'); assert.equal(recovered.delivery.status, 'pending'); assert.equal(recovered.result, null);
      const afterRecovery = await accountSnapshot();
      for (const role of ['buyer', 'provider']) assert.equal(afterRecovery[role].amount, after[role].amount);
      proof.transactions.push(outcome); proof.recovery = { before, after, afterRecovery, child_signal: killed.signal, child_output: child.output, recovered }; proof.assertions.push('fresh process recovers finalized paid-but-pending purchase after SIGKILL without another payment'); saved();
    });

    await t.test('killed worker lease is reclaimed by a separate process and one canonical report survives server restart', async () => {
      const configCrash = `${directory}/worker-crash.json`; persist(configCrash, { ...config, workerDelayMs: 60000 });
      const worker = processNode('app/worker.mjs', [configCrash, '--once']); children.add(worker);
      const claimed = await worker.until(value => value.event === 'claimed' || value.type === 'claimed' || value.claimed === true);
      await stop(worker, 'SIGKILL');
      const running = await buyer.api('/v1/purchases/report-recovery'); assert.equal(running.payment.status, 'accepted'); assert.equal(running.delivery.status, 'running');
      await wait(config.workerLeaseMs + 150);
      await runWorker();
      const delivered = await buyer.wait(intentPath, { timeoutMs: 10000 });
      assert.equal(delivered.purchase.delivery.status, 'succeeded'); assert.equal(delivered.purchase.delivery.attempts, 2); assert.deepEqual(delivered.purchase.result, EXPECTED_REPORT);
      const beforeRestart = await accountSnapshot();
      await stop(serviceProcess); origin = await startService();
      buyer = new BuyerClient({ serviceUrl: origin, rpcUrl: sandbox.rpcUrl, credentials: credentials.buyer }); await buyer.login();
      const recovered = await buyer.recover(intentPath);
      assert.deepEqual(recovered.purchase.result, EXPECTED_REPORT); assert.equal(recovered.purchase.delivery.attempts, 2);
      const afterRestart = await accountSnapshot();
      for (const role of ['buyer', 'provider']) assert.equal(afterRestart[role].amount, beforeRestart[role].amount);
      const db = new DatabaseSync(config.dbPath);
      const terminal = db.prepare("SELECT count(*) AS n FROM events WHERE purchase_id='report-recovery' AND kind='DELIVERY_SUCCEEDED'").get().n;
      assert.equal(terminal, 1); db.close();
      proof.worker_recovery = { claimed, running, delivered: delivered.purchase, recovered: recovered.purchase, canonical_result_events: terminal, beforeRestart, afterRestart }; proof.assertions.push('worker SIGKILL reclaims lease; SQLite result survives independent server process restart without another payment'); saved();
    });

    await t.test('paid delivery failure stays separate and retries same purchase without another charge', async () => {
      const failureIntent = `${directory}/failure.json`; await buyer.prepare(failureIntent, REQUEST, { purchaseId: 'report-failure' });
      const paid = await buyer.pay(failureIntent); assert.equal(paid.purchase.payment.status, 'accepted');
      await runWorker(configPath, 'tests/fixtures/failing-worker.mjs');
      const failed = await buyer.recover(failureIntent); assert.equal(failed.purchase.payment.status, 'accepted'); assert.equal(failed.purchase.delivery.status, 'failed'); assert.equal(failed.purchase.result, null);
      const beforeRetry = await accountSnapshot();
      const retried = await buyer.api('/v1/purchases/report-failure/retry', { method: 'POST', body: {} }); assert.equal(retried.delivery.status, 'pending');
      await runWorker();
      const recovered = await buyer.wait(failureIntent, { timeoutMs: 10000 }); assert.equal(recovered.purchase.delivery.status, 'succeeded'); assert.equal(recovered.purchase.delivery.attempts, 2); assert.deepEqual(recovered.purchase.result, EXPECTED_REPORT);
      const afterRetry = await accountSnapshot();
      for (const role of ['buyer', 'provider']) assert.equal(afterRetry[role].amount, beforeRetry[role].amount);
      proof.failed_delivery = { failed: failed.purchase, recovered: recovered.purchase, beforeRetry, afterRetry }; proof.assertions.push('paid failure remains paid; same purchase retry delivers correct report with unchanged chain balances'); saved();
    });

    await t.test('stale signed nonce renews under the same purchase ID after another purchase pays first', async () => {
      const earlyPath = `${directory}/early.json`, laterPath = `${directory}/later.json`;
      const early = await buyer.prepare(earlyPath, REQUEST, { purchaseId: 'early-purchase' });
      await buyer.prepare(laterPath, REQUEST, { purchaseId: 'later-purchase' });
      assert.equal((await buyer.pay(laterPath)).purchase.payment.status, 'accepted');
      const recovered = await buyer.pay(earlyPath);
      assert.equal(recovered.purchase.payment.status, 'accepted');
      assert.equal(recovered.purchase.purchase_id, 'early-purchase');
      const savedIntent = JSON.parse(readFileSync(earlyPath, 'utf8'));
      assert.notEqual(savedIntent.tx_hash, early.tx_hash);
      assert.equal(savedIntent.signed_attempts.length, 1);
      assert.equal(savedIntent.signed_attempts[0].tx_hash, early.tx_hash);
      proof.nonce_recovery = { purchase_id: recovered.purchase.purchase_id, original_tx_hash: early.tx_hash, renewed_tx_hash: savedIntent.tx_hash, payment: recovered.purchase.payment.status };
      proof.assertions.push('stale nonce renews one signed attempt with the same immutable purchase ID'); saved();
    });

    await t.test('invalid and oversized HTTP requests do not create billable purchases', async () => {
      const invalid = await request(origin, '/v1/quotes', { method: 'POST', token: buyer.token, body: { purchase_id: 'bad', request: { rows: [{ nested: { secret: 'value' } }] } } }); assert.equal(invalid.status, 400);
      const oversized = await request(origin, '/v1/quotes', { method: 'POST', token: buyer.token, body: { purchase_id: 'oversized', request: { rows: [{ field: 'x'.repeat(140000) }] } } }); assert.equal(oversized.status, 413);
      const db = new DatabaseSync(config.dbPath); assert.equal(db.prepare("SELECT count(*) AS n FROM purchases WHERE id IN ('bad','oversized')").get().n, 0); db.close();
      proof.assertions.push('invalid and oversized requests rejected before purchase persistence'); saved();
    });
    const authPath = resolve(process.env.FLOW_BY_FLOW_REPORT_DIR ?? 'outputs/product'); mkdirSync(authPath, { recursive: true });
    persist(`${authPath}/authorization.json`, { schema_version: 1, ...authorization, checks: Object.entries(authorization).map(([id, passed]) => ({ id, passed })), evidence: 'real HTTP authentication/session/ownership checks against the running service and finalized NEAR access keys' });
    proof.completed = new Date().toISOString(); saved();
  } finally {
    if (proxy) { for (const socket of sockets) socket.destroy(); proxy.closeAllConnections(); await new Promise(res => proxy.close(res)); }
    for (const child of children) await stop(child);
    await sandbox.tearDown();
  }
});
