import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { KeyPair, Account, JsonRpcProvider } from 'near-api-js';
import { signMessage } from 'near-api-js/nep413';
import { Store } from '../app/store.mjs';
import { Auth } from '../app/auth.mjs';

const buyer = 'buyer.test.near';
const other = 'other.test.near';
const origin = 'http://127.0.0.1:8787';
const rejected = code => error => error.code === code && error.status === 401;

function fixture(t) {
  let time = 1000;
  const key = KeyPair.fromRandom('ed25519');
  const otherKey = KeyPair.fromRandom('ed25519');
  const registered = new Map([[`${buyer}|${key.getPublicKey()}`, 'FullAccess'], [`${other}|${otherKey.getPublicKey()}`, 'FullAccess']]);
  let failure;
  let gate;
  const near = {
    contractId: 'provider.test.near', environment: 'a'.repeat(64),
    async accessKey(account, publicKey) {
      if (failure) throw failure;
      const permission = registered.get(`${account}|${publicKey.toString()}`);
      if (!permission) throw new Error('Missing access key');
      if (gate) { const active = gate; gate = undefined; active.entered(); await active.wait; }
      return { permission };
    },
  };
  const store = new Store(':memory:', { environment: near.environment, contractId: near.contractId, now: () => time });
  t.after(() => store.close());
  const auth = new Auth(store, near, origin, { now: () => time });
  async function signed(challenge, signingKey = key, changes = {}, accountId = buyer) {
    const account = new Account(accountId, new JsonRpcProvider({ url: 'http://127.0.0.1:1' }), signingKey.toString());
    const message = await signMessage({ signerAccount: account, payload: { message: challenge.message, recipient: challenge.recipient, nonce: Buffer.from(challenge.nonce, 'base64'), ...changes } });
    return { challenge_id: challenge.id, public_key: message.publicKey.toString(), signature: Buffer.from(message.signature).toString('base64') };
  }
  return {
    auth, store, key, otherKey, signed,
    advance: ms => { time += ms; },
    setPermission: permission => { registered.set(`${buyer}|${key.getPublicKey()}`, permission); },
    revoke: () => { registered.delete(`${buyer}|${key.getPublicKey()}`); },
    setFailure: error => { failure = error; },
    holdNextLookup() {
      let entered, release;
      const enteredPromise = new Promise(resolve => { entered = resolve; });
      const wait = new Promise(resolve => { release = resolve; });
      gate = { entered, wait };
      return { entered: enteredPromise, release };
    },
  };
}

test('real NEP-413 signatures establish hashed, domain-bound sessions without a network', async t => {
  const f = fixture(t); const challenge = f.auth.challenge(buyer);
  assert.equal(Buffer.from(challenge.nonce, 'base64').length, 32);
  assert.equal(challenge.recipient, origin);
  assert.match(challenge.message, /provider\.test\.near/);
  assert.match(challenge.message, /Chain a{64}/);
  const session = await f.auth.login(await f.signed(challenge));
  assert.equal(session.buyer, buyer); assert.match(session.token, /^[A-Za-z0-9_-]{43}$/);
  const stored = f.store.db.prepare('SELECT * FROM sessions').get();
  assert.equal(stored.token_hash, createHash('sha256').update(session.token).digest('hex'));
  assert.ok(!JSON.stringify(stored).includes(session.token));
  assert.equal((await f.auth.session(`Bearer ${session.token}`)).buyer, buyer);
});

test('invalid signatures, altered payloads and the wrong buyer key cannot authenticate', async t => {
  const f = fixture(t);
  for (const changes of [{ message: 'different message' }, { recipient: 'http://127.0.0.1:9999' }, { nonce: Buffer.alloc(32) }]) {
    const challenge = f.auth.challenge(buyer);
    await assert.rejects(f.auth.login(await f.signed(challenge, f.key, changes)), rejected('AUTH_SIGNATURE_INVALID'));
  }
  const challenge = f.auth.challenge(buyer);
  await assert.rejects(f.auth.login(await f.signed(challenge, f.otherKey, {}, other)), rejected('AUTH_SIGNATURE_INVALID'));
  const input = await f.signed(challenge);
  await assert.rejects(f.auth.login({ ...input, signature: Buffer.alloc(64).toString('base64') }), rejected('AUTH_SIGNATURE_INVALID'));
  await assert.rejects(f.auth.login({ ...input, public_key: 'not-a-public-key' }), rejected('AUTH_SIGNATURE_INVALID'));
  assert.equal(f.store.db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n, 0);
});

test('challenge replay and concurrent login mint exactly one session', async t => {
  const f = fixture(t); const input = await f.signed(f.auth.challenge(buyer));
  const outcomes = await Promise.allSettled([f.auth.login(input), f.auth.login(input)]);
  assert.equal(outcomes.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(outcomes.find(result => result.status === 'rejected').reason.code, 'AUTH_CHALLENGE_INVALID');
  await assert.rejects(f.auth.login(input), rejected('AUTH_CHALLENGE_INVALID'));
  assert.equal(f.store.db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n, 1);
});

test('challenge expiry is checked both before and after delayed key verification', async t => {
  const f = fixture(t); const input = await f.signed(f.auth.challenge(buyer));
  const gate = f.holdNextLookup();
  const login = f.auth.login(input); await gate.entered;
  f.advance(60000); gate.release();
  await assert.rejects(login, rejected('AUTH_CHALLENGE_INVALID'));
  await assert.rejects(f.auth.login(input), rejected('AUTH_CHALLENGE_INVALID'));
  assert.equal(f.store.db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n, 0);
});

test('restricted access keys cannot login or continue a session and revoked keys are denied', async t => {
  const f = fixture(t); const input = await f.signed(f.auth.challenge(buyer));
  f.setPermission({ FunctionCall: { receiver_id: 'provider.test.near', method_names: ['accept'], allowance: null } });
  await assert.rejects(f.auth.login(input), rejected('AUTH_SIGNATURE_INVALID'));
  f.setPermission('FullAccess');
  const session = await f.auth.login(input);
  f.setPermission({ FunctionCall: { receiver_id: 'provider.test.near', method_names: ['accept'], allowance: null } });
  await assert.rejects(f.auth.session(`Bearer ${session.token}`), rejected('AUTH_REQUIRED'));
  f.revoke();
  await assert.rejects(f.auth.session(`Bearer ${session.token}`), rejected('AUTH_REQUIRED'));
});

test('session expiry, logout and malformed bearer headers reject access', async t => {
  const f = fixture(t); const session = await f.auth.login(await f.signed(f.auth.challenge(buyer)));
  for (const header of [undefined, '', session.token, `Basic ${session.token}`, `Bearer ${session.token}extra`]) await assert.rejects(f.auth.session(header), rejected('AUTH_REQUIRED'));
  f.auth.logout(`Bearer ${session.token}`);
  await assert.rejects(f.auth.session(`Bearer ${session.token}`), rejected('AUTH_REQUIRED'));
  const second = await f.auth.login(await f.signed(f.auth.challenge(buyer)));
  f.advance(15 * 60000);
  await assert.rejects(f.auth.session(`Bearer ${second.token}`), rejected('AUTH_REQUIRED'));
});

test('session expiring while access-key lookup is pending must not authorize', async t => {
  const f = fixture(t); const session = await f.auth.login(await f.signed(f.auth.challenge(buyer)));
  const gate = f.holdNextLookup();
  const access = f.auth.session(`Bearer ${session.token}`); await gate.entered;
  f.advance(15 * 60000); gate.release();
  await assert.rejects(access, rejected('AUTH_REQUIRED'));
});

test('session removed during access-key lookup must not authorize', async t => {
  const f = fixture(t); const session = await f.auth.login(await f.signed(f.auth.challenge(buyer)));
  const gate = f.holdNextLookup();
  const access = f.auth.session(`Bearer ${session.token}`); await gate.entered;
  f.auth.logout(`Bearer ${session.token}`); gate.release();
  await assert.rejects(access, rejected('AUTH_REQUIRED'));
});

test('chain failures fail closed and preserve meaningful unavailable/environment errors', async t => {
  const f = fixture(t); const input = await f.signed(f.auth.challenge(buyer));
  f.setFailure(Object.assign(new Error('unavailable'), { code: 'CHAIN_UNAVAILABLE', status: 503 }));
  await assert.rejects(f.auth.login(input), error => error.code === 'CHAIN_UNAVAILABLE' && error.status === 503);
  f.setFailure(undefined); const session = await f.auth.login(input);
  f.setFailure(Object.assign(new Error('changed'), { code: 'ENVIRONMENT_MISMATCH', status: 409 }));
  await assert.rejects(f.auth.session(`Bearer ${session.token}`), error => error.code === 'ENVIRONMENT_MISMATCH' && error.status === 409);
});

test('outstanding challenge generation is bounded and expired state is pruned', t => {
  const f = fixture(t);
  assert.throws(() => f.auth.challenge('invalid account'), error => error.code === 'INVALID_BUYER');
  for (let i = 0; i < 10; i++) f.auth.challenge(buyer);
  assert.throws(() => f.auth.challenge(buyer), error => error.code === 'RATE_LIMITED' && error.status === 429);
  f.advance(60001); f.auth.challenge(buyer);
  assert.equal(f.store.db.prepare('SELECT COUNT(*) AS n FROM challenges').get().n, 1);
});
