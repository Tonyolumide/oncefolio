import test from 'node:test';
import assert from 'node:assert/strict';
import { rpcUrl, rpc, assertNetwork, StrictJsonRpcProvider } from '../app/rpc.mjs';
import { NearGateway, fingerprint } from '../app/near.mjs';
import { BuyerClient } from '../app/client.mjs';
import { KeyPair } from 'near-api-js';

test('RPC policy permits loopback and approved HTTPS testnet providers only', () => {
  for (const url of ['http://127.0.0.1:3030', 'https://rpc.testnet.near.org', 'https://archival-rpc.testnet.near.org/', 'https://test.rpc.fastnear.com']) assert.equal(rpcUrl(url), url);
  for (const url of ['https://rpc.mainnet.near.org', 'https://rpc.testnet.near.org.evil.test', 'http://rpc.testnet.near.org', 'https://test.rpc.fastnear.com:444', 'https://user:secret@rpc.testnet.near.org', 'https://@rpc.testnet.near.org', 'https://rpc.testnet.near.org/?token=secret', 'https://rpc.testnet.near.org/?', 'https://rpc.testnet.near.org/#x', 'https://rpc.testnet.near.org/#', 'https://rpc.testnet.near.org/path', 'http://localhost:3030', 'file:///tmp/rpc']) assert.throws(() => rpcUrl(url));
});

test('testnet must be explicit for remote gateways and mainnet is never supported', () => {
  assert.throws(() => new NearGateway({ rpcUrl: 'https://rpc.testnet.near.org', contractId: 'provider.testnet', environment: 'fixture' }), e => e.code === 'NETWORK_MISMATCH');
  assert.throws(() => assertNetwork('http://127.0.0.1:1', 'mainnet'), e => e.code === 'UNSUPPORTED_NETWORK');
  const gateway = new NearGateway({ rpcUrl: 'https://rpc.testnet.near.org', contractId: 'provider.testnet', environment: 'fixture', network: 'testnet' });
  assert.equal(gateway.network, 'testnet');
});

test('remote RPC rejects HTTP redirects instead of following a provider redirect', async () => {
  const original = globalThis.fetch;
  globalThis.fetch = async (_url, options) => { assert.equal(options.redirect, 'error'); throw new TypeError('redirect blocked'); };
  try { await assert.rejects(rpc('https://rpc.testnet.near.org', 'status', []), /redirect blocked/); }
  finally { globalThis.fetch = original; }
});

test('SDK provider helpers use the same nonredirecting transport', async () => {
  const original = globalThis.fetch;
  globalThis.fetch = async (_url, options) => { assert.equal(options.redirect, 'error'); return { ok: true, async json() { return { result: { chain_id: 'testnet' } }; } }; };
  try { const provider = new StrictJsonRpcProvider('https://rpc.testnet.near.org'); assert.equal((await provider.viewNodeStatus()).chain_id, 'testnet'); }
  finally { globalThis.fetch = original; }
});

test('testnet fingerprint checks the live chain identity before accepting genesis', async () => {
  const original = globalThis.fetch; const methods = [];
  globalThis.fetch = async (_url, options) => {
    const call = JSON.parse(options.body); methods.push(call.method);
    return { ok: true, async json() { return { result: call.method === 'status' ? { chain_id: 'mainnet' } : { chain_id: 'testnet', genesis_time: 'fixture' } }; } };
  };
  try { await assert.rejects(fingerprint('https://rpc.testnet.near.org', 'testnet'), e => e.code === 'NETWORK_MISMATCH'); assert.deepEqual(methods, ['status']); }
  finally { globalThis.fetch = original; }
});

test('matching testnet identity still requires the exact persisted fingerprint', async () => {
  const original = globalThis.fetch;
  globalThis.fetch = async (_url, options) => {
    const call = JSON.parse(options.body);
    return { ok: true, async json() { return { result: call.method === 'status' ? { chain_id: 'testnet', genesis_hash: 'F'.repeat(44) } : { chain_id: 'testnet', genesis_time: 'fixture' } }; } };
  };
  try {
    const endpoint = 'https://rpc.testnet.near.org';
    const environment = await fingerprint(endpoint, 'testnet');
    const gateway = new NearGateway({ rpcUrl: endpoint, contractId: 'provider.testnet', environment, network: 'testnet' });
    await gateway.ensureEnvironment(); gateway.environment = 'wrong-chain';
    await assert.rejects(gateway.ensureEnvironment(), e => e.code === 'ENVIRONMENT_MISMATCH');
  } finally { globalThis.fetch = original; }
});

test('testnet fingerprint is stable across node/config display changes but rejects a genesis reset', async () => {
  const original = globalThis.fetch; let displayVersion = 0, genesisHash = 'F'.repeat(44);
  globalThis.fetch = async (_url, options) => {
    const call = JSON.parse(options.body); displayVersion++;
    return { ok: true, async json() { return { result: call.method === 'status' ? { chain_id: 'testnet', genesis_hash: genesisHash, uptime_sec: displayVersion, version: { version: String(displayVersion) } } : { chain_id: 'testnet', genesis_time: 'fixture', protocol_version: displayVersion } }; } };
  };
  try {
    const endpoint = 'https://rpc.testnet.near.org';
    const first = await fingerprint(endpoint, 'testnet');
    assert.equal(await fingerprint(endpoint, 'testnet'), first);
    assert.equal(await fingerprint(endpoint, 'testnet'), first);
    genesisHash = 'G'.repeat(44);
    const gateway = new NearGateway({ rpcUrl: endpoint, contractId: 'provider.testnet', environment: first, network: 'testnet' });
    await assert.rejects(gateway.ensureEnvironment(), e => e.code === 'ENVIRONMENT_MISMATCH');
  } finally { globalThis.fetch = original; }
});

test('buyer refuses service network mismatch before trusting its fingerprint', async () => {
  const buyer = new BuyerClient({ serviceUrl: 'http://127.0.0.1:1', rpcUrl: 'https://rpc.testnet.near.org', credentials: { account_id: 'buyer.testnet', secret_key: KeyPair.fromRandom('ed25519').toString() } });
  buyer.api = async () => ({ network: 'sandbox', environment: 'fixture' });
  await assert.rejects(buyer.metadata(), e => e.code === 'NETWORK_MISMATCH');
});

test('durable intents keep network boundaries while legacy sandbox intents still recover', () => {
  const buyer = new BuyerClient({ serviceUrl: 'http://127.0.0.1:1', rpcUrl: 'http://127.0.0.1:3030', credentials: { account_id: 'buyer.local', secret_key: KeyPair.fromRandom('ed25519').toString() } });
  const meta = { environment: 'fixture', contract_id: 'provider.local', network: 'sandbox' };
  const intent = { environment: 'fixture', contract_id: 'provider.local', buyer: 'buyer.local', rpcUrl: buyer.rpcUrl, binding: { network: 'sandbox' } };
  buyer.validateIntent(intent, meta);
  assert.throws(() => buyer.validateIntent({ ...intent, network: 'testnet' }, meta), e => e.code === 'NETWORK_MISMATCH');
  assert.throws(() => buyer.validateIntent({ ...intent, binding: { network: 'testnet' } }, meta), e => e.code === 'NETWORK_MISMATCH');
});
