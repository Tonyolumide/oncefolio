import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeRequest, canonicalJson, requestDigest, buildReport } from '../app/report.mjs';

const invalid = value => assert.throws(() => normalizeRequest(value), e => e.code === 'INVALID_REQUEST' && e.status === 400);

test('canonical requests and digests ignore object and rule order without mutating inputs', () => {
  const input = { rows: [{ z: 3, name: 'a' }], unique_fields: ['z', 'name'], required_fields: ['z', 'name'], field_types: { z: 'number', name: 'string' } };
  const original = structuredClone(input);
  const a = normalizeRequest(input);
  const b = normalizeRequest({ field_types: { name: 'string', z: 'number' }, required_fields: ['name', 'z'], unique_fields: ['name', 'z'], rows: [{ name: 'a', z: 3 }] });
  assert.deepEqual(input, original);
  assert.deepEqual(a, b);
  assert.equal(requestDigest(a), requestDigest(b));
  assert.match(requestDigest(a), /^[0-9a-f]{64}$/);
  assert.equal(canonicalJson({ b: 1, a: { z: 0, x: 2 } }), '{"a":{"x":2,"z":0},"b":1}');
  a.rows[0].name = 'changed';
  assert.equal(input.rows[0].name, 'a');
});

test('report combines required, type and duplicate issues with exact row counts', () => {
  const report = buildReport(normalizeRequest({
    rows: [ { email: 'a', amount: 10 }, { email: 'a', amount: 'bad' }, { email: null, amount: 2 }, { amount: 3 }, { email: '', amount: 4 }, { email: 'b', amount: 5 } ],
    required_fields: ['email'], unique_fields: ['email'], field_types: { amount: 'number', email: 'string' },
  }));
  assert.deepEqual(report, {
    schema_version: 1,
    summary: { total_rows: 6, valid_rows: 1, invalid_rows: 5, duplicate_rows: 2 },
    issues: [
      { row: 1, field: 'email', code: 'DUPLICATE_VALUE' },
      { row: 2, field: 'amount', code: 'TYPE_MISMATCH' },
      { row: 2, field: 'email', code: 'DUPLICATE_VALUE' },
      { row: 3, field: 'email', code: 'REQUIRED' },
      { row: 4, field: 'email', code: 'REQUIRED' },
      { row: 5, field: 'email', code: 'REQUIRED' },
    ],
    duplicates: [{ field: 'email', value: 'a', rows: [1, 2] }],
  });
});

test('duplicate values are type-sensitive, deterministic, and count row unions', () => {
  const request = normalizeRequest({ rows: [{ a: 1, b: false }, { a: '1', b: false }, { a: 1, b: true }, { a: null, b: '' }, { b: '' }], unique_fields: ['b', 'a'] });
  const report = buildReport(request);
  assert.deepEqual(report.duplicates, [{ field: 'a', value: 1, rows: [1, 3] }, { field: 'b', value: false, rows: [1, 2] }]);
  assert.deepEqual(report.summary, { total_rows: 5, valid_rows: 2, invalid_rows: 3, duplicate_rows: 3 });
  assert.deepEqual(buildReport(request), report);
});

test('empty rules permit all flat rows and optional nullable typed fields', () => {
  assert.deepEqual(buildReport(normalizeRequest({ rows: [{}, { value: null }, { value: true }] })).summary, { total_rows: 3, valid_rows: 3, invalid_rows: 0, duplicate_rows: 0 });
  assert.equal(buildReport(normalizeRequest({ rows: [{}, { value: null }], field_types: { value: 'number' } })).issues.length, 0);
});

test('reject malformed structure, unsafe values, prototype keys and unknown input fields', () => {
  for (const value of [null, [], {}, { rows: [] }, { rows: [1] }, { rows: [[]] }, { rows: [{ a: {} }] }, { rows: [{ a: [] }] }, { rows: [{ a: undefined }] }, { rows: [{ a: Infinity }] }, { rows: [{ a: NaN }] }, { rows: [{ a: Number.MAX_SAFE_INTEGER + 1 }] }, { rows: [{ 'bad-key': 1 }] }, { rows: [{ constructor: 1 }] }, { rows: [JSON.parse('{"__proto__":1}')] }, { rows: [Object.create({ inherited: 1 })] }, { rows: [{}], extra: true }, { rows: [{}], unique_fields: ['a', 'a'] }, { rows: [{}], required_fields: [1] }, { rows: [{}], field_types: { a: 'object' } }, { rows: [{}], field_types: [] }]) invalid(value);
});

test('enforce row, field, string, rule and serialized-byte limits including multibyte text', () => {
  invalid({ rows: new Array(1) });
  invalid({ rows: [{}], required_fields: new Array(1) });
  invalid({ rows: Array.from({ length: 1001 }, () => ({})) });
  invalid({ rows: [Object.fromEntries(Array.from({ length: 33 }, (_, i) => [`a${i}`, i]))] });
  invalid({ rows: [{ a: 'x'.repeat(2001) }] });
  invalid({ rows: [{}], required_fields: Array.from({ length: 33 }, (_, i) => `a${i}`) });
  invalid({ rows: [{}], field_types: Object.fromEntries(Array.from({ length: 33 }, (_, i) => [`a${i}`, 'string'])) });
  invalid({ rows: Array.from({ length: 100 }, () => ({ a: '界'.repeat(1000) })) });
  assert.equal(normalizeRequest({ rows: Array.from({ length: 1000 }, () => ({})) }).rows.length, 1000);
  assert.equal(normalizeRequest({ rows: [{ a: 'x'.repeat(2000), n: -1.25 }] }).rows[0].n, -1.25);
});
