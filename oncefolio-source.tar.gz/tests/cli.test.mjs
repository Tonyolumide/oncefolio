import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { KeyPair } from 'near-api-js';
import { BuyerClient } from '../app/client.mjs';

test('buyer CLI entrypoint does not execute the imported spike CLI', () => {
  const result = spawnSync(process.execPath, ['app/client.mjs'], { encoding: 'utf8' });
  assert.equal(result.status, 1);
  assert.deepEqual(JSON.parse(result.stderr.trim()), { error: 'USAGE_BUY_OR_RECOVER_CONFIG_INTENT_REQUEST' });
  assert.equal(result.stdout, '');
});

test('definite pre-inclusion rejection remains actionable while purchase is unresolved', async () => {
  const client = new BuyerClient({ serviceUrl: 'http://127.0.0.1:1', rpcUrl: 'http://127.0.0.1:1', credentials: { account_id: 'buyer.local', secret_key: KeyPair.fromRandom('ed25519').toString() } });
  const intent = { environment: 'fixture-chain', contract_id: 'provider.local', buyer: 'buyer.local', rpcUrl: client.rpcUrl, purchase_id: 'p', binding: { purchase_id: 'p' }, attempt: { status: 'rejected', error: 'PAYMENT_NONCE_RETRY_REQUIRED' } };
  client.metadata = async () => ({ environment: intent.environment, contract_id: intent.contract_id });
  client.api = async () => ({ binding: intent.binding, payment: { status: 'unknown' } });
  const result = await client._recover(intent, { lookupAttempt: false });
  assert.equal(result.purchase.payment.status, 'unknown');
  assert.equal(result.attempt.error, 'PAYMENT_NONCE_RETRY_REQUIRED');
  client.api = async () => ({ binding: intent.binding, payment: { status: 'accepted' } });
  const accepted = await client._recover(intent, { lookupAttempt: false });
  assert.equal(accepted.attempt.status, 'accepted');
  assert.equal(accepted.attempt.error, undefined);
});
