import { readFileSync } from 'node:fs';
import { Store } from '../../app/store.mjs';
import { workOnce } from '../../app/worker.mjs';
const config = JSON.parse(readFileSync(process.argv[2], 'utf8'));
const store = new Store(config.dbPath, config);
try {
  await workOnce(store, { compute() { throw Object.assign(new Error('Injected execution failure'), { code: 'SERVICE_FAILED' }); } });
} finally { store.close(); }
