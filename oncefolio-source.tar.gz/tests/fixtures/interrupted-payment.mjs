import { readFileSync } from 'node:fs';
import { rpc } from '../../spike/client.mjs';
const [intentPath, proxyUrl] = process.argv.slice(2);
const intent = JSON.parse(readFileSync(intentPath, 'utf8'));
process.stdout.write('broadcast-started\n');
await rpc(proxyUrl, 'send_tx', { signed_tx_base64: intent.signed_tx_base64, wait_until: 'FINAL' });
process.stdout.write('broadcast-response-received\n');
