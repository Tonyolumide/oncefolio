import { readFileSync } from 'node:fs';
import { BuyerClient } from '../../app/client.mjs';
const [configPath, intentPath] = process.argv.slice(2);
const config = JSON.parse(readFileSync(configPath, 'utf8'));
const buyer = new BuyerClient(config);
await buyer.login();
const result = await buyer.recover(intentPath);
process.stdout.write(`${JSON.stringify(result)}\n`);
