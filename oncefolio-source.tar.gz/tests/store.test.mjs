import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Store, publicPurchase } from '../app/store.mjs';

const spec = { environment: 'sandbox', contractId: 'provider.test.near' };
const purchase = (id = 'p1') => ({ id, buyer: 'buyer.test.near', request: { rows: [{ name: 'a' }] }, digest: 'a'.repeat(64), binding: { purchase_id: id, buyer: 'buyer.test.near', amount: '100' } });
function fixture(t) {
  const directory = mkdtempSync(join(tmpdir(), 'oncefolio-store-'));
  const path = join(directory, 'data', 'provider.sqlite');
  const stores = [];
  let time = 1000;
  const open = options => { const s = new Store(path, { ...spec, now: () => time, ...options }); stores.push(s); return s; };
  t.after(() => { for (const s of stores) s.close(); rmSync(directory, { recursive: true, force: true }); });
  return { path, open, advance: ms => { time += ms; } };
}

test('migrations are repeatable, checksum protected, environment bound and private', t => {
  const f = fixture(t); const first = f.open();
  const state = first.migrationState();
  assert.equal(state.tracked_migrations.length, 1);
  assert.equal(state.applied_migrations.length, 1);
  assert.equal(state.tracked_migrations[0].sha256, state.applied_migrations[0].sha256);
  assert.match(state.schema_fingerprint, /^[0-9a-f]{64}$/);
  assert.deepEqual(state.open_recovery_findings, []);
  const second = f.open();
  assert.equal(second.migrationState().schema_fingerprint, state.schema_fingerprint);
  assert.equal(statSync(f.path).mode & 0o777, 0o600);
  assert.equal(statSync(join(f.path, '..')).mode & 0o777, 0o700);
  assert.throws(() => f.open({ environment: 'testnet' }), e => e.code === 'ENVIRONMENT_MISMATCH' && e.status === 409);
  assert.throws(() => f.open({ contractId: 'other.test.near' }), e => e.code === 'ENVIRONMENT_MISMATCH');
  first.db.prepare('UPDATE schema_migrations SET sha256 = ?').run('bad-checksum');
  assert.throws(() => f.open(), e => e.code === 'MIGRATION_MISMATCH');
});

test('two store handles converge on immutable purchases and atomic claims', t => {
  const f = fixture(t); const a = f.open(); const b = f.open();
  const input = purchase();
  const first = a.ensurePurchase(input);
  assert.equal(b.ensurePurchase({ ...input, request: { rows: [{ name: 'a' }] } }).id, first.id);
  for (const changed of [{ buyer: 'other.test.near' }, { digest: 'b'.repeat(64) }, { request: { rows: [{ name: 'changed' }] } }]) assert.throws(() => b.ensurePurchase({ ...input, ...changed }), e => e.code === 'PURCHASE_CONFLICT' && e.status === 409);
  assert.equal(a.get('p1').payment, 'unknown');
  assert.equal(a.claim(), undefined);
  a.markQuoteReady('p1');
  assert.equal(a.get('p1').quote_status, 'ready');
  a.confirmPayment('p1', 'final-block'); b.confirmPayment('p1', 'same-payment-another-final-block');
  const claimed = a.claim(100);
  assert.equal(claimed.id, 'p1'); assert.equal(claimed.attempts, 1);
  assert.equal(b.claim(100), undefined);
  assert.equal(a.db.prepare("SELECT COUNT(*) AS count FROM events WHERE kind = 'PAYMENT_ACCEPTED'").get().count, 1);
});

test('expired lease cannot complete and reclaimed work fences stale workers', t => {
  const f = fixture(t); const a = f.open(); const b = f.open();
  a.ensurePurchase(purchase()); a.confirmPayment('p1', 'final-block');
  const first = a.claim(50); f.advance(50);
  assert.equal(a.complete('p1', first.lease_token, { unsafe: true }), false);
  assert.equal(a.fail('p1', first.lease_token), false);
  const second = b.claim(50);
  assert.equal(second.attempts, 2); assert.notEqual(second.lease_token, first.lease_token);
  assert.equal(a.complete('p1', first.lease_token, { stale: true }), false);
  assert.equal(b.complete('p1', second.lease_token, { valid: true }), true);
  assert.equal(a.complete('p1', second.lease_token, { overwritten: true }), false);
  assert.deepEqual(JSON.parse(a.get('p1').result_json), { valid: true });
  a.confirmPayment('p1', 'later-block');
  assert.equal(a.get('p1').delivery, 'succeeded');
});

test('third crashed attempt becomes terminal rather than remaining running forever', t => {
  const f = fixture(t); const s = f.open();
  s.ensurePurchase(purchase()); s.confirmPayment('p1', 'block');
  for (let i = 1; i <= 3; i++) { const row = s.claim(10); assert.equal(row.attempts, i); f.advance(10); }
  assert.equal(s.claim(10), undefined);
  assert.equal(s.get('p1').delivery, 'failed'); assert.equal(s.get('p1').last_error, 'LEASE_EXHAUSTED');
  assert.equal(s.get('p1').lease_token, null);
  assert.throws(() => s.retry('p1'), e => e.code === 'RETRY_NOT_ALLOWED');
});

test('paid service failures stay paid; retries are bounded and error messages sanitized', t => {
  const f = fixture(t); const s = f.open();
  s.ensurePurchase(purchase());
  assert.throws(() => s.retry('p1'), e => e.code === 'RETRY_NOT_ALLOWED');
  s.confirmPayment('p1', 'block');
  for (let i = 1; i <= 3; i++) {
    const row = s.claim(); assert.equal(row.attempts, i);
    assert.equal(s.fail('p1', row.lease_token, 'private customer input in an exception'), true);
    assert.equal(s.get('p1').last_error, 'SERVICE_FAILED');
    assert.equal(s.get('p1').payment, 'accepted');
    if (i < 3) s.retry('p1');
  }
  assert.throws(() => s.retry('p1'), e => e.code === 'RETRY_NOT_ALLOWED');
  assert.equal(s.get('p1').attempts, 3);
});

test('durable canonical result survives close/reopen without exposing raw request in status', t => {
  const f = fixture(t); const s = f.open();
  s.ensurePurchase(purchase()); s.confirmPayment('p1', 'block');
  const row = s.claim(); assert.equal(s.complete('p1', row.lease_token, { z: 1, a: 2 }), true);
  s.close();
  const reopened = f.open();
  assert.equal(reopened.get('p1').result_json, '{"a":2,"z":1}');
  const visible = publicPurchase(reopened.get('p1'));
  assert.deepEqual(visible, { purchase_id: 'p1', binding: purchase().binding, payment: { status: 'accepted', block: 'block' }, delivery: { status: 'succeeded', attempts: 1, max_attempts: 3, error: null }, result: { a: 2, z: 1 } });
  assert.equal(Object.hasOwn(visible, 'request'), false);
  assert.throws(() => reopened.retry('p1'), e => e.code === 'RETRY_NOT_ALLOWED');
});

test('transactions and nested savepoints roll back data and audit events together', t => {
  const f = fixture(t); const s = f.open();
  assert.throws(() => s.transaction(() => { s.ensurePurchase(purchase()); throw new Error('abort'); }), /abort/);
  assert.equal(s.get('p1'), undefined);
  assert.equal(s.db.prepare('SELECT COUNT(*) AS count FROM events').get().count, 0);
  s.transaction(() => {
    s.ensurePurchase(purchase());
    assert.throws(() => s.transaction(() => { s.ensurePurchase(purchase('p2')); throw new Error('nested'); }), /nested/);
  });
  assert.equal(s.get('p1').id, 'p1'); assert.equal(s.get('p2'), undefined);
});
