# Oncefolio build constitution

## Product truth and authority
Oncefolio sells one structured-data validation report to a buyer agent. Its signature flow is pay → lose the response → restart → recover the same purchase and result. The user authorized building the local MVP after the payment spike. No remote deployment, publication, public repository, real-token spending or submission is authorized. Oncefolio and Lotveil remain independent; names are provisional.

## Locked boundaries
- API/CLI-first local application; no production UI in this build.
- Native NEAR only. Product provider and payment contract are the same account, so acceptance credits that account in one receipt. No separate payout promise or automatic service-failure refund.
- Bind buyer, provider, quote/version, request digest, price, expiry, purchase ID, contract and environment. Never treat a missing RPC response as payment failure.
- Store raw requests and results offchain. Require buyer ownership for every private purchase operation.
- SQLite durability, atomic claims, lease fencing and at most three lifetime execution attempts; recomputation may occur, one canonical result is committed.
- A sandbox genesis fingerprint binds database and buyer intents to the actual chain instance. Never reset a mismatched database automatically.

## Conflict hierarchy and document map
Current user instruction > safety/authority > this constitution > SECURITY.md > 00_Flow_Contracts.md > BACKEND_SETUP.md > individual flow notes > builder judgment. Proven runtime informs corrections but does not grant authority.

Read 00_Brief_Analysis.md, 00_Source_Inventory.md, 00_Flow_Map.md and 00_Flow_Contracts.md. CONTEXT.md owns terminology. SECURITY.md owns trust boundaries; BACKEND_SETUP.md owns module/storage contracts. flows/ owns actor goals. Existing PROJECT_BRIEF.md and BUILD_PLAN.md retain project history; explicit newer instructions take precedence over their earlier setup-only authorization.

## Build order and proof
Build shared migrations, environment binding, identity, canonicalization and errors first; then Flow 01 purchase, Flow 03 delivery, and Flow 02 recovery. Preserve the real payment spike regression. Write failing behavior/security tests before each seam; review specification before code quality. Independently review payment, authorization and cross-flow failure behavior.

Bootstrap twice, replay migrations from zero, exercise unauthenticated/wrong-role/cross-object requests as real callers, race workers, interrupt buyer/provider processes, and inspect final chain receipts and persisted results. Inspect command definitions before execution. Capture fresh command transcripts, migration state and generated BUILD_STATE.json from repository/runtime truth. No narrative PASS may replace executed proof.

## Repository and release rules
Never write secrets or private payloads to logs/evidence. Generated runtime keys, signed intents, databases and temporary assets belong under ignored work/. User-facing deliverables belong under outputs/. Preserve pinned dependencies and the separate spike. No destructive real-data reset; use isolated fixtures. A web UI requires its own prototype review before production implementation. Stop for unapproved external spending, production activation, DNS, legal consent, publication or submission. Report remaining limits plainly.
