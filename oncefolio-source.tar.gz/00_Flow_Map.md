# Flow map

## Product outcome
A buyer receives one paid structured-data report and can resume the same purchase after an uncertain payment outcome or provider interruption.

## Flow registry
| ID | Flow | Primary actor | Goal | Trigger | Success outcome | Entry flows | Exit flows | Depends on | Proof |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 01 | Buy a report | Buyer agent | Fund one immutable report request | CLI buy / quote request | Exact finalized accepted purchase, eligible for delivery | Fresh intent | 02, 03 | Shared foundation | Product integration evidence pending |
| 02 | Resume a purchase/result | Buyer agent | Retrieve the existing purchase and report | CLI recover/status/retry | Same ID/binding and durable result, or honest pending/failed/unresolved status | 01, interruption | 03 or terminal retrieval | 01; finalized reconciliation | Fresh-process recovery proof pending |
| 03 | Complete a paid report | Provider worker | Publish one canonical report for paid work | Confirmed purchase/job claim | Durable result and succeeded delivery state committed atomically | 01, 02 | 02 | Finalized payment, durable job | Lease/restart/concurrency proof pending |

## Dependency order
| Batch | Kind | Includes | Depends on |
| --- | --- | --- | --- |
| shared-foundation | shared | SQLite migrations, environment binding, request validation, identity/session, errors, redacted logs | Existing payment spike |
| purchase | flow | 01 | Shared foundation |
| delivery | flow | 03 | 01 |
| recovery | flow | 02 and cross-flow interruption proof | 01, 03 |

## Surface and function coverage
Public GET /health and GET /v1/service belong to shared foundation. POST /v1/auth/challenges, POST /v1/auth/sessions and DELETE /v1/auth/session support the actor goal they unlock. POST /v1/quotes and CLI buy belong to 01. GET /v1/purchases/:id, POST /v1/purchases/:id/reconcile, POST /v1/purchases/:id/retry and CLI recover/status/retry belong to 02. Background claim/compute/commit belongs to 03. scripts/demo.mjs orchestrates all three; it is not another flow.

## Cross-flow edges
01 → 03: only independently verified finalized payment unlocks a durable job. 01 → 02: persist intent before signing/broadcast and retain its ID through interruption. 03 → 02: terminal result/state becomes retrievable only by its buyer. 02 → 03: bounded retry reuses the paid purchase and lifetime attempt count. Identity, canonicalization, quote, payment or lease changes require complete-flow regression proof.


## Executed local verification — November 5, 2026
See outputs/product/result.json, runtime.json, authorization.json, migration-state.json and demo.json. The clean verifier covers real settlement, ownership, worker SIGKILL/fencing, failed-delivery retry, stale nonce recovery and provider/chain/stored-result restart. Historical pending entries above describe foundation-authoring status; generated proof supersedes them. Testnet/production remain unverified.
