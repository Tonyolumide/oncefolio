# Testnet release runbook

Status: code and local regression proof prepared; external execution requires explicit approval of the public deployment plan. No mainnet or real-token funding is in scope.

## Prepare and inspect
Run `./oncefolio build`, then `./oncefolio testnet-prepare`. Preparation creates two fresh keypairs under ignored mode-0700 `work/testnet/`, with mode-0600 key files. It reads public testnet state but never contacts the faucet or signs/sends a transaction.

Inspect `outputs/testnet/deployment-plan.json` and `deployment-plan.sha256`: account IDs/public keys, approved RPC/faucet, genesis fingerprint, exact contract source/Wasm hashes, storage requirement and test-token budgets. `./oncefolio testnet-deploy` without flags is read-only preflight. Existing accounts must match the locally held full-access keys; unrelated contract code is never overwritten.

## Execute after exact approval
Execution requires `./oncefolio testnet-deploy --execute --plan-sha256 REVIEWED_PLAN_SHA256`, replacing the final argument with the literal hash the human approved. Do not automatically substitute a newly regenerated hash. Changed artifacts, keys, network identity or increased live cost stop execution.

The script requests faucet sponsorship only for an absent planned account and sends only the account ID/public key. It reconciles finalized account/key state after an uncertain response. If the faucet refuses, requires human intervention or provides insufficient test funds, stop; do not bypass controls or use mainnet funds.

The provider needs enough test NEAR for code/storage, gas and the reviewed buffer. DeployContract has no configurable gas field; the script checks its live protocol-fee estimate against the plan. FunctionCall actions set an explicit 100-TGas limit. Signed deployment/init bytes are persisted before broadcast; uncertain responses reconcile state. Lifetime signing attempts per action are capped at two. No automatic unrelated retry or contract replacement occurs.

Successful deployment writes public evidence to `outputs/testnet/deployment.json` and private-path runtime configuration to `work/testnet/runtime.json`. Keys, signed bytes, databases and requests never enter the release archive.

## Start and validate after deployment
Run `./oncefolio testnet-start`; it starts only the localhost provider API and worker after verifying the live network and initialized contract. It never creates an account or deploys.

In a separate terminal:

```sh
./oncefolio testnet-buy work/testnet/purchase.json examples/request.json
./oncefolio testnet-recover work/testnet/purchase.json
```

The purchase is 0.1 **test** NEAR plus gas. Recovery reuses the original intent. The reviewed validation budget permits at most 0.3 test NEAR in attached deposits: first purchase, duplicate rejection and changed-binding rejection. Rejected deposits must be inspected through finalized refund receipts. Testnet validation is not proven until actual transactions and restart/result evidence have been captured; passing local tests alone is insufficient.

Stop before any public repository creation/push, social post or hackathon submission unless that specific action is authorized. The human must publish the X demo and confirm the complete submission payload, contact consent and real prize account before submission.
