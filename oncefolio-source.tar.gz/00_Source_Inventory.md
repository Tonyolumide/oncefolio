# Source inventory

Snapshot inventory captured November 4, 2026 during foundation authoring. Hashes identify the inspected versions, not a promise that active implementation files remain unchanged. New user build authorization and the parent-orchestrator architecture packet are authoritative conversation sources with no local file hash. No screens/assets were supplied; visual surface coverage is not applicable to this headless API build.

| ID | Source | SHA-256 | Kind | Authority | Coverage | Inspection method | Status and findings |
| --- | --- | --- | --- | --- | --- | --- | --- |
| REF-001 | PROJECT_BRIEF.md | 667dce97479ed621201a1239dc73f9c1457b1628bd1f36993e6cc2deed3c659f | brief | AUTHORITATIVE | required | Text/static inspection; historical runtime report | Product intent; earlier local-spike-only authority superseded by later user build instruction. |
| REF-002 | BUILD_PLAN.md | 8fa7a80962b0f462baa204091ec721f03605b5a0c357afde2ea30ffbd6e312ca | plan | DIRECTIONAL | contextual | Text/static inspection; historical runtime report | Historical plan, updated by the API foundation decisions. |
| REF-003 | README.md | 0b939aa16c1e65da8b72e153dafe5e380666a8ae969cb9504b352432a508f676 | project description | CONTENT_ONLY | contextual | Text/static inspection; historical runtime report | Independent Lotveil disclosure and current scope. |
| REF-004 | outputs/FEASIBILITY_REPORT.md | e3f80f5124007a7040b156bbb163a4c87dafe08664e87d08351638a4ac462417 | runtime report | BEHAVIOR_ONLY | required | Text/static inspection; historical runtime report | Historical local payment evidence; not delivery proof. |
| REF-005 | spike/contract.js | 402aa15ec7f00d629d35407686e24ba71d97e683d654bc2c5ce2de587e9ea140 | contract code | BEHAVIOR_ONLY | required | Text/static inspection; historical runtime report | Existing payment boundary; product may add quote recovery view. |
| REF-006 | spike/feasibility.test.mjs | 26e768605806a6e366e3656125f8001b76ba102bfae2b4f2592154cbcfe0a511 | integration tests | BEHAVIOR_ONLY | required | Text/static inspection; historical runtime report | Baseline payment accounting and interruption cases. |
| REF-007 | spike/client.mjs | 345f0e775ff8968a732117bc9c923b7ddcd199e5b9f7df5b7d54be9920cd345a | recovery code | BEHAVIOR_ONLY | required | Text/static inspection; historical runtime report | Historical durable signed intent/recovery behavior. |
| REF-008 | work/HACKATHON.md | 86654c13521fe629493bf498d41c0f7573047867d67fcdd8c2543411fc13062f | official rules snapshot | AUTHORITATIVE | contextual | Text/static inspection; historical runtime report | Retrieved November 4; recheck live source before submission. |
